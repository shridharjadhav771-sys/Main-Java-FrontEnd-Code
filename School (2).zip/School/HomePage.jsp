<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Login Page</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
</head>
 
<body>
    <div class="wrapper">
        <form id="loginForm" action="LoginServlet" method="post">
            <h1>Login</h1>
	            <div id="errorMsg" class="text-danger"></div>
	
            <div class="input-box">
                <input type="text" placeholder="Username" name="username" id="username" required>
                <i class="bi bi-person"></i>
            </div>

            <div class="input-box">
                <input type="password" placeholder="Password" name="password" id="password" required>
                <i class="bi bi-lock"></i>
            </div>

            <div class="remember-forgot">
                <label>
                    <input type="checkbox" id="rememberMe"> Remember Me
                </label>
                <a href="#">Forgot Password?</a>
            </div>

            <button type="button" class="btn" onclick="doSubmit()">Login</button>

            <div class="register-link">
                <p>Don’t have an account? <a href="#">Register</a></p>
            </div>
        </form>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script>

$(document).ready(function() {
	 
 
	 if($.cookie('username')){
		 $("#username").val($.cookie('username'));
		 $("#rememberMe").prop('checked',true);
	 }
	 
	 if($.cookie('password')){
		 $("#password").val($.cookie('password'));
	 }
	 
	 
	  
});

function doSubmit(){
	
    $("#errorMsg").html(''); // Clear previous error
    var username = $("#username").val();
    var password = $("#password").val();
    
    if($("#username").val() === ''){
    	alert('Please enter username:');
    	return;
    }
    
    if($("#password").val() === ''){
    	alert('Please enter password:');
    	return;
    }
    
    
    $.ajax({
        url: 'LoginServlet',
        type: 'POST',
        data: {
            username: username,
            password: password
        },
        success: function(resp) {
            console.log("Response: " + resp);
            if (resp.trim() === "Login successful") {
            	
            	if($("#rememberMe").is(":checked")){
			    	//set cookie if remember me is checked
			    	$.cookie('username', username, { expires: 7, path: '/' }); 
			    	$.cookie('password', password, { expires: 7, path: '/' }); 
    			}else{
    				$.removeCookie('username', { path: '/' });
    	            $.removeCookie('password', { path: '/' });
    			}
            	
            	
                window.location.href = "welcome.jsp";
            } else {
                $("#errorMsg").html("Invalid username or password");
            }
        },
        error: function() {
            $("#errorMsg").html("Server error occurred. Please try again.");
        }
    });
s
	
}
</script>


</body>
</html>
