<%@ page contentType="text/html;charset=UTF-8"%>
<%@ page import="java.util.List"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Customers</title>

<!-- Bootstrap CSS + Icons (ensure these are available once) -->
<link
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
	rel="stylesheet">
<link
	href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
	rel="stylesheet">

<style>
/* --- Categories page styles --- */
body {
	background-color: #f8f9fc;
	font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.card-custom {
	border-radius: 16px;
	box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
	transition: transform 0.2s ease, box-shadow 0.2s ease;
	border: none;
}

.card-custom:hover {
	transform: translateY(-3px);
	box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18);
}

.btn-primary, .btn-danger {
	border-radius: 12px;
	padding: 8px 18px;
	font-weight: 500;
}

.btn-primary {
	background: linear-gradient(to right, #4e54c8, #8f94fb);
	border: none;
}

.btn-danger {
	background: linear-gradient(to right, #ff416c, #ff4b2b);
	border: none;
}

.table-custom {
	border-radius: 12px;
	overflow: hidden;
	box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

.table thead {
	background-color: #4e54c8;
	color: white;
}

.table thead th {
	border: none;
	padding: 15px;
}

.table-striped tbody tr:nth-of-type(odd) {
	background-color: #fafbff;
}

.table-hover tbody tr:hover {
	background-color: #e9f0ff;
}

.table td {
	padding: 15px;
	border-color: #f1f4f9;
}

.action-btn {
	margin-left: 4px;
}

.modal-content {
	border-radius: 16px;
	border: none;
	box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18);
}

.modal-header {
	background: linear-gradient(to right, #4e54c8, #8f94fb);
	color: white;
	border-radius: 16px 16px 0 0;
}

.modal-title {
	font-weight: 600;
}

.form-control {
	border-radius: 12px;
	padding: 12px 16px;
	border: 1px solid #e1e5ef;
}

.form-control:focus {
	box-shadow: 0 0 0 3px rgba(78, 84, 200, 0.2);
	border-color: #4e54c8;
}

.search-box {
	position: relative;
}

.search-box .form-control {
	padding-left: 45px;
}

.search-box .bi-search {
	position: absolute;
	left: 15px;
	top: 12px;
	color: #6c757d;
}

/* Layout helpers so sidebar (provided by sidebar.jsp) sits left and main content fills right */
.app-shell {
	display: flex;
	gap: 0;
	align-items: flex-start;
}

.main-content {
	flex: 1 1 auto;
	min-width: 0; /* ensures proper flex behavior */
}
/* container inside main-content keeps spacing consistent with your original page */
.main-content .container {
	padding-left: 2rem;
	padding-right: 2rem;
}

@media ( max-width : 768px) {
	.app-shell {
		flex-direction: column;
	}
	.main-content .container {
		padding-left: 1rem;
		padding-right: 1rem;
	}
}
</style>
</head>
<body>

	<div class="app-shell">

		<!-- SINGLE include tag to insert the sidebar -->
		<jsp:include page="sidebar.jsp" />

		<!-- Main content -->
		<div class="main-content">
			<div class="container py-5">

				<!-- Page Header -->
				<div class="d-flex justify-content-between align-items-center mb-4">
					<div>
						<h2 class="fw-bold mb-1">Customer Management</h2>
						<p class="text-muted">Organize your Customers into categories</p>
					</div>

					<!-- Button to open modal -->
					<button type="button" class="btn btn-primary shadow-sm"
						data-bs-toggle="modal" data-bs-target="#addCustomerModal">
						+ Add New Customers</button>
				</div>

				<!-- Categories Card -->
				<div class="card card-custom">
					<div class="card-body">
						<h5 class="mb-3 fw-semibold">Customers</h5>

						<!-- Search Form -->
						<form class="d-flex mb-3" role="search" id="searchForm">
							<input class="form-control me-2" type="search"
								placeholder="Search customers..." aria-label="Search"
								name="query" id="query">
							<button class="btn btn-outline-primary" type="submit">Search</button>
						</form>

						<!-- Table -->
						<div class="table-responsive table-custom">
							<table class="table table-striped table-hover align-middle mb-0">
								<thead>
									<tr>
										<th scope="col">Customers Name</th>
										<th scope="col">Organization</th>
										<th scope="col">Contact No</th>
										<th scope="col">Email</th>
										<th scope="col">Address</th>
										<th scope="col">Actions</th>
									</tr>
								</thead>
								<tbody id="customersTblBody">
									<!-- Dynamic rows will be injected by JS -->
								</tbody>
							</table>
						</div>
					</div>
				</div>

			</div>
			<!-- /.container -->
		</div>
		<!-- /.main-content -->

	</div>
	<!-- /.app-shell -->

	<!-- ===================== Modal ===================== -->
	<div class="modal fade" id="addCustomerModal" tabindex="-1"
		aria-labelledby="addCustomerModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg modal-dialog-centered">
			<div class="modal-content text-dark">
				<div class="modal-header">
					<h5 class="modal-title" id="addCustomerModalLabel">Add New
						Customer</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal"
						aria-label="Close"></button>
				</div>

				<div class="modal-body">
					<form action="customer" method="post" name="customerForm"
						id="customerForm">

						<input type="hidden" name="customer_id" id="customer_id">
						<input type="hidden" name="action" id="actionID" />

						<!-- Customer Name -->
						<div class="mb-3">
							<label for="customer_name" class="form-label">Customer
								Name</label> <input type="text" class="form-control" id="customer_name"
								name="customer_name" required> <span id="nameError"
								style="color: grey"></span>
						</div>

						<!-- Organization -->
						<div class="mb-3">
							<label for="organization" class="form-label">Organization</label>
							<input type="text" class="form-control" id="organization"
								name="organization" required>
							<span id="organizationError" style="color: grey"></span>
						</div>

						<!-- Contact No -->
						<div class="mb-3">
							<label for="contact_no" class="form-label">Contact Number</label>
							<input type="text" class="form-control" id="contact_no"
								name="contact_no" onblur="doCheckContact(this.value)" required>
							<span id="contactError" style="color: grey"></span>
						</div>

						<!-- Email -->
						<div class="mb-3">
							<label for="email" class="form-label">Email</label> <input
								type="email" class="form-control" id="email" name="email"
								required> <span id="emailError" style="color: grey"></span>
						</div>

						<!-- Address -->
						<div class="mb-3">
							<label for="address" class="form-label">Address</label>
							<textarea class="form-control" id="address" rows="3"
								name="address" rows="3" required></textarea>
							<span id="addressError" style="color: grey"></span>
						</div>

						<!-- Buttons -->
						<div class="d-grid gap-2">
							<button type="button" onclick="validateInfo()"
								class="btn btn-primary" id="addbtnID">Add Customer</button>
							<a href="customerList" class="btn btn-secondary">Cancel</a>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<!-- Bootstrap JS + jQuery (kept at bottom) -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js"
		integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="
		crossorigin="anonymous"></script>
	<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

	<script type="text/javascript">
		$(document).ready(function() {
			loadCustomerList();
		});

		$("#searchForm").on("submit", function(event) {
			event.preventDefault();
			loadCustomerList();
		});

		function loadCustomerList() {
			$.ajax({
				url : 'customerList',
				type : 'GET',
				data : {
					query : $("#query").val()
				},
				success : function(data) {
					console.log("Fetched Customer:", data);

					$("#customersTblBody").empty();
					$.map(data, function(customer) {
						var rowData = createRowElement(customer);
						$("#customersTblBody").append(rowData);
					});
				},
				error : function() {
					alert('Error fetching customer data');
				}
			});
		}

		function validateInfo() {
			$("#nameError").html('');
			$("#organizationError").html('');
			$("#contactNoError").html('');
			$("#emailError").html('');
			$("#addressError").html('');

			var customerName = $("#customer_name").val().trim();
			var organization = $("#organization").val().trim();
			var contactNo = $("#contact_no").val().trim();
			var email = $("#email").val().trim();
			var address = $("#address").val().trim();

			var isValid = true;

			// Customer Name
			if (customerName === '') {
				$("#nameError").html("Customer Name is required.");
				isValid = false;
			}

			// Organization
			if (organization === '') {
				$("#organizationError").html("Organization is required.");
				isValid = false;
			}
				
			/*
			// Contact No
			if (contactNo === '') {
				$("#contactNoError").html("Contact No is required.");
				isValid = false;
			} else if (!/^[0-9\s\-\(\)]{7,15}$/.test(contactNo)) { // Allows 7-15 digits, spaces, dashes, or parentheses
				$("#contactNoError").html(
						"Enter a valid contact number (7-15 digits).");
				isValid = false;
			}
			*/
			
			if(contactNo === '' || contactNo.length !== 10 || isNaN(contactNo)){
				$("#contactError").html("Please enter a valid 10-digit contact.");
				isValid = false;
			}
			
			// Email
			if (email === '') {
				$("#emailError").html("Email is required.");
				isValid = false;
			} else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
				$("#emailError").html("Enter a valid email address.");
				isValid = false;
			}

			// Address
			if (address === '') {
				$("#addressError").html("Address is required.");
				isValid = false;
			}

			if (isValid) {
				$.ajax({
					url : 'customer',
					type : 'POST',
					data : $('#customerForm').serialize(),
					success : function(data) {
						data = $.trim(data);
						if (data === 'success') {
							loadCustomerList();
							$('#addCustomerModal').modal('hide');
						} else {
							alert('Save failed');
						}
					},
					error : function() {
						alert('Something went wrong. Please try again');
					}
				});
			}
		}

		function createRowElement(customer) {
			var rowData = "<tr>";
			rowData += "<td>" + customer.customer_name + "</td>";
			rowData += "<td>" + customer.organization + "</td>";
			rowData += "<td>" + customer.contact_no + "</td>";
			rowData += "<td>" + customer.email + "</td>";
			rowData += "<td>" + customer.address + "</td>";
			/* 
			rowData += "<td>" + new Date(category.date_added).toLocaleString('en-US', {
			    month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true
			}) + "</td>";
			rowData += "<td>" + new Date(category.date_updated).toLocaleString('en-US', {
			    month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true
			}) + "</td>";
			 */
			rowData += "<td>";
			rowData += "<button class='btn btn-sm btn-primary' onclick='editCustomer("
					+ customer.customer_id + ")'>Edit</button> ";
			rowData += "<button type='button' class='btn btn-sm btn-danger' onclick='doDelete("
					+ customer.customer_id + ", event)'>Delete</button>";
			rowData += "</td>";
			rowData += "</tr>";
			return rowData;
		}

		function doDelete(customer_id) {
			if (confirm("Delete this customer?")) {

				$.ajax({
					url : 'customer',
					type : 'POST',
					data : {
						action : 'delete',
						customer_id : customer_id
					},
					success : function(data) {
						console.log(data);
						if ($.trim(data) === 'success') {
							loadCustomerList();
							$('#addCustomerModal').modal('hide');
						} else {
							console.log("Not saved...");
						}
					},
					error : function() {
						alert('Something wrong. Please try again')
					}
				});
			}
		}

		function doCheckContact(contact_no) {
			if (contact_no.trim() === '') {
			      $('#contactError').html('Contact number is required.');
			      return;
			    }
			
			console.log('Contact no ' + contact_no);
			$.ajax({
						url : "customerContact",
						type : "GET",
						data : {
							ContactVal : contact_no
						},
						success : function(resp) {
							console.log(resp);
							if (resp === 'exist') {
								$('#contactError').html("This contact is already used. Please enter another.");
							}
						},
						failure : function(data) {
							alert('Invalid request');
						}
					});
		}

		function editCustomer(customer_id) {
			$('#addCustomerModalLabel').text('Edit Customer');
			$.ajax({
				url : 'customer',
				type : 'GET',
				data : {
					customer_id : customer_id
				},
				dataType : 'json',
				success : function(customer) {
					if (customer && customer.customer_id) {
						$('#actionID').val('update');
						$('#customer_id').val(customer.customer_id);
						$('#customer_name').val(customer.customer_name);
						$('#organization').val(customer.organization);
						$('#contact_no').val(customer.contact_no);
						$('#email').val(customer.email);
						$('#address').val(customer.address);
						$('#addbtnID').text('Update');
						$('#addCustomerModal').modal('show');
					} else {
						alert('Error fetching customer data');
					}
				},
				error : function() {
					alert('Error fetching customer data');
				}
			});
		}

		$(document).on('click', '[data-bs-target="#addCustomerModal"]',
				function() {
					$('#addCustomerModalLabel').text("Add New Customer");
					$('#addbtnID').text('Add Customer');
					$('#customerForm')[0].reset();
					$('#customer_id').val('');
					$('#actionID').val('');
					$('#nameError').html('');
					$("#organizationError").html('');
					$("#contactNoError").html('');
					$("#emailError").html('');
					$("#addressError").html('');
				});
	</script>
</body>
</html>
