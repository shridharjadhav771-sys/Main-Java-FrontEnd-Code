<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>SubCategories</title>

    <!-- Bootstrap CSS + Icons (ensure these are available once) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        /* KEEP ALL YOUR EXISTING CSS UNCHANGED */
        body { background-color: #f8f9fc; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; } .card-custom { border-radius: 16px; box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12); transition: transform 0.2s ease, box-shadow 0.2s ease; border: none; } .card-custom:hover { transform: translateY(-3px); box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18); } .btn-primary, .btn-danger { border-radius: 12px; padding: 8px 18px; font-weight: 500; } .btn-primary { background: linear-gradient(to right, #4e54c8, #8f94fb); border: none; } .btn-danger { background: linear-gradient(to right, #ff416c, #ff4b2b); border: none; } .table-custom { border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); } .table thead { background-color: #4e54c8; color: white; } .table thead th { border: none; padding: 15px; } .table-striped tbody tr:nth-of-type(odd) { background-color: #fafbff; } .table-hover tbody tr:hover { background-color: #e9f0ff; } .table td { padding: 15px; border-color: #f1f4f9; } .action-btn { margin-left: 4px; } .modal-content { border-radius: 16px; border: none; box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18); } .modal-header { background: linear-gradient(to right, #4e54c8, #8f94fb); color: white; border-radius: 16px 16px 0 0; } .modal-title { font-weight: 600; } .form-control { border-radius: 12px; padding: 12px 16px; border: 1px solid #e1e5ef; } .form-control:focus { box-shadow: 0 0 0 3px rgba(78, 84, 200, 0.2); border-color: #4e54c8; } .search-box { position: relative; } .search-box .form-control { padding-left: 45px; } .search-box .bi-search { position: absolute; left: 15px; top: 12px; color: #6c757d; } .app-shell { display: flex; gap: 0; align-items: flex-start; } .main-content { flex: 1 1 auto; min-width: 0; } .main-content .container { padding-left: 2rem; padding-right: 2rem; } @media (max-width: 768px) { .app-shell { flex-direction: column; } .main-content .container { padding-left: 1rem; padding-right: 1rem; } }
    </style>
</head>
<body>

<div class="app-shell">

    <jsp:include page="sidebar.jsp" />

    <!-- Main content -->
    <div class="main-content">
      <div class="container py-5">

        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h2 class="fw-bold mb-1">Software Service Management</h2>
            <p class="text-muted">Organize your Services </p>
          </div>

          <!-- Button to open modal -->
          <button type="button" class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#addServiceModal">
            + Add New Service
          </button>
        </div>

        <!-- SubCategories Card -->
        <div class="card card-custom" >
          <div class="card-body">
            <h5 class="mb-3 fw-semibold"> Software Service </h5>

            <!-- Search Form -->
            <form class="d-flex mb-3 row gx-3 gy-2 align-items-center" role="search" id="searchServiceForm">
                <div class="col-auto">
                    <input class="form-control me-2" type="search"
                           placeholder="Search Product / Software / License Key..."
                           aria-label="Search" name="query" id="query">
                </div>

                <div class="col-auto">
                    <select class="form-select" name="status" id="status">
                        <option value="">-- Select Status --</option>
                        <option value="Active">Active</option>
                        <option value="Expired">Expired</option>
                        <option value="Inactive">Inactive</option>
                    </select>
                </div>

                <div class="col-auto">
                    <button type="button" class="btn btn-primary" onclick="loadServiceList()">Search</button>
                </div>
            </form>

            <!-- Table -->
            <div class="table-responsive table-custom">
              <table class="table table-striped table-hover align-middle mb-0">
                <thead>
                  <tr>
                      <th scope="col">Product Name</th>
                      <th scope="col">Software Name</th>
                      <th scope="col">License Key</th>
                      <th scope="col">Issue Date</th>
                      <th scope="col">Expiry Date</th>
                      <th scope="col">Validity Period</th>
                      <th scope="col">Status</th>
                      <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody id="serviceTblBody">
                  <!-- Dynamic rows will be injected by JS -->
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>
    </div>

</div>

<!-- Modal -->
<div class="modal fade" id="addServiceModal" tabindex="-1" aria-labelledby="addServiceModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content text-dark">
      <div class="modal-header">
        <h5 class="modal-title" id="addServiceModalLabel">Add New Product</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="softwareService" method="post" name="serviceForm" id="serviceForm">
            <input type="hidden" name="service_id" id="service_id">
            <input type="hidden" name="action" id="actionID"/>

            <!-- Product Dropdown -->
            <div class="mb-3">
                <label for="product_id" class="form-label">Product</label>
                <select name="product_id" id="product_id" class="form-select" required>
                    <option value="">Select Product</option>
                </select>
                <span id="productError" style="color: grey"></span>
            </div>

            <!-- Software Name -->
            <div class="mb-3">
                <label for="software_name" class="form-label">Software Name</label>
                <input type="text" class="form-control" id="software_name" name="software_name" required>
                <span id="softwareNameError" style="color: grey"></span>
            </div>

            <!-- License Key -->
            <div class="mb-3">
                <label for="license_key" class="form-label">License Key</label>
                <input type="text" class="form-control" id="license_key" name="license_key" required>
                <span id="licenseKeyError" style="color: grey"></span>
            </div>

            <!-- Issue Date -->
            <div class="mb-3">
                <label for="issue_date" class="form-label">Issue Date</label>
                <input type="date" class="form-control" id="issue_date" name="issue_date" required>
                <span id="issueDateError" style="color: grey"></span>
            </div>

            <!-- Expiry Date -->
            <div class="mb-3">
                <label for="expiry_date" class="form-label">Expiry Date</label>
                <input type="date" class="form-control" id="expiry_date" name="expiry_date" required>
                <span id="expiryDateError" style="color: grey"></span>
            </div>

            <!-- Validity Period -->
            <div class="mb-3">
                <label for="validity_period" class="form-label">Validity Period (in days/months)</label>
                <input type="number" min="1" class="form-control" id="validity_period" name="validity_period" required>
                <span id="validityPeriodError" style="color: grey"></span>
            </div>

            <!-- Status Dropdown -->
            <div class="mb-3">
                <label for="status_modal" class="form-label">Status</label>
                <select name="status" id="status_modal" class="form-select" required>
                    <option value="">Select Status</option>
                    <option value="Active">Active</option>
                    <option value="Expired">Expired</option>
                    <option value="Inactive">Inactive</option>
                </select>
                <span id="statusError" style="color: grey"></span>
            </div>

            <div class="d-grid gap-2">
                <button type="button" onclick="validateServiceInfo()" class="btn btn-primary" id="addbtnID">Add Service</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS + jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
    loadProductList();
    loadServiceList();

    $("#searchServiceForm button").on("click", function(event) {
        event.preventDefault();
        loadServiceList();
    });
});

function loadServiceList() {
    $("#serviceTblBody").html('<tr><td colspan="8" class="text-center">Loading...</td></tr>');
    $.ajax({
        url: 'serviceList',
        type: 'GET',
        data: {
            query: $("#query").val(),
            status: $("#status").val()
        },
        success: function(data) {
            $("#serviceTblBody").empty();
            $.map(data, function(service) {
                $("#serviceTblBody").append(createRowElement(service));
            });
        },
        error: function() {
            alert('Error fetching service data');
        }
    });
}

function validateServiceInfo() {
    // Clear previous errors
    $("#productError, #softwareNameError, #licenseKeyError, #issueDateError, #expiryDateError, #validityPeriodError, #statusError").html('');

    var productId = $("#product_id").val().trim(),
        softwareName = $("#software_name").val().trim(),
        licenseKey = $("#license_key").val().trim(),
        issueDate = $("#issue_date").val().trim(),
        expiryDate = $("#expiry_date").val().trim(),
        validityPeriod = $("#validity_period").val().trim(),
        status = $("#status_modal").val().trim(),
        isValid = true;

    if(productId === '') { $("#productError").html("Product is required."); isValid=false; }
    if(softwareName === '') { $("#softwareNameError").html("Software Name is required."); isValid=false; }
    if(licenseKey === '') { $("#licenseKeyError").html("License Key is required."); isValid=false; }
    if(issueDate === '') { $("#issueDateError").html("Issue Date is required."); isValid=false; }
    if(expiryDate === '') { $("#expiryDateError").html("Expiry Date is required."); isValid=false; }
    if(validityPeriod === '') { $("#validityPeriodError").html("Validity Period is required."); isValid=false; }
    if(status === '') { $("#statusError").html("Status is required."); isValid=false; }

    if(isValid){
        $.ajax({
            url: 'softwareService',
            type: 'POST',
            data: $('#serviceForm').serialize(),
            success: function(data){
                data = $.trim(data);
                if(data === 'success'){
                    loadServiceList();
                    $('#addServiceModal').modal('hide');
                } else { alert('Save failed'); }
            },
            error: function(){ alert('Something went wrong. Please try again'); }
        });
    }
}

function createRowElement(service){
    var row = "<tr>";
    row += "<td>" + service.product_name + "</td>";
    row += "<td>" + service.software_name + "</td>";
    row += "<td>" + service.license_key + "</td>";
    row += "<td>" + service.issue_date + "</td>";
    row += "<td>" + service.expiry_date + "</td>";
    row += "<td>" + service.validity_period + "</td>";
    row += "<td>" + service.status + "</td>";
    row += "<td>";
    row += "<button class='btn btn-sm btn-primary' onclick='editService(" + service.service_id + ")'>Edit</button> ";
    row += "<button class='btn btn-sm btn-danger' onclick='doDelete(" + service.service_id + ")'>Delete</button>";
    row += "</td></tr>";
    return row;
}

function loadProductList(){
    $.ajax({
        url: 'productList',
        type: 'GET',
        success: function(data){
            var $product = $("#product_id");
            $product.empty();
            $product.append('<option value="">Select Product</option>');
            $.map(data, function(p){ $product.append('<option value="'+p.product_id+'">'+p.model+'</option>'); });
        },
        error: function(){ alert('Error fetching product data'); }
    });
}

function doDelete(service_id){
    if(confirm("Delete this service?")){
        $('#actionID').val('delete');
        $('#service_id').val(service_id);
        $.ajax({
            url:'softwareService',
            type:'POST',
            data: $('#serviceForm').serialize(),
            success: function(data){
                if($.trim(data)==='success'){ loadServiceList(); $('#addServiceModal').modal('hide'); }
                else { console.log("Not deleted"); }
            },
            error: function(){ alert('Something went wrong.'); }
        });
    }
}

function editService(service_id){
    $('#addServiceModalLabel').text('Edit Service');
    $.ajax({
        url: 'softwareService',
        type: 'GET',
        data: {service_id: service_id},
        dataType: 'json',
        success: function(service){
            if(service && service.service_id){
                $('#actionID').val('update');
                $('#service_id').val(service.service_id);
                $('#product_id').val(service.product_id);
                $('#software_name').val(service.software_name);
                $('#license_key').val(service.license_key);
                $('#issue_date').val(service.issue_date);
                $('#expiry_date').val(service.expiry_date);
                $('#validity_period').val(service.validity_period);
                $('#status_modal').val(service.status);

                $('#addbtnID').text('Update');
                $('#addServiceModal').modal('show');
            } else { alert('Error fetching service data'); }
        },
        error: function(){ alert('Error fetching service data'); }
    });
}

// Reset modal when opening "Add Service"
$(document).on('click', '[data-bs-target="#addServiceModal"]', function(){
    $('#addServiceModalLabel').text("Add New Service");
    $('#addbtnID').text('Add Service');
    $('#serviceForm')[0].reset();
    $('#service_id').val('');
    $('#productError, #softwareNameError, #licenseKeyError, #issueDateError, #expiryDateError, #validityPeriodError, #statusError').html('');
});
</script>
</body>
</html>
