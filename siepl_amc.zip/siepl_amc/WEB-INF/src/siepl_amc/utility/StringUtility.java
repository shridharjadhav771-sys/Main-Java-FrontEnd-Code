package siepl_amc.utility;

public class StringUtility {
	public static String removeNull(String val) {
		return val == null ? "": val;
	}
}
