package siepl_amc.mst.mst_units;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import siepl_amc.utility.DBConfig;

public class UnitDAO {

	public UnitDTO getUnitById(int unit_id) {
		// TODO Auto-generated method stub
		UnitDTO unitDTO = null;
		String query = "select * from siepl_amc_mst_units where unit_id = ? and is_deleted = 0";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setInt(1, unit_id);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				unitDTO = new UnitDTO();
				unitDTO.setUnit_id(rs.getInt("unit_id"));
				unitDTO.setUnit_name(rs.getString("unit_name"));
				unitDTO.setDate_added(rs.getTimestamp("date_added").toLocalDateTime());
				unitDTO.setDate_updated(rs.getTimestamp("date_updated").toLocalDateTime());
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return unitDTO;
	}

	public boolean updateUnit(UnitDTO unitDTO) {
		// TODO Auto-generated method stub
		String query = "update siepl_amc_mst_units set unit_name = ? where unit_id = ?";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setString(1, unitDTO.getUnit_name());
			ps.setInt(2, unitDTO.getUnit_id());
			return ps.executeUpdate() > 0;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return false;
	}

	public boolean deleteUnit(int unit_id) {
		// TODO Auto-generated method stub
		String query = "update siepl_amc_mst_units set is_deleted = 1 where unit_id = ?";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setInt(1, unit_id);
			return ps.executeUpdate() > 0;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return false;
	}

	public boolean insertUnit(UnitDTO unitDTO) {
		// TODO Auto-generated method stub
		String query = "insert into siepl_amc_mst_units (unit_name, date_added) values (? , NOW())";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setString(1, unitDTO.getUnit_name());
			return ps.executeUpdate() > 0;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return false;
	}

	public List<UnitDTO> getAllUnits(String query) {
		// TODO Auto-generated method stub
		List<UnitDTO> list = new ArrayList<>();
		try {
			 String sql = "SELECT * FROM siepl_amc_mst_units WHERE is_deleted = 0";
			 
			 if(query != null && !query.isEmpty()) {
				 sql += " AND unit_name LIKE ?";
			 }
			 
			 try (Connection con = DBConfig.getConnection();
		             PreparedStatement ps = con.prepareStatement(sql)){
				 if (query != null && !query.trim().isEmpty()) {
		                ps.setString(1, "%" + query + "%");
		         }
				 ResultSet rs = ps.executeQuery();
					
		            while (rs.next()) {
		            	UnitDTO unitDTO = new UnitDTO();
		            	unitDTO.setUnit_id(rs.getInt("unit_id"));
		            	unitDTO.setUnit_name(rs.getString("unit_name"));
						unitDTO.setDate_added(rs.getTimestamp("date_added").toLocalDateTime());
						unitDTO.setDate_updated(rs.getTimestamp("date_updated").toLocalDateTime());
						list.add(unitDTO);
		            }
			 }
		}catch (Exception e) {
			// TODO: handle exception
			 e.printStackTrace();
				System.out.println(e.getMessage());
		}
		return list;
	}

}
