package siepl_amc.mst.mst_units;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import siepl_amc.mst.mst_category.CategoryDTO;
import siepl_amc.utility.LocalDateTimeTypeAdapter;

@WebServlet("/unit")
public class UnitServlet extends HttpServlet{
	private final Gson gson;

    public UnitServlet() {
        this.gson = new GsonBuilder()
                .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeTypeAdapter())
                .create();
    }
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        String action = req.getParameter("action");
        
        String unit_id = req.getParameter("unit_id");
        UnitDAO unitDAO = new UnitDAO();
        
        if ("list".equalsIgnoreCase(action)) {
            // fetch all categories
            String query = req.getParameter("query") == null ? "" : req.getParameter("query").trim();
            List<UnitDTO> units = unitDAO.getAllUnits(query);

            String unitsJson = gson.toJson(units);
            resp.getWriter().write(unitsJson);

        }else if(unit_id != null && !unit_id.isEmpty()) {
        	
        	UnitDTO unit = unitDAO.getUnitById(Integer.parseInt(unit_id));
        	
        	if(unit != null) {
        		String unitJson = gson.toJson(unit);
				resp.getWriter().write(unitJson);
        	}else {
				resp.getWriter().write("{}");
			}
        }else {
			resp.getWriter().write("{}");
		}
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain");
        
        String action =req.getParameter("action");
        String unit_id = req.getParameter("unit_id");
        
        UnitDTO unitDTO = new UnitDTO();
        if(!"delete".equalsIgnoreCase(action)) {
        	String unit_name = req.getParameter("unit_name");
        	
        	unitDTO.setUnit_name(unit_name);
        	unitDTO.setIs_deleted(0);
        }
        
        UnitDAO unitDAO = new UnitDAO();
        boolean status;
        
        if("update".equals(action) && unit_id != null && !unit_id.isEmpty()) {
        	unitDTO.setUnit_id(Integer.parseInt(unit_id));
        	status = unitDAO.updateUnit(unitDTO);
        }else if("delete".equalsIgnoreCase(action) && unit_id != null && !unit_id.isEmpty()) {
        	status = unitDAO.deleteUnit(Integer.parseInt(unit_id));
        }else {
        	status = unitDAO.insertUnit(unitDTO);
        }
        
        resp.setContentType("application/plain");
		if (status)
			resp.getWriter().write("success");
		else
			resp.getWriter().write("failure");
		
	}
}
