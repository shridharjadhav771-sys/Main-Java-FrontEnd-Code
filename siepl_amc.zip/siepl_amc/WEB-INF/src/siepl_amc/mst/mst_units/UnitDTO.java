package siepl_amc.mst.mst_units;

import java.time.LocalDateTime;

public class UnitDTO {

    private Integer unit_id;
    private String unit_name;   // e.g., pcs, box, kg
    private LocalDateTime date_added;
    private LocalDateTime date_updated;
    private int is_deleted;
    
	public UnitDTO(Integer unit_id, String unit_name, LocalDateTime date_added, LocalDateTime date_updated,
			int is_deleted) {
		super();
		this.unit_id = unit_id;
		this.unit_name = unit_name;
		this.date_added = date_added;
		this.date_updated = date_updated;
		this.is_deleted = is_deleted;
	}

	public UnitDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getUnit_id() {
		return unit_id;
	}

	public void setUnit_id(Integer unit_id) {
		this.unit_id = unit_id;
	}

	public String getUnit_name() {
		return unit_name;
	}

	public void setUnit_name(String unit_name) {
		this.unit_name = unit_name;
	}

	public LocalDateTime getDate_added() {
		return date_added;
	}

	public void setDate_added(LocalDateTime date_added) {
		this.date_added = date_added;
	}

	public LocalDateTime getDate_updated() {
		return date_updated;
	}

	public void setDate_updated(LocalDateTime date_updated) {
		this.date_updated = date_updated;
	}

	public int getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(int is_deleted) {
		this.is_deleted = is_deleted;
	}

	@Override
	public String toString() {
		return "UnitDTO [unit_id=" + unit_id + ", unit_name=" + unit_name + ", date_added=" + date_added
				+ ", date_updated=" + date_updated + ", is_deleted=" + is_deleted + "]";
	}

	
	
    
    
}
