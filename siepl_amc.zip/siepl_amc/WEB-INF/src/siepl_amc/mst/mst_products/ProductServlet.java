package siepl_amc.mst.mst_products;

import java.io.IOException;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import siepl_amc.utility.LocalDateTimeTypeAdapter;

@WebServlet("/product")
public class ProductServlet extends HttpServlet {
    private final Gson gson;

    public ProductServlet() {
        this.gson = new GsonBuilder()
                .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeTypeAdapter())
                .create();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");

        String product_id = req.getParameter("product_id");

        if (product_id == null || product_id.isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\": \"product_id is required\"}");
            return;
        }

        try {
            int id = Integer.parseInt(product_id);
            ProductDAO productDAO = new ProductDAO();
            ProductDTO product = productDAO.getProductById(id);

            if (product != null) {
                String productJson = gson.toJson(product);
                resp.getWriter().write(productJson);
            } else {
                resp.getWriter().write("{}");
            }
        } catch (NumberFormatException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\": \"Invalid product_id\"}");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain"); // 

        String action = req.getParameter("action");
        String productId = req.getParameter("product_id");

        ProductDAO productDAO = new ProductDAO();
        ProductDTO productDTO = new ProductDTO();
        boolean status = false;

        try {
            if ("delete".equalsIgnoreCase(action) && productId != null && !productId.isEmpty()) {
                status = productDAO.deleteProduct(productId);

           } else {
                // For insert / update
                productDTO.setSerial_no(req.getParameter("serial_no"));
                productDTO.setCategory_id(Integer.parseInt(req.getParameter("category_id")));
                productDTO.setSubcategory_id(Integer.parseInt(req.getParameter("subcategory_id")));
                productDTO.setUnit_id(Integer.parseInt(req.getParameter("unit_id")));
                productDTO.setModel(req.getParameter("model"));
                productDTO.setDescription(req.getParameter("description"));
                productDTO.setIs_deleted(0);

                if ("update".equalsIgnoreCase(action) && productId != null && !productId.isEmpty()) {
                    productDTO.setProduct_id(Integer.parseInt(productId));
                    status = productDAO.updateProduct(productDTO);
                } else {
                    status = productDAO.insertProduct(productDTO);
                }
            }

            resp.getWriter().write(status ? "success" : "error");

        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().write("error");
        }
    }

}