package siepl_amc.mst.mst_products;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import siepl_amc.utility.DBConfig;


public class ProductDAO {

	public ProductDTO getProductById(int product_id) {
		// TODO Auto-generated method stub
		ProductDTO productDTO = null;
		String query = "SELECT p.product_id, p.serial_no, ctg.category_id , ctg.category_name, " +
						"sctg.subcategory_id, sctg.subcategory_name, p.model, p.description, " +
						"unit.unit_id, unit.unit_name, p.is_deleted " +
						"FROM siepl_amc_mst_products p " +
						"JOIN siepl_amc_mst_categories ctg ON ctg.category_id = p.category_id " +
						"JOIN siepl_amc_mst_subcategories sctg ON sctg.subcategory_id = p.subcategory_id " +
						"JOIN siepl_amc_mst_units unit ON unit.unit_id = p.unit_id " +
						"WHERE p.product_id = ? AND p.is_deleted = 0";
		try (Connection con = DBConfig.getConnection();
	             PreparedStatement ps = con.prepareStatement(query)){
			ps.setInt(1, product_id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
            	productDTO = new ProductDTO();
            	productDTO.setProduct_id(rs.getInt("product_id"));
                productDTO.setSerial_no(rs.getString("serial_no"));
                productDTO.setCategory_id(rs.getInt("category_id"));
                productDTO.setCategory_name(rs.getString("category_name"));
                productDTO.setSubcategory_id(rs.getInt("subcategory_id"));
                productDTO.setSubcategory_name(rs.getString("subcategory_name"));
                productDTO.setModel(rs.getString("model"));
                productDTO.setDescription(rs.getString("description"));
                productDTO.setUnit_id(rs.getInt("unit_id"));
                productDTO.setUnit_name(rs.getString("unit_name"));
            }
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return productDTO;
	}

	public boolean updateProduct(ProductDTO productDTO) {
	    String query = "UPDATE siepl_amc_mst_products SET " +
	                   "serial_no=?, category_id=?, subcategory_id=?, model=?, description=?, unit_id=?, " +
	                   "date_updated=NOW() " +
	                   "WHERE product_id=? AND is_deleted=0";
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(query)) {

	        ps.setString(1, productDTO.getSerial_no());
	        ps.setInt(2, productDTO.getCategory_id());
	        ps.setInt(3, productDTO.getSubcategory_id());
	        ps.setString(4, productDTO.getModel());
	        ps.setString(5, productDTO.getDescription());
	        ps.setInt(6, productDTO.getUnit_id());
	        ps.setInt(7, productDTO.getProduct_id());

	        return ps.executeUpdate() > 0;

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false;
	}

	public boolean deleteProduct(String product_id) {
	    String query = "UPDATE siepl_amc_mst_products SET is_deleted=1, date_updated=NOW() WHERE product_id=?";
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(query)) {

	        ps.setInt(1, Integer.parseInt(product_id));
	        return ps.executeUpdate() > 0;

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false;
	}

	public boolean insertProduct(ProductDTO productDTO) {
	    String query = "INSERT INTO siepl_amc_mst_products " +
	                   "(serial_no, category_id, subcategory_id, model, description, unit_id, date_added, is_deleted) " +
	                   "VALUES (?, ?, ?, ?, ?, ?, NOW(), 0)";
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(query)) {

	        ps.setString(1, productDTO.getSerial_no());
	        ps.setInt(2, productDTO.getCategory_id());
	        ps.setInt(3, productDTO.getSubcategory_id());
	        ps.setString(4, productDTO.getModel());
	        ps.setString(5, productDTO.getDescription());
	        ps.setInt(6, productDTO.getUnit_id());

	        return ps.executeUpdate() > 0;

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false;
	}


	public List<ProductDTO> getSearchedProducts(String query, Integer categoryId, Integer subcategoryId, Integer unitId, String sortColumn) {
	    List<ProductDTO> list = new ArrayList<>();
	    try {
	        String subQuery = "";

	        if (query != null && !"".equals(query.trim())) {
	            // simple single-quote escape to avoid SQL error when user types '
	            String q = query.trim().replace("'", "''");
	            subQuery += " AND (p.serial_no LIKE '%" + q + "%' " +
	                        "OR p.model LIKE '%" + q + "%' " +
	                        "OR p.description LIKE '%" + q + "%' " +
	                        "OR ctg.category_name LIKE '%" + q + "%' " +
	                        "OR sctg.subcategory_name LIKE '%" + q + "%' " +
	                        "OR unit.unit_name LIKE '%" + q + "%') ";
	        }

	        // Only add filter when value is provided and greater than 0
	        if (categoryId != null && categoryId > 0) {
	            subQuery += " AND ctg.category_id = " + categoryId;
	        }

	        if (subcategoryId != null && subcategoryId > 0) {
	            subQuery += " AND sctg.subcategory_id = " + subcategoryId;
	        }

	        if (unitId != null && unitId > 0) {
	            subQuery += " AND unit.unit_id = " + unitId;
	        }

	        if (sortColumn == null || sortColumn.isEmpty()) {
	            sortColumn = "p.product_id";
	        }

	        String sql = "SELECT p.product_id, p.serial_no, ctg.category_id , ctg.category_name, " +
	                     "sctg.subcategory_id, sctg.subcategory_name, p.model, p.description, " +
	                     "unit.unit_id, unit.unit_name, p.is_deleted " +
	                     "FROM siepl_amc_mst_products p " +
	                     "JOIN siepl_amc_mst_categories ctg ON ctg.category_id = p.category_id " +
	                     "JOIN siepl_amc_mst_subcategories sctg ON sctg.subcategory_id = p.subcategory_id " +
	                     "JOIN siepl_amc_mst_units unit ON unit.unit_id = p.unit_id " +
	                     "WHERE 1=1 AND p.is_deleted = 0 " + subQuery +
	                     " ORDER BY " + sortColumn + " ASC";

	        try (Connection con = DBConfig.getConnection();
	             PreparedStatement ps = con.prepareStatement(sql)) {

	            ResultSet rs = ps.executeQuery();
	            while (rs.next()) {
	                ProductDTO dto = new ProductDTO();
	                dto.setProduct_id(rs.getInt("product_id"));
	                dto.setSerial_no(rs.getString("serial_no"));
	                dto.setCategory_id(rs.getInt("category_id"));
	                dto.setCategory_name(rs.getString("category_name"));
	                dto.setSubcategory_id(rs.getInt("subcategory_id"));
	                dto.setSubcategory_name(rs.getString("subcategory_name"));
	                dto.setModel(rs.getString("model"));
	                dto.setDescription(rs.getString("description"));
	                dto.setUnit_id(rs.getInt("unit_id"));
	                dto.setUnit_name(rs.getString("unit_name"));
	                list.add(dto);
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return list;
	}

}
