package siepl_amc.mst.mst_products;

import java.time.LocalDateTime;

public class ProductDTO {

    private int product_id;
    private String serial_no;
    private int category_id;       // FK → Categories
    private String category_name;
    private int subcategory_id; 
    private String subcategory_name;// FK → Subcategories
    private String model;
    private String description;
    private int unit_id;           // FK → Units
    private String unit_name;
    private LocalDateTime date_added;
    private LocalDateTime date_updated;
    private int is_deleted; 
	public ProductDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductDTO(int product_id, String serial_no, int category_id, String category_name, int subcategory_id,
			String subcategory_name, String model, String description, int unit_id, String unit_name,
			LocalDateTime date_added, LocalDateTime date_updated, int is_deleted) {
		super();
		this.product_id = product_id;
		this.serial_no = serial_no;
		this.category_id = category_id;
		this.category_name = category_name;
		this.subcategory_id = subcategory_id;
		this.subcategory_name = subcategory_name;
		this.model = model;
		this.description = description;
		this.unit_id = unit_id;
		this.unit_name = unit_name;
		this.date_added = date_added;
		this.date_updated = date_updated;
		this.is_deleted = is_deleted;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getSerial_no() {
		return serial_no;
	}
	public void setSerial_no(String serial_no) {
		this.serial_no = serial_no;
	}
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	public int getSubcategory_id() {
		return subcategory_id;
	}
	public void setSubcategory_id(int subcategory_id) {
		this.subcategory_id = subcategory_id;
	}
	public String getSubcategory_name() {
		return subcategory_name;
	}
	public void setSubcategory_name(String subcategory_name) {
		this.subcategory_name = subcategory_name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getUnit_id() {
		return unit_id;
	}
	public void setUnit_id(int unit_id) {
		this.unit_id = unit_id;
	}
	public String getUnit_name() {
		return unit_name;
	}
	public void setUnit_name(String unit_name) {
		this.unit_name = unit_name;
	}
	public LocalDateTime getDate_added() {
		return date_added;
	}
	public void setDate_added(LocalDateTime date_added) {
		this.date_added = date_added;
	}
	public LocalDateTime getDate_updated() {
		return date_updated;
	}
	public void setDate_updated(LocalDateTime date_updated) {
		this.date_updated = date_updated;
	}
	public int getIs_deleted() {
		return is_deleted;
	}
	public void setIs_deleted(int is_deleted) {
		this.is_deleted = is_deleted;
	}
	@Override
	public String toString() {
		return "ProductDTO [product_id=" + product_id + ", serial_no=" + serial_no + ", category_id=" + category_id
				+ ", category_name=" + category_name + ", subcategory_id=" + subcategory_id + ", subcategory_name="
				+ subcategory_name + ", model=" + model + ", description=" + description + ", unit_id=" + unit_id
				+ ", unit_name=" + unit_name + ", date_added=" + date_added + ", date_updated=" + date_updated
				+ ", is_deleted=" + is_deleted + "]";
	}
}
