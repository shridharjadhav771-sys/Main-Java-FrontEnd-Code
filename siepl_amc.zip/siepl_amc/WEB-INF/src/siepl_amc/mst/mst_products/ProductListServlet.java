package siepl_amc.mst.mst_products;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import siepl_amc.utility.LocalDateTimeTypeAdapter;

@WebServlet("/productList")
public class ProductListServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String query = req.getParameter("query") != null ? req.getParameter("query").trim() : "";

        Integer categoryId = req.getParameter("category_id") != null && !req.getParameter("category_id").isEmpty()? Integer.parseInt(req.getParameter("category_id")) : null;

        Integer subcategoryId = req.getParameter("subcategory_id") != null && !req.getParameter("subcategory_id").isEmpty()
                                ? Integer.parseInt(req.getParameter("subcategory_id")) : null;

        Integer unitId = req.getParameter("unit_id") != null && !req.getParameter("unit_id").isEmpty()
                         ? Integer.parseInt(req.getParameter("unit_id")) : null;

        String sortColumn = req.getParameter("sortColumn") != null && !req.getParameter("sortColumn").isEmpty() 
                            ? req.getParameter("sortColumn") : "p.product_id";

        ProductDAO productDAO = new ProductDAO();
        List<ProductDTO> products = productDAO.getSearchedProducts(query, categoryId, subcategoryId, unitId, sortColumn);

        Gson gson = new GsonBuilder()
                .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeTypeAdapter())
                .create();

        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(gson.toJson(products));
    }
}
