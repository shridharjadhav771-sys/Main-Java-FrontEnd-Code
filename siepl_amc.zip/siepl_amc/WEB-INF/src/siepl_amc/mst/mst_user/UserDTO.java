package siepl_amc.mst.mst_user;

import java.time.LocalDateTime;

public class UserDTO {

    private Integer userId;
    private String fullName;
    private String username;
    private String passwordHash;
    private LocalDateTime dateAdded;
    private LocalDateTime dateUpdated;
    private Boolean isDeleted;

    // Constructors
    public UserDTO() {
    }

    public UserDTO(Integer userId, String fullName, String username,
                   String passwordHash, LocalDateTime dateAdded,
                   LocalDateTime dateUpdated, Boolean isDeleted) {
        this.userId = userId;
        this.fullName = fullName;
        this.username = username;
        this.passwordHash = passwordHash;
        this.dateAdded = dateAdded;
        this.dateUpdated = dateUpdated;
        this.isDeleted = isDeleted;
    }

    // Getters and Setters
    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public LocalDateTime getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(LocalDateTime dateAdded) {
        this.dateAdded = dateAdded;
    }

    public LocalDateTime getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(LocalDateTime dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public String toString() {
        return "UserDTO{" +
                "userId=" + userId +
                ", fullName='" + fullName + '\'' +
                ", username='" + username + '\'' +
                ", passwordHash='" + passwordHash + '\'' +
                ", dateAdded=" + dateAdded +
                ", dateUpdated=" + dateUpdated +
                ", isDeleted=" + isDeleted +
                '}';
    }
}
