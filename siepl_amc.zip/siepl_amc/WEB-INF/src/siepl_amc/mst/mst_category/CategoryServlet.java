package siepl_amc.mst.mst_category;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import siepl_amc.utility.LocalDateTimeTypeAdapter;

@WebServlet("/category")
public class CategoryServlet extends HttpServlet {
    private final Gson gson;

    public CategoryServlet() {
        this.gson = new GsonBuilder()
                .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeTypeAdapter())
                .create();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");

        String action = req.getParameter("action");
        String categoryId = req.getParameter("category_id");

        CategoryDAO categoryDAO = new CategoryDAO();

        if ("list".equalsIgnoreCase(action)) {
            // fetch all categories
            String query = req.getParameter("query") == null ? "" : req.getParameter("query").trim();
            List<CategoryDTO> categories = categoryDAO.getAllCategories(query);

            String categoriesJson = gson.toJson(categories);
            resp.getWriter().write(categoriesJson);

        } else if (categoryId != null && !categoryId.isEmpty()) {
            // fetch single category by ID
            CategoryDTO category = categoryDAO.getCategoryById(Integer.parseInt(categoryId));

            if (category != null) {
                String categoryJson = gson.toJson(category);
                resp.getWriter().write(categoryJson);
            } else {
                resp.getWriter().write("{}"); // not found
            }

        } else {
            // no action / no category_id
            resp.getWriter().write("{}");
        }
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain");

        String action = req.getParameter("action");
        String category_id = req.getParameter("category_id");

        CategoryDTO categoryDTO = new CategoryDTO();
        if (!"delete".equals(action)) {
            categoryDTO.setCategory_name(req.getParameter("category_name"));
            categoryDTO.setIs_deleted(req.getParameter("isDeleted") == null ? 0 : Integer.parseInt(req.getParameter("isDeleted")));
        }

        CategoryDAO categoryDAO = new CategoryDAO();
        boolean status = false;

        if ("update".equals(action)) {
            categoryDTO.setCategory_id(Integer.parseInt(category_id));
            status = categoryDAO.updateCategory(categoryDTO);
        } else if ("delete".equals(action)) {
            status = categoryDAO.deleteCategory(Integer.parseInt(category_id));
        } else {
            status = categoryDAO.insertCategory(categoryDTO);
        }

        if (status) {
            resp.getWriter().write("success");
        } else {
            resp.getWriter().write("failure");
        }
    }
}
