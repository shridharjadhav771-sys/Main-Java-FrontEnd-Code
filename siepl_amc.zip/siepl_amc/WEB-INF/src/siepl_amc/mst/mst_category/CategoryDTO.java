package siepl_amc.mst.mst_category;

import java.time.LocalDateTime;

public class CategoryDTO {

    private Integer category_id;
    private String category_name;
    private LocalDateTime date_added;
    private LocalDateTime date_updated;
    private int is_deleted;   // <-- changed from Boolean to int

    // Constructors
    public CategoryDTO() {
    }

    public CategoryDTO(Integer category_id, String category_name,
                       LocalDateTime date_added, LocalDateTime date_updated,
                       int is_deleted) {
        this.category_id = category_id;
        this.category_name = category_name;
        this.date_added = date_added;
        this.date_updated = date_updated;
        this.is_deleted = is_deleted;
    }

    // Getters and Setters
    public Integer getCategory_id() {
        return category_id;
    }

    public void setCategory_id(Integer category_id) {
        this.category_id = category_id;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    public LocalDateTime getDate_added() {
        return date_added;
    }

    public void setDate_added(LocalDateTime date_added) {
        this.date_added = date_added;
    }

    public LocalDateTime getDate_updated() {
        return date_updated;
    }

    public void setDate_updated(LocalDateTime date_updated) {
        this.date_updated = date_updated;
    }

    public int getIs_deleted() {
        return is_deleted;
    }

    public void setIs_deleted(int is_deleted) {
        this.is_deleted = is_deleted;
    }

    @Override
    public String toString() {
        return "CategoryDTO{" +
                "category_id=" + category_id +
                ", category_name='" + category_name + '\'' +
                ", date_added=" + date_added +
                ", date_updated=" + date_updated +
                ", is_deleted=" + is_deleted +
                '}';
    }
}
