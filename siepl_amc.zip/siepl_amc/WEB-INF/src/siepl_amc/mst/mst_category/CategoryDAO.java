package siepl_amc.mst.mst_category;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import siepl_amc.utility.DBConfig;

public class CategoryDAO {

	public boolean insertCategory(CategoryDTO categoryDTO) {
		// TODO Auto-generated method stub
		String query = "insert into siepl_amc_mst_categories (category_name, date_added) values (?, NOW())";
		 try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			 ps.setString(1, categoryDTO.getCategory_name());
			 return ps.executeUpdate() > 0;
		 }catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
				 
		return false;
	}

	

	public CategoryDTO getCategoryById(int categoryId) {
		// TODO Auto-generated method stub
		CategoryDTO categoryDTO = new CategoryDTO();
		String query = "select * from siepl_amc_mst_categories where category_id = ? and is_deleted = 0";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setInt(1, categoryId);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				categoryDTO.setCategory_id(rs.getInt("category_id"));
				categoryDTO.setCategory_name(rs.getString("category_name"));
				categoryDTO.setDate_added(rs.getTimestamp("date_added").toLocalDateTime());
				categoryDTO.setDate_updated(rs.getTimestamp("date_updated").toLocalDateTime());
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return categoryDTO;
	}



	public boolean updateCategory(CategoryDTO categoryDTO) {
		// TODO Auto-generated method stub
		String query = "update siepl_amc_mst_categories set category_name = ? where category_id =?";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setString(1, categoryDTO.getCategory_name());
			ps.setInt(2, categoryDTO.getCategory_id());
			return ps.executeUpdate() > 0;
		}catch (Exception e) {
			// TODO: handle exception 
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return false;
	}



	public boolean deleteCategory(int category_id) {
		// TODO Auto-generated method stub
		String query = "update siepl_amc_mst_categories set is_deleted = 1 where category_id = ?";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setInt(1, category_id);
			return ps.executeUpdate() > 0;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
		return false;
	}



	public List<CategoryDTO> getAllCategories(String query) {
	    List<CategoryDTO> list = new ArrayList<>();
	    try {
	        String sql = "SELECT * FROM siepl_amc_mst_categories WHERE is_deleted = 0";

	        if (query != null && !query.trim().isEmpty()) {
	            sql += " AND category_name LIKE ?";
	        }
	        

	        try (Connection con = DBConfig.getConnection();
	             PreparedStatement ps = con.prepareStatement(sql)) {

	            if (query != null && !query.trim().isEmpty()) {
	                ps.setString(1, "%" + query + "%");
	            }

	            ResultSet rs = ps.executeQuery();
	
	            while (rs.next()) {
	                CategoryDTO categoryDTO = new CategoryDTO();
	                categoryDTO.setCategory_id(rs.getInt("category_id"));
	                categoryDTO.setCategory_name(rs.getString("category_name"));
	                categoryDTO.setDate_added(rs.getTimestamp("date_added").toLocalDateTime());
	                categoryDTO.setDate_updated(rs.getTimestamp("date_updated").toLocalDateTime());

	                list.add(categoryDTO);
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        System.out.println("Error in getAllCategories: " + e.getMessage());
	    }
	    return list;
	}

	

}
