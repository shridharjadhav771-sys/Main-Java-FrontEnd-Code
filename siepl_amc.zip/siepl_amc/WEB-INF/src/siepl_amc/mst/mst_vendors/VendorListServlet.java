package siepl_amc.mst.mst_vendors;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import siepl_amc.utility.LocalDateTimeTypeAdapter;

@WebServlet("/vendorList")
public class VendorListServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String query = req.getParameter("query") == null ? "" : req.getParameter("query").trim();
		
		VendorDAO vendorDAO = new VendorDAO();
		List<VendorDTO> vendors = vendorDAO.getAllVendors(query);
		
		Gson gson = new GsonBuilder()
                .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeTypeAdapter())
                .create();

            resp.setContentType("application/json");
            resp.setCharacterEncoding("UTF-8");
            resp.getWriter().write(gson.toJson(vendors));
	}
	
}
