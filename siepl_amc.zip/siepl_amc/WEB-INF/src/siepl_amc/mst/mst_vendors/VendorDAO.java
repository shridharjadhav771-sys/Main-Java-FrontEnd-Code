package siepl_amc.mst.mst_vendors;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import siepl_amc.utility.DBConfig;

public class VendorDAO {

	public VendorDTO getVendorById(int vendor_id) {
		// TODO Auto-generated method stub
		VendorDTO vendorDTO = new VendorDTO();
		String query = "select * from siepl_amc_mst_vendors where vendor_id = ? and is_deleted = 0";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setInt(1, vendor_id);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				vendorDTO.setVendor_id(rs.getInt("vendor_id"));
				vendorDTO.setVendor_name(rs.getString("vendor_name"));
				vendorDTO.setDate_added(rs.getTimestamp("date_added").toLocalDateTime());
				vendorDTO.setDate_updated(rs.getTimestamp("date_updated").toLocalDateTime());
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return vendorDTO;
	}

	public boolean updateVendor(VendorDTO vendorDTO) {
		// TODO Auto-generated method stub
		String query = "update siepl_amc_mst_vendors set vendor_name = ?, date_updated=NOW() where vendor_id =?";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setString(1, vendorDTO.getVendor_name());
			ps.setInt(2, vendorDTO.getVendor_id());
			return ps.executeUpdate() > 0;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return false;
	}

	public boolean deleteVendor(int vendor_id) {
		// TODO Auto-generated method stub
		String query = "update siepl_amc_mst_vendors set is_deleted = 1 where vendor_id =?";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setInt(1, vendor_id);
			return ps.executeUpdate() > 0;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
		return false;
	}

	public boolean insertVendor(VendorDTO vendorDTO) {
		String query = "insert into siepl_amc_mst_vendors (vendor_name, date_added) values (?, NOW())";
		 try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			 ps.setString(1, vendorDTO.getVendor_name());
			 return ps.executeUpdate() > 0;
		 }catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
				 
		return false;
	}

	public List<VendorDTO> getAllVendors(String query) {
		// TODO Auto-generated method stub
		List<VendorDTO> list = new ArrayList<>();
	    try {
	        String sql = "SELECT * FROM siepl_amc_mst_vendors WHERE is_deleted = 0";

	        if (query != null && !query.trim().isEmpty()) {
	            sql += " AND vendor_name LIKE ?";
	        }
	        

	        try (Connection con = DBConfig.getConnection();
	             PreparedStatement ps = con.prepareStatement(sql)) {

	            if (query != null && !query.trim().isEmpty()) {
	                ps.setString(1, "%" + query + "%");
	            }

	            ResultSet rs = ps.executeQuery();
	            while (rs.next()) {
	                VendorDTO vendorDTO = new VendorDTO();
	                vendorDTO.setVendor_id(rs.getInt("vendor_id"));
					vendorDTO.setVendor_name(rs.getString("vendor_name"));
					vendorDTO.setDate_added(rs.getTimestamp("date_added").toLocalDateTime());
					vendorDTO.setDate_updated(rs.getTimestamp("date_updated").toLocalDateTime());

	                list.add(vendorDTO);
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        System.out.println("Error in getAllVendors: " + e.getMessage());
	    }
	    return list;
	}

}
