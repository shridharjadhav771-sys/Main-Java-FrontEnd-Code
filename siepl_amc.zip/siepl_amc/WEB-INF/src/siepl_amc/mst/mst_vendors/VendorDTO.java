package siepl_amc.mst.mst_vendors;

import java.time.LocalDateTime;

public class VendorDTO {

    private int vendor_id;
    private String vendor_name;
    private LocalDateTime date_added;
    private LocalDateTime date_updated;
    private int is_deleted; // strictly int

    // Constructors
    public VendorDTO() {
    }

    public VendorDTO(int vendor_id, String vendor_name, LocalDateTime date_added,
                     LocalDateTime date_updated, int is_deleted) {
        this.vendor_id = vendor_id;
        this.vendor_name = vendor_name;
        this.date_added = date_added;
        this.date_updated = date_updated;
        this.is_deleted = is_deleted;
    }

    // Getters and Setters
    public int getVendor_id() {
        return vendor_id;
    }

    public void setVendor_id(int vendor_id) {
        this.vendor_id = vendor_id;
    }

    public String getVendor_name() {
        return vendor_name;
    }

    public void setVendor_name(String vendor_name) {
        this.vendor_name = vendor_name;
    }

    public LocalDateTime getDate_added() {
        return date_added;
    }

    public void setDate_added(LocalDateTime date_added) {
        this.date_added = date_added;
    }

    public LocalDateTime getDate_updated() {
        return date_updated;
    }

    public void setDate_updated(LocalDateTime date_updated) {
        this.date_updated = date_updated;
    }

    public int getIs_deleted() {
        return is_deleted;
    }

    public void setIs_deleted(int is_deleted) {
        this.is_deleted = is_deleted;
    }

    @Override
    public String toString() {
        return "VendorDTO{" +
                "vendor_id=" + vendor_id +
                ", vendor_name='" + vendor_name + '\'' +
                ", date_added=" + date_added +
                ", date_updated=" + date_updated +
                ", is_deleted=" + is_deleted +
                '}';
    }
}
