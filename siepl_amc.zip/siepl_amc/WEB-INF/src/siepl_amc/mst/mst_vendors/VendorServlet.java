package siepl_amc.mst.mst_vendors;

import java.io.IOException;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import siepl_amc.utility.LocalDateTimeTypeAdapter;

@WebServlet("/vendor")
public class VendorServlet extends HttpServlet{
	private final Gson gson;

    public VendorServlet() {
        this.gson = new GsonBuilder()
                .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeTypeAdapter())
                .create();
    }
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        
        String vendorId = req.getParameter("vendor_id");
        if(vendorId != null && !vendorId.isEmpty()) {
        	VendorDAO vendorDAO = new VendorDAO();
        	VendorDTO vendor = vendorDAO.getVendorById(Integer.parseInt(vendorId));
        	
        	if(vendor != null) {
        		String vendorJson = gson.toJson(vendor);
                resp.getWriter().write(vendorJson);
        	}else {
                resp.getWriter().write("{}"); // empty JSON if not found
            }
        }else {
            resp.getWriter().write("{}");
        }
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain");
		
        String action = req.getParameter("action");
        String vendor_id = req.getParameter("vendor_id");
        
        VendorDTO vendorDTO = new VendorDTO();
        if (!"delete".equals(action)) {
        	vendorDTO.setVendor_name(req.getParameter("vendor_name"));
        	vendorDTO.setIs_deleted(req.getParameter("isDeleted") == null ? 0 : Integer.parseInt(req.getParameter("isDeleted")));
        }
        
        VendorDAO vendorDAO = new VendorDAO();
        boolean status = false;
        
        if ("update".equals(action)) {
        	vendorDTO.setVendor_id(Integer.parseInt(vendor_id));
        	status = vendorDAO.updateVendor(vendorDTO);
        }else if ("delete".equals(action)) {
            status = vendorDAO.deleteVendor(Integer.parseInt(vendor_id));
        } else {
            status = vendorDAO.insertVendor(vendorDTO);
        }
        
        if (status) {
            resp.getWriter().write("success");
        } else {
            resp.getWriter().write("failure");
        }
	}
}
