package siepl_amc.mst.mst_customers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/customerContact")
public class CustomerContactServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String contact_no = req.getParameter("ContactVal");
		System.out.println("Contact: "+contact_no);
		
		CustomerDAO customerDAO = new CustomerDAO();
		
		if(customerDAO.checkContact(contact_no)) {
			resp.setContentType("text/plain");
			resp.getWriter().write("exist");
		}else {
			resp.setContentType("text/plain");
			resp.getWriter().write("Does not exist.");
		}
	}
}