package siepl_amc.mst.mst_customers;

import java.time.LocalDateTime;

public class CustomerDTO {

    private int customer_id;
    private String customer_name;
    private String organization;
    private String contact_no;
    private String email;
    private String address;
    private LocalDateTime date_added;
    private LocalDateTime date_updated;
    private int is_deleted; 

    // Constructors
    public CustomerDTO() {
    }

    public CustomerDTO(int customer_id, String customer_name, String organization,
                       String contact_no, String email, String address,
                       LocalDateTime date_added, LocalDateTime date_updated,
                       int is_deleted) {
        this.customer_id = customer_id;
        this.customer_name = customer_name;
        this.organization = organization;
        this.contact_no = contact_no;
        this.email = email;
        this.address = address;
        this.date_added = date_added;
        this.date_updated = date_updated;
        this.is_deleted = is_deleted;
    }

    // Getters and Setters
    public int getCustomer_id() {
        return customer_id;
    }

    public void setCustomer_id(int customer_id) {
        this.customer_id = customer_id;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getContact_no() {
        return contact_no;
    }

    public void setContact_no(String contact_no) {
        this.contact_no = contact_no;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public LocalDateTime getDate_added() {
        return date_added;
    }

    public void setDate_added(LocalDateTime date_added) {
        this.date_added = date_added;
    }

    public LocalDateTime getDate_updated() {
        return date_updated;
    }

    public void setDate_updated(LocalDateTime date_updated) {
        this.date_updated = date_updated;
    }

    public int getIs_deleted() {
        return is_deleted;
    }

    public void setIs_deleted(int is_deleted) {
        this.is_deleted = is_deleted;
    }

    @Override
    public String toString() {
        return "CustomerDTO{" +
                "customer_id=" + customer_id +
                ", customer_name='" + customer_name + '\'' +
                ", organization='" + organization + '\'' +
                ", contact_no='" + contact_no + '\'' +
                ", email='" + email + '\'' +
                ", address='" + address + '\'' +
                ", date_added=" + date_added +
                ", date_updated=" + date_updated +
                ", is_deleted=" + is_deleted +
                '}';
    }
}
