package siepl_amc.mst.mst_customers;

import java.io.IOException;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import siepl_amc.utility.LocalDateTimeTypeAdapter;

@WebServlet("/customer")
public class CustomerServlet extends HttpServlet{
	private final Gson gson;

    public CustomerServlet() {
        this.gson = new GsonBuilder()
                .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeTypeAdapter())
                .create();
    }
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        
		String customerId = req.getParameter("customer_id");
		if(customerId != null && !customerId.isEmpty()) {
			CustomerDAO customerDAO = new CustomerDAO();
			CustomerDTO customer = customerDAO.getCustomerById(Integer.parseInt(customerId));
			
			if(customer != null) {
				String customerJson = gson.toJson(customer);
				resp.getWriter().write(customerJson);
			}else {
				resp.getWriter().write("{}");
			}
		}else {
			resp.getWriter().write("{}");
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain");
        
        String action =req.getParameter("action");
        String customerId = req.getParameter("customer_id");
        
        
        CustomerDTO customerDTO = new CustomerDTO();
        if(!"delete".equals(action)) {
        	
        	String customerName = req.getParameter("customer_name");
            String organization = req.getParameter("organization");
            String contact_no = req.getParameter("contact_no");
            String email = req.getParameter("email");
            String address = req.getParameter("address");
            
        	customerDTO.setCustomer_name(customerName);
        	customerDTO.setOrganization(organization);
        	customerDTO.setContact_no(contact_no);
        	customerDTO.setEmail(email);
        	customerDTO.setAddress(address);
        	customerDTO.setIs_deleted(0);
        }
        
        CustomerDAO customerDAO = new CustomerDAO();
        boolean status;
        
        if ("update".equals(action) && customerId != null && !customerId.isEmpty()) {
        	customerDTO.setCustomer_id(Integer.parseInt(customerId));
			status = customerDAO.updateCustomer(customerDTO); // Call update method
		} else if ("delete".equals(action) && customerId != null && !customerId.isEmpty()) {
			status = customerDAO.deleteCustomer(Integer.parseInt(customerId));
		} else {
			status = customerDAO.insertCustomer(customerDTO); // Call insert method
		}
        
        resp.setContentType("application/plain");
		if (status)
			resp.getWriter().write("success");
		else
			resp.getWriter().write("failure");
        
	}
}
