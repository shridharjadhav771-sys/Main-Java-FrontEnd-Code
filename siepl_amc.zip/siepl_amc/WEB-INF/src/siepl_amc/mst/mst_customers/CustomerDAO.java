package siepl_amc.mst.mst_customers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import siepl_amc.utility.DBConfig;

public class CustomerDAO {

	public CustomerDTO getCustomerById(int customer_id) {
		// TODO Auto-generated method stub
		CustomerDTO customerDTO = new CustomerDTO();
		String query = "select * from siepl_amc_mst_customers where customer_id = ? and is_deleted = 0";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setInt(1, customer_id);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				customerDTO.setCustomer_id(rs.getInt("customer_id"));
				customerDTO.setCustomer_name(rs.getString("customer_name"));
				customerDTO.setOrganization(rs.getString("organization"));
				customerDTO.setContact_no(rs.getString("contact_no"));
				customerDTO.setEmail(rs.getString("email"));
				customerDTO.setAddress(rs.getString("address"));
				customerDTO.setDate_added(rs.getTimestamp("date_added").toLocalDateTime());
				customerDTO.setDate_updated(rs.getTimestamp("date_updated").toLocalDateTime());
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return customerDTO;
	}

	public boolean updateCustomer(CustomerDTO customerDTO) {
		// TODO Auto-generated method stub
		String query = "update siepl_amc_mst_customers set customer_name = ?, organization = ?, contact_no = ?, email = ?, address = ? where customer_id = ?";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setString(1, customerDTO.getCustomer_name());
			ps.setString(2, customerDTO.getOrganization());
			ps.setString(3, customerDTO.getContact_no());
			ps.setString(4, customerDTO.getEmail());
			ps.setString(5, customerDTO.getAddress());
			ps.setInt(6, customerDTO.getCustomer_id());
			int rowsAffected = ps.executeUpdate(); 
	        return rowsAffected > 0;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		} 
		return false;
	}

	public boolean deleteCustomer(int customer_id) {
		// TODO Auto-generated method stub
		String query = "update siepl_amc_mst_customers set is_deleted = 1 where customer_id = ?";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setInt(1, customer_id); 
			int rowsAffected = ps.executeUpdate(); 
	        return rowsAffected > 0;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return false;
	}

	public boolean insertCustomer(CustomerDTO customerDTO) {
		// TODO Auto-generated method stub
		String query = "insert into siepl_amc_mst_customers (customer_name, organization, contact_no, email, address) values (?, ?, ?, ?, ?)";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setString(1, customerDTO.getCustomer_name());
			ps.setString(2, customerDTO.getOrganization());
			ps.setString(3, customerDTO.getContact_no());
			ps.setString(4, customerDTO.getEmail());
			ps.setString(5, customerDTO.getAddress());
			int rowsAffected = ps.executeUpdate(); // Execute the INSERT query
	        return rowsAffected > 0;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return false;
	}

	public List<CustomerDTO> getAllCustomers(String query) {
		// TODO Auto-generated method stub
		List<CustomerDTO> list = new ArrayList<>();
		try {
			String sql = "SELECT * FROM siepl_amc_mst_customers WHERE is_deleted = 0";
			
			if (query != null && !query.trim().isEmpty()) {
				sql += " AND customer_name LIKE ?";

	        }
			
			try (Connection con = DBConfig.getConnection();
			         PreparedStatement ps = con.prepareStatement(sql)){
				if (query != null && !query.trim().isEmpty()) {
	                ps.setString(1, "%" + query + "%");
	            }
				
				ResultSet rs = ps.executeQuery();
				while(rs.next()) {
					CustomerDTO customerDTO = new CustomerDTO();
					customerDTO.setCustomer_id(rs.getInt("customer_id"));
					customerDTO.setCustomer_name(rs.getString("customer_name"));
					customerDTO.setOrganization(rs.getString("organization"));
					customerDTO.setContact_no(rs.getString("contact_no"));
					customerDTO.setEmail(rs.getString("email"));
					customerDTO.setAddress(rs.getString("address"));
					customerDTO.setDate_added(rs.getTimestamp("date_added").toLocalDateTime());
					customerDTO.setDate_updated(rs.getTimestamp("date_updated").toLocalDateTime());
					
					list.add(customerDTO);
				}
			}
			
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return list;
	}

	

public boolean checkContact(String contact_no) {
	String sql = "select contact_no from siepl_amc_mst_customers where contact_no = '" + contact_no + "' ";
	System.out.println(sql);
	try (Connection con = DBConfig.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {
           if (rs.next()) {
               return true;
           }
       } catch (Exception e) {
           e.printStackTrace();
       }
	return false;
}

}
