package siepl_amc.mst.mst_subcategory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import siepl_amc.utility.DBConfig;

public class SubcategoryDAO {

	// Fetch subcategory by ID
	public SubcategoryDTO getSubcategoryById(int subcategory_id) {
        SubcategoryDTO subcategoryDTO = new SubcategoryDTO();

	    String sql = "SELECT * FROM siepl_amc_mst_subcategories WHERE subcategory_id = ? AND is_deleted = 0";
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {
	        
	        ps.setInt(1, subcategory_id);
	        try (ResultSet rs = ps.executeQuery()) {
	            if (rs.next()) {
	                subcategoryDTO.setSubcategory_id(rs.getInt("subcategory_id"));
	                subcategoryDTO.setCategory_id(rs.getInt("category_id"));
	                subcategoryDTO.setSubcategory_name(rs.getString("subcategory_name"));
	                subcategoryDTO.setDate_added(rs.getTimestamp("date_added").toLocalDateTime());
	                subcategoryDTO.setDate_updated(rs.getTimestamp("date_updated").toLocalDateTime());
	                return subcategoryDTO;
	            }
	        }
	    } catch (Exception e) { 
	        e.printStackTrace();
	    }
	    return subcategoryDTO;
	}

	// Insert new subcategory
	public boolean insertSubcategory(SubcategoryDTO subcategoryDTO) {
	    String sql = "INSERT INTO siepl_amc_mst_subcategories (category_id, subcategory_name, date_added) " +
	                 "VALUES (?, ?, NOW())";
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {
	        
	        ps.setInt(1, subcategoryDTO.getCategory_id());
	        ps.setString(2, subcategoryDTO.getSubcategory_name());

	        return ps.executeUpdate() > 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false;
	}

	// Update subcategory
	public boolean updateSubcategory(SubcategoryDTO subcategoryDTO) {
	    String sql = "UPDATE siepl_amc_mst_subcategories SET category_id = ?, subcategory_name = ?  WHERE subcategory_id = ?";
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {
	        
	        ps.setInt(1, subcategoryDTO.getCategory_id());
	        ps.setString(2, subcategoryDTO.getSubcategory_name());
	        ps.setInt(3, subcategoryDTO.getSubcategory_id());

	        return ps.executeUpdate() > 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false;
	}

	// Delete subcategory (soft delete)
	public boolean deleteSubcategory(int subcategory_id) {
	    String sql = "UPDATE siepl_amc_mst_subcategories SET is_deleted = 1 WHERE subcategory_id = ?";
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {
	        
	        ps.setInt(1, subcategory_id);

	        return ps.executeUpdate() > 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false;
	}

	public List<SubcategoryDTO> getAllSubcategories(String query) {
		// TODO Auto-generated method stub
		List<SubcategoryDTO> list = new ArrayList<>();
		try {
			String sql = "SELECT * FROM siepl_amc_mst_subcategories WHERE is_deleted = 0";

	        if (query != null && !query.trim().isEmpty()) {
	            sql += " AND category_name LIKE ?";
	        }
	        try (Connection con = DBConfig.getConnection();
		             PreparedStatement ps = con.prepareStatement(sql)) {

		            if (query != null && !query.trim().isEmpty()) {
		                ps.setString(1, "%" + query + "%");
		            }
		            ResultSet rs = ps.executeQuery();
		            
		            while(rs.next()) {
		                SubcategoryDTO subcategoryDTO = new SubcategoryDTO();
		            	subcategoryDTO.setSubcategory_id(rs.getInt("subcategory_id"));
		                subcategoryDTO.setCategory_id(rs.getInt("category_id"));
		                subcategoryDTO.setSubcategory_name(rs.getString("subcategory_name"));
		                subcategoryDTO.setDate_added(rs.getTimestamp("date_added").toLocalDateTime());
		                subcategoryDTO.setDate_updated(rs.getTimestamp("date_updated").toLocalDateTime());
		                list.add(subcategoryDTO);
		            }
	        }
		}catch (Exception e) {
			// TODO: handle exception
			 e.printStackTrace();
		}
		return list;
	}

	public List<SubcategoryDTO> getSubcategoriesByCategory(int categoryId) {
	    List<SubcategoryDTO> list = new ArrayList<>();
	    String sql = "SELECT * FROM siepl_amc_mst_subcategories WHERE category_id = ?";
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {
	        ps.setInt(1, categoryId); 
	        try (ResultSet rs = ps.executeQuery()) {
	            while (rs.next()) {
	            	SubcategoryDTO sucategoryDTO = new SubcategoryDTO();
	                sucategoryDTO.setSubcategory_id(rs.getInt("subcategory_id"));
	                sucategoryDTO.setSubcategory_name(rs.getString("subcategory_name"));
	                sucategoryDTO.setCategory_id(rs.getInt("category_id"));
	                list.add(sucategoryDTO);
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return list;
	}

}
