package siepl_amc.mst.mst_subcategory;

import java.time.LocalDateTime;

public class SubcategoryDTO {

    private int subcategory_id;
    private int category_id;   // FK to Category
    private String subcategory_name;
    private LocalDateTime date_added;
    private LocalDateTime date_updated;
    private int is_deleted;    // 0 = active, 1 = deleted

    // Constructors
    public SubcategoryDTO() {
    }

    public SubcategoryDTO(int subcategory_id, int category_id, String subcategory_name,
                          LocalDateTime date_added, LocalDateTime date_updated, int is_deleted) {
        this.subcategory_id = subcategory_id;
        this.category_id = category_id;
        this.subcategory_name = subcategory_name;
        this.date_added = date_added;
        this.date_updated = date_updated;
        this.is_deleted = is_deleted;
    }

    // Getters and Setters
    public int getSubcategory_id() {
        return subcategory_id;
    }

    public void setSubcategory_id(int subcategory_id) {
        this.subcategory_id = subcategory_id;
    }

    public int getCategory_id() {
        return category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public String getSubcategory_name() {
        return subcategory_name;
    }

    public void setSubcategory_name(String subcategory_name) {
        this.subcategory_name = subcategory_name;
    }

    public LocalDateTime getDate_added() {
        return date_added;
    }

    public void setDate_added(LocalDateTime date_added) {
        this.date_added = date_added;
    }

    public LocalDateTime getDate_updated() {
        return date_updated;
    }

    public void setDate_updated(LocalDateTime date_updated) {
        this.date_updated = date_updated;
    }

    public int getIs_deleted() {
        return is_deleted;
    }

    public void setIs_deleted(int is_deleted) {
        this.is_deleted = is_deleted;
    }

    @Override
    public String toString() {
        return "SubcategoryDTO{" +
                "subcategory_id=" + subcategory_id +
                ", category_id=" + category_id +
                ", subcategory_name='" + subcategory_name + '\'' +
                ", date_added=" + date_added +
                ", date_updated=" + date_updated +
                ", is_deleted=" + is_deleted +
                '}';
    }

	
}
