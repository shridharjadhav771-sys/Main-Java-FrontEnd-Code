package siepl_amc.mst.mst_subcategory;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import siepl_amc.mst.mst_category.CategoryDTO;
import siepl_amc.utility.LocalDateTimeTypeAdapter;

@WebServlet("/subcategories")
public class SubcategoriesServlet extends HttpServlet{
	private final Gson gson;

    public SubcategoriesServlet() {
        this.gson = new GsonBuilder()
                .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeTypeAdapter())
                .create();
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");

        String action = req.getParameter("action");
        String subcategoryId = req.getParameter("subcategory_id");
        String categoryId = req.getParameter("category_id"); // ✅ used below

        SubcategoryDAO subcategoryDAO = new SubcategoryDAO();

        if ("list".equalsIgnoreCase(action)) {
            List<SubcategoryDTO> subcategories;

            if (categoryId != null && !categoryId.isEmpty()) {
                // fetch only subcategories of selected category
                subcategories = subcategoryDAO.getSubcategoriesByCategory(Integer.parseInt(categoryId));
            } else {
                // fetch all (optionally filter by query if you still need it)
                String query = req.getParameter("query") == null ? "" : req.getParameter("query").trim();
                subcategories = subcategoryDAO.getAllSubcategories(query);
            }

            String subcategoriesJson = gson.toJson(subcategories);
            resp.getWriter().write(subcategoriesJson);

        } else if (subcategoryId != null && !subcategoryId.isEmpty()) {
            SubcategoryDTO subcategory = subcategoryDAO.getSubcategoryById(Integer.parseInt(subcategoryId));

            if (subcategory != null) {
                String subcategoryJson = gson.toJson(subcategory);
                resp.getWriter().write(subcategoryJson);
            } else {
                resp.getWriter().write("{}");
            }
        } else {
            resp.getWriter().write("{}");
        }
    }

	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain");
        
        String action =req.getParameter("action");
        String subcategory_id = req.getParameter("subcategory_id");
        
        SubcategoryDTO subcategoryDTO = new SubcategoryDTO();
        if(!"delete".equals(action)) {
        	int category_id = Integer.parseInt(req.getParameter("category_id"));
        	String subcategory_name = req.getParameter("subcategory_name");
        	
        	subcategoryDTO.setCategory_id(category_id);
        	subcategoryDTO.setSubcategory_name(subcategory_name);
        	subcategoryDTO.setIs_deleted(0);
        	
        }
        
        SubcategoryDAO subcategoryDAO = new SubcategoryDAO();
        boolean status;
        
        if ("update".equals(action) && subcategory_id != null && !subcategory_id.isEmpty()) {
        	subcategoryDTO.setSubcategory_id(Integer.parseInt(subcategory_id));
			status = subcategoryDAO.updateSubcategory(subcategoryDTO); // Call update method
		} else if ("delete".equals(action) && subcategory_id != null && !subcategory_id.isEmpty()) {
			status = subcategoryDAO.deleteSubcategory(Integer.parseInt(subcategory_id));
		} else {
			status = subcategoryDAO.insertSubcategory(subcategoryDTO); // Call insert method
		}
        
        resp.setContentType("application/plain");
		if (status)
			resp.getWriter().write("success");
		else
			resp.getWriter().write("failure");
        
	}
}
