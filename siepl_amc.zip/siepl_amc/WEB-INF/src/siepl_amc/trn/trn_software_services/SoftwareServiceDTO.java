package siepl_amc.trn.trn_software_services;

public class SoftwareServiceDTO {

    private int service_id;          
    private int product_id;          
    private String product_name;     
    private String software_name;
    private String license_key;
    private String issue_date;       
    private String expiry_date;      
    private int validity_period;     
    private String status;           
    private String date_added;       
    private String date_updated;     
    private int is_deleted;          

    // Constructors
    public SoftwareServiceDTO() {
    }

    public SoftwareServiceDTO(int service_id, int product_id, String product_name,
                              String software_name, String license_key,
                              String issue_date, String expiry_date,
                              int validity_period, String status,
                              String date_added, String date_updated,
                              int is_deleted) {
        this.service_id = service_id;
        this.product_id = product_id;
        this.product_name = product_name;
        this.software_name = software_name;
        this.license_key = license_key;
        this.issue_date = issue_date;
        this.expiry_date = expiry_date;
        this.validity_period = validity_period;
        this.status = status;
        this.date_added = date_added;
        this.date_updated = date_updated;
        this.is_deleted = is_deleted;
    }

    // Getters and Setters
    public int getService_id() {
        return service_id;
    }

    public void setService_id(int service_id) {
        this.service_id = service_id;
    }

    public int getProduct_id() {
        return product_id;
    }

    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getSoftware_name() {
        return software_name;
    }

    public void setSoftware_name(String software_name) {
        this.software_name = software_name;
    }

    public String getLicense_key() {
        return license_key;
    }

    public void setLicense_key(String license_key) {
        this.license_key = license_key;
    }

    public String getIssue_date() {
        return issue_date;
    }

    public void setIssue_date(String issue_date) {
        this.issue_date = issue_date;
    }

    public String getExpiry_date() {
        return expiry_date;
    }

    public void setExpiry_date(String expiry_date) {
        this.expiry_date = expiry_date;
    }

    public int getValidity_period() {
        return validity_period;
    }

    public void setValidity_period(int validity_period) {
        this.validity_period = validity_period;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDate_added() {
        return date_added;
    }

    public void setDate_added(String date_added) {
        this.date_added = date_added;
    }

    public String getDate_updated() {
        return date_updated;
    }

    public void setDate_updated(String date_updated) {
        this.date_updated = date_updated;
    }

    public int getIs_deleted() {
        return is_deleted;
    }

    public void setIs_deleted(int is_deleted) {
        this.is_deleted = is_deleted;
    }

    @Override
    public String toString() {
        return "SoftwareServiceDTO{" +
                "service_id=" + service_id +
                ", product_id=" + product_id +
                ", product_name='" + product_name + '\'' +
                ", software_name='" + software_name + '\'' +
                ", license_key='" + license_key + '\'' +
                ", issue_date='" + issue_date + '\'' +
                ", expiry_date='" + expiry_date + '\'' +
                ", validity_period=" + validity_period +
                ", status='" + status + '\'' +
                ", date_added='" + date_added + '\'' +
                ", date_updated='" + date_updated + '\'' +
                ", is_deleted=" + is_deleted +
                '}';
    }
}
