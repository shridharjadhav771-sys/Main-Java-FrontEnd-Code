package siepl_amc.trn.trn_software_services;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/softwareService")
public class SoftwareServiceServlet extends HttpServlet {
    private final Gson gson;

    public SoftwareServiceServlet() {
        this.gson = new Gson(); // No LocalDateTimeTypeAdapter needed
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");

        String service_id = req.getParameter("service_id");
        if (service_id == null || service_id.isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\": \"service_id is required\"}");
            return;
        }

        try {
            int id = Integer.parseInt(service_id);
            SoftwareServiceDAO serviceDAO = new SoftwareServiceDAO();
            SoftwareServiceDTO service = serviceDAO.getServiceById(id);

            if (service != null) {
                String serviceJson = gson.toJson(service);
                resp.getWriter().write(serviceJson);
            } else {
                resp.getWriter().write("{}");
            }
        } catch (NumberFormatException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\": \"Invalid service_id\"}");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain");

        String action = req.getParameter("action");
        String serviceIdStr = req.getParameter("service_id");

        SoftwareServiceDAO serviceDAO = new SoftwareServiceDAO();
        SoftwareServiceDTO serviceDTO = new SoftwareServiceDTO();
        boolean status = false;

        try {
            // DELETE
            if ("delete".equalsIgnoreCase(action)
                    && serviceIdStr != null && !serviceIdStr.isEmpty()) {

                status = serviceDAO.deleteService(serviceIdStr);

            } else {
                // Set service_id if present (for updates)
                if (serviceIdStr != null && !serviceIdStr.isEmpty()) {
                    serviceDTO.setService_id(Integer.parseInt(serviceIdStr));
                }

                // Product ID
                String productIdStr = req.getParameter("product_id");
                if (productIdStr != null && !productIdStr.isEmpty()) {
                    serviceDTO.setProduct_id(Integer.parseInt(productIdStr));
                }

                serviceDTO.setSoftware_name(req.getParameter("software_name"));
                serviceDTO.setLicense_key(req.getParameter("license_key"));

                // Dates as String
                serviceDTO.setIssue_date(req.getParameter("issue_date"));   // Expecting "yyyy-MM-dd" or similar
                serviceDTO.setExpiry_date(req.getParameter("expiry_date"));

                // Validity Period
                String validityStr = req.getParameter("validity_period");
                if (validityStr != null && !validityStr.isEmpty()) {
                    serviceDTO.setValidity_period(Integer.parseInt(validityStr));
                }

                // Status
                String statusStr = req.getParameter("status");
                if (statusStr != null && !statusStr.isEmpty()) {
                    serviceDTO.setStatus(statusStr.trim());
                }

                serviceDTO.setIs_deleted(0);

                // Insert or Update
                if ("update".equalsIgnoreCase(action)
                        && serviceIdStr != null && !serviceIdStr.isEmpty()) {
                    status = serviceDAO.updateService(serviceDTO);
                } else {
                    status = serviceDAO.insertService(serviceDTO);
                }
            }

            resp.getWriter().write(status ? "success" : "error");

        } catch (NumberFormatException nfe) {
            nfe.printStackTrace();
            resp.getWriter().write("error: invalid number format");
        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().write("error");
        }
    }
}
