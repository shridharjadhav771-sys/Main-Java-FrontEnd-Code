package siepl_amc.trn.trn_software_services;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/serviceList")
public class SoftwareServiceServletList extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Free-text search (e.g. software_name)
        String query = req.getParameter("query") != null ? req.getParameter("query").trim() : "";

        // Product filter
        Integer productId = (req.getParameter("product_id") != null &&
                             !req.getParameter("product_id").isEmpty())
                ? Integer.parseInt(req.getParameter("product_id"))
                : null;

        // Status filter (Active / Expired / Renewed)
        String status = req.getParameter("status") != null ? req.getParameter("status").trim() : null;

        // Fetch data from DAO
        SoftwareServiceDAO serviceDAO = new SoftwareServiceDAO();
        List<SoftwareServiceDTO> services = serviceDAO.getSearchedServices(query, productId, status);

        // Gson without any adapters (because DTO has String fields for date/time)
        Gson gson = new Gson();

        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(gson.toJson(services));
    }
}
