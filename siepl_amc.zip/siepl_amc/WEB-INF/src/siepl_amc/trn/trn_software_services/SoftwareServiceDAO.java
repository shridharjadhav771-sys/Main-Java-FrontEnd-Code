package siepl_amc.trn.trn_software_services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import siepl_amc.utility.DBConfig;

public class SoftwareServiceDAO {

    public SoftwareServiceDTO getServiceById(int id) {
        SoftwareServiceDTO serviceDTO = null;
        String sql = "SELECT srv.service_id, p.product_id, p.model AS product_name, "
                + "srv.software_name, srv.license_key, srv.issue_date, srv.expiry_date, "
                + "srv.validity_period, srv.status, srv.date_added, srv.date_updated, srv.is_deleted "
                + "FROM siepl_amc_trn_software_services srv "
                + "JOIN siepl_amc_mst_products p ON p.product_id = srv.product_id "
                + "WHERE srv.service_id = ? AND srv.is_deleted = 0";

        try (Connection con = DBConfig.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                serviceDTO = new SoftwareServiceDTO();
                serviceDTO.setService_id(rs.getInt("service_id"));
                serviceDTO.setProduct_id(rs.getInt("product_id"));
                serviceDTO.setProduct_name(rs.getString("product_name"));
                serviceDTO.setSoftware_name(rs.getString("software_name"));
                serviceDTO.setLicense_key(rs.getString("license_key"));

                // Dates as Strings
                serviceDTO.setIssue_date(rs.getString("issue_date"));
                serviceDTO.setExpiry_date(rs.getString("expiry_date"));

                serviceDTO.setValidity_period(rs.getInt("validity_period"));
                serviceDTO.setStatus(rs.getString("status"));

                // Timestamps as Strings
                serviceDTO.setDate_added(rs.getString("date_added"));
                serviceDTO.setDate_updated(rs.getString("date_updated"));

                serviceDTO.setIs_deleted(rs.getInt("is_deleted"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return serviceDTO;
    }

    public boolean deleteService(String serviceId) {
        String sql = "UPDATE siepl_amc_trn_software_services "
                   + "SET is_deleted=1, date_updated=NOW() WHERE service_id=?";
        try (Connection con = DBConfig.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, Integer.parseInt(serviceId));
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateService(SoftwareServiceDTO serviceDTO) {
        String sql = "UPDATE siepl_amc_trn_software_services SET "
                   + "product_id=?, software_name=?, license_key=?, issue_date=?, expiry_date=?, "
                   + "validity_period=?, status=?, date_updated=NOW() "
                   + "WHERE service_id=? AND is_deleted=0";

        try (Connection con = DBConfig.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, serviceDTO.getProduct_id());
            ps.setString(2, serviceDTO.getSoftware_name());
            ps.setString(3, serviceDTO.getLicense_key());
            ps.setString(4, serviceDTO.getIssue_date());   // Stored as String (must be "yyyy-MM-dd")
            ps.setString(5, serviceDTO.getExpiry_date());
            ps.setInt(6, serviceDTO.getValidity_period());
            ps.setString(7, serviceDTO.getStatus());
            ps.setInt(8, serviceDTO.getService_id());

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean insertService(SoftwareServiceDTO serviceDTO) {
        String sql = "INSERT INTO siepl_amc_trn_software_services "
                   + "(product_id, software_name, license_key, issue_date, expiry_date, "
                   + "validity_period, status, date_added, date_updated, is_deleted) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW(), 0)";

        try (Connection con = DBConfig.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, serviceDTO.getProduct_id());
            ps.setString(2, serviceDTO.getSoftware_name());
            ps.setString(3, serviceDTO.getLicense_key());
            ps.setString(4, serviceDTO.getIssue_date());
            ps.setString(5, serviceDTO.getExpiry_date());
            ps.setInt(6, serviceDTO.getValidity_period());
            ps.setString(7, serviceDTO.getStatus());

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<SoftwareServiceDTO> getSearchedServices(String query,
                                                        Integer productId,
                                                        String status) {
        List<SoftwareServiceDTO> list = new ArrayList<>();
        StringBuilder sub = new StringBuilder();

        if (query != null && !query.trim().isEmpty()) {
            String q = query.trim().replace("'", "''");
            sub.append(" AND (p.model LIKE '%").append(q).append("%' ")
               .append("OR srv.software_name LIKE '%").append(q).append("%' ")
               .append("OR srv.license_key LIKE '%").append(q).append("%') ");
        }
        if (productId != null && productId > 0) {
            sub.append(" AND p.product_id = ").append(productId);
        }
        if (status != null && !status.trim().isEmpty()) {
            String s = status.trim().replace("'", "''");
            sub.append(" AND srv.status = '").append(s).append("' ");
        }

        String sql = "SELECT srv.service_id, srv.product_id, p.model AS product_name, "
                   + "srv.software_name, srv.license_key, srv.issue_date, srv.expiry_date, "
                   + "srv.validity_period, srv.status, srv.date_added, srv.date_updated, srv.is_deleted "
                   + "FROM siepl_amc_trn_software_services srv "
                   + "JOIN siepl_amc_mst_products p ON p.product_id = srv.product_id "
                   + "WHERE srv.is_deleted = 0 " + sub
                   + " ORDER BY srv.service_id ASC";

        try (Connection con = DBConfig.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                SoftwareServiceDTO serviceDTO = new SoftwareServiceDTO();
                serviceDTO.setService_id(rs.getInt("service_id"));
                serviceDTO.setProduct_id(rs.getInt("product_id"));
                serviceDTO.setProduct_name(rs.getString("product_name"));
                serviceDTO.setSoftware_name(rs.getString("software_name"));
                serviceDTO.setLicense_key(rs.getString("license_key"));

                // Dates as Strings
                serviceDTO.setIssue_date(rs.getString("issue_date"));
                serviceDTO.setExpiry_date(rs.getString("expiry_date"));

                serviceDTO.setValidity_period(rs.getInt("validity_period"));
                serviceDTO.setStatus(rs.getString("status"));

                // Timestamps as Strings
                serviceDTO.setDate_added(rs.getString("date_added"));
                serviceDTO.setDate_updated(rs.getString("date_updated"));

                serviceDTO.setIs_deleted(rs.getInt("is_deleted"));
                list.add(serviceDTO);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
