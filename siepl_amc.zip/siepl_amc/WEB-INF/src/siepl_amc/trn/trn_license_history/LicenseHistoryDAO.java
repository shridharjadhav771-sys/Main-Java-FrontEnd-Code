package siepl_amc.trn.trn_license_history;

public class LicenseHistoryDAO {

}
