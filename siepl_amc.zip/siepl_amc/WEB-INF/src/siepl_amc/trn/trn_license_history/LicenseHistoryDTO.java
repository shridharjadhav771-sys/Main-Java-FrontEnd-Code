package siepl_amc.trn.trn_license_history;

public class LicenseHistoryDTO {

    private Integer history_id;
    private Integer service_id;          // FK → Software Service
    private String software_name;
    private String renewed_on_date;      // Date when renewal happened
    private String new_expiry_date;      // Expiry date after renewal
    private String date_added;
    private String date_updated;
    private int is_deleted;

    // Constructors
    public LicenseHistoryDTO() {
    }

	public LicenseHistoryDTO(Integer history_id, Integer service_id, String software_name, String renewed_on_date,
			String new_expiry_date, String date_added, String date_updated, int is_deleted) {
		super();
		this.history_id = history_id;
		this.service_id = service_id;
		this.software_name = software_name;
		this.renewed_on_date = renewed_on_date;
		this.new_expiry_date = new_expiry_date;
		this.date_added = date_added;
		this.date_updated = date_updated;
		this.is_deleted = is_deleted;
	}

	public Integer getHistory_id() {
		return history_id;
	}

	public void setHistory_id(Integer history_id) {
		this.history_id = history_id;
	}

	public Integer getService_id() {
		return service_id;
	}

	public void setService_id(Integer service_id) {
		this.service_id = service_id;
	}

	public String getSoftware_name() {
		return software_name;
	}

	public void setSoftware_name(String software_name) {
		this.software_name = software_name;
	}

	public String getRenewed_on_date() {
		return renewed_on_date;
	}

	public void setRenewed_on_date(String renewed_on_date) {
		this.renewed_on_date = renewed_on_date;
	}

	public String getNew_expiry_date() {
		return new_expiry_date;
	}

	public void setNew_expiry_date(String new_expiry_date) {
		this.new_expiry_date = new_expiry_date;
	}

	public String getDate_added() {
		return date_added;
	}

	public void setDate_added(String date_added) {
		this.date_added = date_added;
	}

	public String getDate_updated() {
		return date_updated;
	}

	public void setDate_updated(String date_updated) {
		this.date_updated = date_updated;
	}

	public int getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(int is_deleted) {
		this.is_deleted = is_deleted;
	}

	@Override
	public String toString() {
		return "LicenseHistoryDTO [history_id=" + history_id + ", service_id=" + service_id + ", software_name="
				+ software_name + ", renewed_on_date=" + renewed_on_date + ", new_expiry_date=" + new_expiry_date
				+ ", date_added=" + date_added + ", date_updated=" + date_updated + ", is_deleted=" + is_deleted + "]";
	}

    
}
