package siepl_amc.trn.trn_sales_orders;

import java.io.IOException;
import java.math.BigDecimal;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/salesOrder")
public class SalesOrderServlet extends HttpServlet{
	private final Gson gson;

    public SalesOrderServlet() {
        this.gson = new Gson(); // No LocalDateTimeTypeAdapter needed
    }
    
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");

        String sales_order_id = req.getParameter("sales_order_id");
        if(sales_order_id == null || sales_order_id.isEmpty()) {
        	resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\": \"sales_order_id is required\"}");
            return;
        }
        
        try {
        	int id = Integer.parseInt(sales_order_id);
        	SalesOrderDAO salesOrderDAO = new SalesOrderDAO();
        	SalesOrderDTO salesOrder = salesOrderDAO.getSalesOrderById(id);
        	
        	if (salesOrder != null) {
                String salesOrderJson = gson.toJson(salesOrder);
                resp.getWriter().write(salesOrderJson);
            } else {
                resp.getWriter().write("{}");
            }
        } catch (NumberFormatException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\": \"Invalid sales_order_id\"}");
        }
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain");

        String action = req.getParameter("action");
		String salesOrderId = req.getParameter("sales_order_id");
		
		SalesOrderDAO salesOrderDAO = new SalesOrderDAO();
		SalesOrderDTO salesOrderDTO = new SalesOrderDTO();
		
		try {
			if ("delete".equalsIgnoreCase(action)
                    && salesOrderId != null && !salesOrderId.isEmpty()) {

                boolean deleted = salesOrderDAO.deleteSalesOrder(salesOrderId);
                resp.getWriter().write(deleted ? "success" : "error");
                return;
		}else {
			
			if (salesOrderId != null && !salesOrderId.isEmpty()) {
				salesOrderDTO.setSales_order_id(Integer.parseInt(salesOrderId));
            }
			
			String customerId = req.getParameter("customer_id");
			if (customerId != null && !customerId.isEmpty()) {
				salesOrderDTO.setCustomer_id(Integer.parseInt(customerId));
            }
			
			String productIdStr = req.getParameter("product_id");
            if (productIdStr != null && !productIdStr.isEmpty()) {
            	salesOrderDTO.setProduct_id(Integer.parseInt(productIdStr));
            }
            
            String billAmountStr = req.getParameter("bill_amount");
            if (billAmountStr != null && !billAmountStr.isEmpty()) {
            	salesOrderDTO.setBill_amount(new BigDecimal(billAmountStr));
            }
            
            salesOrderDTO.setDate_out(req.getParameter("date_out"));
            salesOrderDTO.setWarranty_start_date(req.getParameter("warranty_start_date"));
            salesOrderDTO.setWarranty_end_date(req.getParameter("warranty_end_date"));
            String isDeletedStr = req.getParameter("is_deleted");
            if (isDeletedStr != null && !isDeletedStr.isEmpty()) {
            	salesOrderDTO.setIs_deleted(Integer.parseInt(isDeletedStr));
            }
            
            boolean success;
            if ("update".equalsIgnoreCase(action)) {
                success = salesOrderDAO.updateSalesOrder(salesOrderDTO);
            } else {
                success = salesOrderDAO.addSalesOrder(salesOrderDTO);
            }
            resp.getWriter().write(success ? "success" : "error");
		}
	}catch (NumberFormatException nfe) {
        nfe.printStackTrace();
        resp.getWriter().write("error: invalid number format");
    } catch (Exception e) {
        e.printStackTrace();
        resp.getWriter().write("error");
    }
	}
}
