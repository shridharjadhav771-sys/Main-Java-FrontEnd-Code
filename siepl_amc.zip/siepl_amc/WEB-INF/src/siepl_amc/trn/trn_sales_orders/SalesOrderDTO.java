package siepl_amc.trn.trn_sales_orders;

import java.math.BigDecimal;

public class SalesOrderDTO {

    private int sales_order_id;
    private int customer_id;
    private String customer_name;
    private int product_id;
    private String product_name;
    private BigDecimal bill_amount;
    private String date_out;
    private String warranty_start_date;
    private String warranty_end_date;
    private String date_added;
    private String date_updated;
    private int is_deleted;

    // Constructors
    public SalesOrderDTO() {
    }

	public SalesOrderDTO(int sales_order_id, int customer_id, String customer_name, int product_id, String product_name,
			BigDecimal bill_amount, String date_out, String warranty_start_date, String warranty_end_date,
			String date_added, String date_updated, int is_deleted) {
		super();
		this.sales_order_id = sales_order_id;
		this.customer_id = customer_id;
		this.customer_name = customer_name;
		this.product_id = product_id;
		this.product_name = product_name;
		this.bill_amount = bill_amount;
		this.date_out = date_out;
		this.warranty_start_date = warranty_start_date;
		this.warranty_end_date = warranty_end_date;
		this.date_added = date_added;
		this.date_updated = date_updated;
		this.is_deleted = is_deleted;
	}

	public int getSales_order_id() {
		return sales_order_id;
	}

	public void setSales_order_id(int sales_order_id) {
		this.sales_order_id = sales_order_id;
	}

	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public BigDecimal getBill_amount() {
		return bill_amount;
	}

	public void setBill_amount(BigDecimal bill_amount) {
		this.bill_amount = bill_amount;
	}

	public String getDate_out() {
		return date_out;
	}

	public void setDate_out(String date_out) {
		this.date_out = date_out;
	}

	public String getWarranty_start_date() {
		return warranty_start_date;
	}

	public void setWarranty_start_date(String warranty_start_date) {
		this.warranty_start_date = warranty_start_date;
	}

	public String getWarranty_end_date() {
		return warranty_end_date;
	}

	public void setWarranty_end_date(String warranty_end_date) {
		this.warranty_end_date = warranty_end_date;
	}

	public String getDate_added() {
		return date_added;
	}

	public void setDate_added(String date_added) {
		this.date_added = date_added;
	}

	public String getDate_updated() {
		return date_updated;
	}

	public void setDate_updated(String date_updated) {
		this.date_updated = date_updated;
	}

	public int getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(int is_deleted) {
		this.is_deleted = is_deleted;
	}

	@Override
	public String toString() {
		return "SalesOrderDTO [sales_order_id=" + sales_order_id + ", customer_id=" + customer_id + ", customer_name="
				+ customer_name + ", product_id=" + product_id + ", product_name=" + product_name + ", bill_amount="
				+ bill_amount + ", date_out=" + date_out + ", warranty_start_date=" + warranty_start_date
				+ ", warranty_end_date=" + warranty_end_date + ", date_added=" + date_added + ", date_updated="
				+ date_updated + ", is_deleted=" + is_deleted + "]";
	}
    
}
