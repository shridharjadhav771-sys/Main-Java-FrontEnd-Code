package siepl_amc.trn.trn_sales_orders;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/salesOrderList")
public class SalesOrderListServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String query = req.getParameter("query") != null ? req.getParameter("query").trim() : "";

        Integer productId = (req.getParameter("product_id") != null &&
                !req.getParameter("product_id").isEmpty())
                ? Integer.parseInt(req.getParameter("product_id"))
                : null;


        String startDate = req.getParameter("startDate");  // e.g. "2025-09-01"
        String endDate = req.getParameter("endDate");      // e.g. "2025-09-12"

        SalesOrderDAO salesOrderDAO = new SalesOrderDAO();
        List<SalesOrderDTO> salesOrders = salesOrderDAO.getSearchedOrders(query, productId, startDate, endDate);

        Gson gson = new Gson();

        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(gson.toJson(salesOrders));
    }
}
