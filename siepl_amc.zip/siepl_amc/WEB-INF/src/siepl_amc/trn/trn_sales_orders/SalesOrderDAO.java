package siepl_amc.trn.trn_sales_orders;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import siepl_amc.utility.DBConfig;

public class SalesOrderDAO {

	public SalesOrderDTO getSalesOrderById(int id) {
	    SalesOrderDTO salesOrderDTO = null;

	    String sql = "SELECT so.sales_order_id, " +
	                 "c.customer_id, c.customer_name, " +
	                 "p.product_id, p.model AS product_name, " +
	                 "so.bill_amount, so.date_out, " +
	                 "so.warranty_start_date, so.warranty_end_date, " +
	                 "so.date_added, so.date_updated, so.is_deleted " +
	                 "FROM siepl_amc_trn_sales_orders so " +
	                 "JOIN siepl_amc_mst_customers c ON c.customer_id = so.customer_id " +
	                 "JOIN siepl_amc_mst_products p ON p.product_id = so.product_id " +
	                 "WHERE so.sales_order_id = ? AND so.is_deleted = 0";

	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {

	        ps.setInt(1, id);
	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            salesOrderDTO = new SalesOrderDTO();

	            salesOrderDTO.setSales_order_id(rs.getInt("sales_order_id"));
	            salesOrderDTO.setCustomer_id(rs.getInt("customer_id"));
	            salesOrderDTO.setCustomer_name(rs.getString("customer_name"));
	            salesOrderDTO.setProduct_id(rs.getInt("product_id"));
	            salesOrderDTO.setProduct_name(rs.getString("product_name"));

	            salesOrderDTO.setBill_amount(rs.getBigDecimal("bill_amount"));

	            // Dates as String
	            salesOrderDTO.setDate_out(rs.getString("date_out"));
	            salesOrderDTO.setWarranty_start_date(rs.getString("warranty_start_date"));
	            salesOrderDTO.setWarranty_end_date(rs.getString("warranty_end_date"));

	            salesOrderDTO.setDate_added(rs.getString("date_added"));
	            salesOrderDTO.setDate_updated(rs.getString("date_updated"));
	            salesOrderDTO.setIs_deleted(rs.getInt("is_deleted"));
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return salesOrderDTO;
	}

	public boolean deleteSalesOrder(String salesOrderIdStr) {
	    String sql = "UPDATE siepl_amc_trn_sales_orders " +
	                 "SET is_deleted = 1, date_updated = NOW() " +
	                 "WHERE sales_order_id = ?";

	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {

	        ps.setInt(1, Integer.parseInt(salesOrderIdStr));
	        return ps.executeUpdate() > 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false;
	}

	public boolean updateSalesOrder(SalesOrderDTO dto) {
	    String sql = "UPDATE siepl_amc_trn_sales_orders " +
	                 "SET customer_id = ?, product_id = ?, bill_amount = ?, " +
	                 "    date_out = ?, warranty_start_date = ?, warranty_end_date = ?, " +
	                 "    date_updated = NOW() " +
	                 "WHERE sales_order_id = ? AND is_deleted = 0";

	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {

	        ps.setInt(1, dto.getCustomer_id());
	        ps.setInt(2, dto.getProduct_id());
	        ps.setBigDecimal(3, dto.getBill_amount());
	        ps.setString(4, dto.getDate_out());
	        ps.setString(5, dto.getWarranty_start_date());
	        ps.setString(6, dto.getWarranty_end_date());
	        ps.setInt(7, dto.getSales_order_id());

	        return ps.executeUpdate() > 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false;
	}

	public boolean addSalesOrder(SalesOrderDTO dto) {
	    String sql = "INSERT INTO siepl_amc_trn_sales_orders " +
	                 "(customer_id, product_id, bill_amount, date_out, " +
	                 " warranty_start_date, warranty_end_date, date_added) " +
	                 "VALUES (?,?,?,?,?,?,NOW())";

	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {

	        ps.setInt(1, dto.getCustomer_id());
	        ps.setInt(2, dto.getProduct_id());
	        ps.setBigDecimal(3, dto.getBill_amount());
	        ps.setString(4, dto.getDate_out());
	        ps.setString(5, dto.getWarranty_start_date());
	        ps.setString(6, dto.getWarranty_end_date());

	        return ps.executeUpdate() > 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false;
	}

/*
	public List<SalesOrderDTO> getSearchedOrders(String query, Integer productId) {
	    List<SalesOrderDTO> list = new ArrayList<>();
	    StringBuilder sub = new StringBuilder();

	    if (query != null && !query.trim().isEmpty()) {
	        String q = query.trim().replace("'", "''");
	        sub.append(" AND (p.model LIKE '%").append(q).append("%' ")
	           .append("OR c.customer_name LIKE '%").append(q).append("%') ");
	    }

	    if (productId != null && productId > 0) {
	        sub.append(" AND p.product_id = ").append(productId);
	    }

	    String sql = "SELECT so.sales_order_id, " +
	                 "c.customer_id, c.customer_name, " +
	                 "p.product_id, p.model AS product_name, " +
	                 "so.bill_amount, so.date_out, " +
	                 "so.warranty_start_date, so.warranty_end_date, " +
	                 "so.date_added, so.date_updated, so.is_deleted " +
	                 "FROM siepl_amc_trn_sales_orders so " +
	                 "JOIN siepl_amc_mst_customers c ON c.customer_id = so.customer_id " +
	                 "JOIN siepl_amc_mst_products p ON p.product_id = so.product_id " +
	                 "WHERE so.is_deleted = 0 " + sub +
	                 " ORDER BY so.sales_order_id ASC";

	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {

	        while (rs.next()) {
	            SalesOrderDTO dto = new SalesOrderDTO();

	            dto.setSales_order_id(rs.getInt("sales_order_id"));
	            dto.setCustomer_id(rs.getInt("customer_id"));
	            dto.setCustomer_name(rs.getString("customer_name"));
	            dto.setProduct_id(rs.getInt("product_id"));
	            dto.setProduct_name(rs.getString("product_name"));
	            dto.setBill_amount(rs.getBigDecimal("bill_amount"));

	            // Dates as Strings
	            dto.setDate_out(rs.getString("date_out"));
	            dto.setWarranty_start_date(rs.getString("warranty_start_date"));
	            dto.setWarranty_end_date(rs.getString("warranty_end_date"));

	            dto.setDate_added(rs.getString("date_added"));
	            dto.setDate_updated(rs.getString("date_updated"));
	            dto.setIs_deleted(rs.getInt("is_deleted"));

	            list.add(dto);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return list;
	}
*/
	
	public List<SalesOrderDTO> getSearchedOrders(String query, Integer productId, String startDate, String endDate) {
	    List<SalesOrderDTO> list = new ArrayList<>();
	    String sql = "SELECT so.sales_order_id, " +
	                 "c.customer_id, c.customer_name, " +
	                 "p.product_id, p.model AS product_name, " +
	                 "so.bill_amount, so.date_out, " +
	                 "so.warranty_start_date, so.warranty_end_date, " +
	                 "so.date_added, so.date_updated, so.is_deleted " +
	                 "FROM siepl_amc_trn_sales_orders so " +
	                 "JOIN siepl_amc_mst_customers c ON c.customer_id = so.customer_id " +
	                 "JOIN siepl_amc_mst_products p ON p.product_id = so.product_id " +
	                 "WHERE so.is_deleted = 0";

	    if (query != null && !query.trim().isEmpty()) {
	        String q = query.trim().replace("'", "''");
	        sql += " AND (p.model LIKE '%" + q + "%' OR c.customer_name LIKE '%" + q + "%')";
	    }

	    if (productId != null && productId > 0) {
	        sql += " AND p.product_id = " + productId;
	    }

	    if (startDate != null && !startDate.isEmpty() && endDate != null && !endDate.isEmpty()) {
	        sql += " AND so.date_out BETWEEN '" + startDate + "' AND '" + endDate + "'";
	    }

	    sql += " ORDER BY so.sales_order_id ASC";

	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {

	        while (rs.next()) {
	            SalesOrderDTO dto = new SalesOrderDTO();
	            dto.setSales_order_id(rs.getInt("sales_order_id"));
	            dto.setCustomer_id(rs.getInt("customer_id"));
	            dto.setCustomer_name(rs.getString("customer_name"));
	            dto.setProduct_id(rs.getInt("product_id"));
	            dto.setProduct_name(rs.getString("product_name"));
	            dto.setBill_amount(rs.getBigDecimal("bill_amount"));
	            dto.setDate_out(rs.getString("date_out"));
	            dto.setWarranty_start_date(rs.getString("warranty_start_date"));
	            dto.setWarranty_end_date(rs.getString("warranty_end_date"));
	            dto.setDate_added(rs.getString("date_added"));
	            dto.setDate_updated(rs.getString("date_updated"));
	            dto.setIs_deleted(rs.getInt("is_deleted"));
	            list.add(dto);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return list;
	}


}
