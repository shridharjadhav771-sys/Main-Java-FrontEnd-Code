package siepl_amc.trn.trn_fms_facilities;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/facilityList")
public class FacilityListServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
        String query = req.getParameter("query") != null ? req.getParameter("query").trim() : "";
        
        FacilityDAO facilityDAO = new FacilityDAO();
        List<FacilityDTO> facilities = facilityDAO.getSearchedFacilities(query);
        
        Gson gson = new Gson();

        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(gson.toJson(facilities));
	}
}
