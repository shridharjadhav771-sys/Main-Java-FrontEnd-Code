package siepl_amc.trn.trn_fms_facilities;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import siepl_amc.utility.DBConfig;

public class FacilityDAO {

	public FacilityDTO getFacilityById(int id) {
	    FacilityDTO facilityDTO = null;

	    String sql =
	        "SELECT f.facility_id, " +
	        "c.customer_id, c.customer_name, " +
	        "p.product_id, p.model AS product_name, " +
	        "cat.category_id, cat.category_name, " +
	        "s.service_id, s.software_name, " +
	        "f.service_start_date, f.service_end_date, " +
	        "f.status, f.date_added, f.date_updated, f.is_deleted " +
	        "FROM siepl_amc_trn_fms_facilities f " +
	        "JOIN siepl_amc_mst_customers c ON c.customer_id = f.customer_id " +
	        "JOIN siepl_amc_mst_products p ON p.product_id = f.product_id " +
	        "JOIN siepl_amc_mst_categories cat ON cat.category_id = f.category_id " +
	        "JOIN siepl_amc_trn_software_services s ON s.service_id = f.service_id " +
	        "WHERE f.facility_id = ? AND f.is_deleted = 0";

	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {

	        ps.setInt(1, id);
	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            facilityDTO = new FacilityDTO();

	            facilityDTO.setFacility_id(rs.getInt("facility_id"));
	            facilityDTO.setCustomer_id(rs.getInt("customer_id"));
	            facilityDTO.setCustomer_name(rs.getString("customer_name"));
	            facilityDTO.setProduct_id(rs.getInt("product_id"));
	            facilityDTO.setProduct_name(rs.getString("product_name"));
	            facilityDTO.setCategory_id(rs.getInt("category_id"));
	            facilityDTO.setCategory_name(rs.getString("category_name"));
	            facilityDTO.setService_id(rs.getInt("service_id"));
	            facilityDTO.setSoftware_name(rs.getString("software_name"));

	            // Dates as String (consistent with your DTO)
	            facilityDTO.setService_start_date(rs.getString("service_start_date"));
	            facilityDTO.setService_end_date(rs.getString("service_end_date"));

	            facilityDTO.setStatus(rs.getString("status"));
	            facilityDTO.setDate_added(rs.getString("date_added"));
	            facilityDTO.setDate_updated(rs.getString("date_updated"));
	            facilityDTO.setIs_deleted(rs.getInt("is_deleted"));
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return facilityDTO;
	}


	public boolean deleteFacility(String facility_id) {
	    String sql = "UPDATE siepl_amc_trn_fms_facilities "
	               + "SET is_deleted = 1, date_updated = CURRENT_TIMESTAMP "
	               + "WHERE facility_id = ?";
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {
	        ps.setInt(1, Integer.parseInt(facility_id));
	        return ps.executeUpdate() > 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return false;
	    }
	}

	public boolean updateFacility(FacilityDTO facilityDTO) {
	    String sql = "UPDATE siepl_amc_trn_fms_facilities SET "
	               + "customer_id = ?, product_id = ?, category_id = ?, service_id = ?, "
	               + "service_start_date = ?, service_end_date = ?, status = ?, "
	               + "date_updated = CURRENT_TIMESTAMP "
	               + "WHERE facility_id = ? AND is_deleted = 0";
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {

	        ps.setInt(1, facilityDTO.getCustomer_id());
	        ps.setInt(2, facilityDTO.getProduct_id());
	        ps.setInt(3, facilityDTO.getCategory_id());
	        ps.setInt(4, facilityDTO.getService_id());
	        ps.setString(5, facilityDTO.getService_start_date());
	        ps.setString(6, facilityDTO.getService_end_date());
	        ps.setString(7, facilityDTO.getStatus());
	        ps.setInt(8, facilityDTO.getFacility_id());

	        return ps.executeUpdate() > 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return false;
	    }
	}

	public boolean addFacility(FacilityDTO facilityDTO) {
	    String sql = "INSERT INTO siepl_amc_trn_fms_facilities "
	               + "(customer_id, product_id, category_id, service_id, "
	               + "service_start_date, service_end_date, status, date_added, date_updated, is_deleted) "
	               + "VALUES (?,?,?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,0)";
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {

	        ps.setInt(1, facilityDTO.getCustomer_id());
	        ps.setInt(2, facilityDTO.getProduct_id());
	        ps.setInt(3, facilityDTO.getCategory_id());
	        ps.setInt(4, facilityDTO.getService_id());
	        ps.setString(5, facilityDTO.getService_start_date());
	        ps.setString(6, facilityDTO.getService_end_date());
	        ps.setString(7, facilityDTO.getStatus());

	        return ps.executeUpdate() > 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return false;
	    }
	}


	public List<FacilityDTO> getSearchedFacilities(String query) {
	    List<FacilityDTO> list = new ArrayList<>();

	    String sql = "SELECT f.facility_id, " +
	                 "c.customer_id, c.customer_name, " +
	                 "p.product_id, p.model AS product_name, " +
	                 "cat.category_id, cat.category_name, " +
	                 "s.service_id, s.software_name, " +
	                 "f.service_start_date, f.service_end_date, " +
	                 "f.status, f.date_added, f.date_updated, f.is_deleted " +
	                 "FROM siepl_amc_trn_fms_facilities f " +
	                 "JOIN siepl_amc_mst_customers c ON c.customer_id = f.customer_id " +
	                 "JOIN siepl_amc_mst_products p ON p.product_id = f.product_id " +
	                 "JOIN siepl_amc_mst_categories cat ON cat.category_id = f.category_id " +
	                 "JOIN siepl_amc_trn_software_services s ON s.service_id = f.service_id " +
	                 "WHERE f.is_deleted = 0";

	    if (query != null && !query.trim().isEmpty()) {
	        String q = query.trim().replace("'", "''");
	        sql += " AND (p.model LIKE '%" + q + "%' " +
	               "OR c.customer_name LIKE '%" + q + "%' " +
	               "OR cat.category_name LIKE '%" + q + "%' " +
	               "OR s.software_name LIKE '%" + q + "%')";
	    }

	    sql += " ORDER BY f.facility_id ASC";

	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {

	        while (rs.next()) {
	            FacilityDTO dto = new FacilityDTO();
	            dto.setFacility_id(rs.getInt("facility_id"));
	            dto.setCustomer_id(rs.getInt("customer_id"));
	            dto.setCustomer_name(rs.getString("customer_name"));
	            dto.setProduct_id(rs.getInt("product_id"));
	            dto.setProduct_name(rs.getString("product_name"));
	            dto.setCategory_id(rs.getInt("category_id"));
	            dto.setCategory_name(rs.getString("category_name"));
	            dto.setService_id(rs.getInt("service_id"));
	            dto.setSoftware_name(rs.getString("software_name"));
	            dto.setService_start_date(rs.getString("service_start_date"));
	            dto.setService_end_date(rs.getString("service_end_date"));
	            dto.setStatus(rs.getString("status"));
	            dto.setDate_added(rs.getString("date_added"));
	            dto.setDate_updated(rs.getString("date_updated"));
	            dto.setIs_deleted(rs.getInt("is_deleted"));
	            list.add(dto);
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return list;
	}

	
}
