package siepl_amc.trn.trn_fms_facilities;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/facility")
public class FacilityServlet extends HttpServlet {
    private final Gson gson;

    public FacilityServlet() {
        this.gson = new Gson();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");

        String facilityId = req.getParameter("facility_id");
        if (facilityId == null || facilityId.isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\":\"facility_id is required\"}");
            return;
        }

        try {
            int id = Integer.parseInt(facilityId);
            FacilityDAO dao = new FacilityDAO();
            FacilityDTO facility = dao.getFacilityById(id);

            resp.getWriter().write(
                facility != null ? gson.toJson(facility) : "{}"
            );

        } catch (NumberFormatException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\":\"Invalid facility_id\"}");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain");

        String action     = req.getParameter("action");
        String facilityId = req.getParameter("facility_id");

        FacilityDAO dao   = new FacilityDAO();
        FacilityDTO dto   = new FacilityDTO();

        try {
            // ----- Delete -----
            if ("delete".equalsIgnoreCase(action)
                    && facilityId != null && !facilityId.isEmpty()) {
                boolean deleted = dao.deleteFacility(facilityId);
                resp.getWriter().write(deleted ? "success" : "error");
                return;
            }

            // ----- Common fields -----
            if (facilityId != null && !facilityId.isEmpty()) {
                dto.setFacility_id(Integer.parseInt(facilityId));
            }

            String customerId = req.getParameter("customer_id");
            if (customerId != null && !customerId.isEmpty()) {
                dto.setCustomer_id(Integer.parseInt(customerId));
            }

            String productId = req.getParameter("product_id");
            if (productId != null && !productId.isEmpty()) {
                dto.setProduct_id(Integer.parseInt(productId));
            }

            String categoryId = req.getParameter("category_id");
            if (categoryId != null && !categoryId.isEmpty()) {
                dto.setCategory_id(Integer.parseInt(categoryId));
            }

            String serviceId = req.getParameter("service_id");
            if (serviceId != null && !serviceId.isEmpty()) {
                dto.setService_id(Integer.parseInt(serviceId));
            }


            // Dates are plain Strings now
            dto.setService_start_date(req.getParameter("service_start_date"));
            dto.setService_end_date(req.getParameter("service_end_date"));

            dto.setStatus(req.getParameter("status"));

            String isDeletedStr = req.getParameter("is_deleted");
            if (isDeletedStr != null && !isDeletedStr.isEmpty()) {
                dto.setIs_deleted(Integer.parseInt(isDeletedStr));
            }

            // ----- Insert or Update -----
            boolean success = "update".equalsIgnoreCase(action)
                              ? dao.updateFacility(dto)
                              : dao.addFacility(dto);

            resp.getWriter().write(success ? "success" : "error");

        } catch (NumberFormatException nfe) {
            nfe.printStackTrace();
            resp.getWriter().write("error: invalid number format");
        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().write("error");
        }
    }
}
