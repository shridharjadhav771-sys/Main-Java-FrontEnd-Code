package siepl_amc.trn.trn_fms_facilities;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class FacilityDTO {

    private int facility_id;
    private int customer_id;       // FK → Customer
    private String customer_name;
    private int product_id;        // FK → Product
    private String product_name;
    private int category_id;       // FK → Category
    private String category_name;
    private int service_id;        // FK → Software Service
    private String software_name;
    private String service_start_date;
    private String service_end_date;
    private String status;            // Active / Inactive
    private String date_added;
    private String date_updated;
    private int is_deleted;

    // Constructors
    public FacilityDTO() {
    }

	public FacilityDTO(int facility_id, int customer_id, String customer_name, int product_id, String product_name,
			int category_id, String category_name, int service_id, String software_name, String service_start_date,
			String service_end_date, String status, String date_added, String date_updated, int is_deleted) {
		super();
		this.facility_id = facility_id;
		this.customer_id = customer_id;
		this.customer_name = customer_name;
		this.product_id = product_id;
		this.product_name = product_name;
		this.category_id = category_id;
		this.category_name = category_name;
		this.service_id = service_id;
		this.software_name = software_name;
		this.service_start_date = service_start_date;
		this.service_end_date = service_end_date;
		this.status = status;
		this.date_added = date_added;
		this.date_updated = date_updated;
		this.is_deleted = is_deleted;
	}

	public int getFacility_id() {
		return facility_id;
	}

	public void setFacility_id(int facility_id) {
		this.facility_id = facility_id;
	}

	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public int getCategory_id() {
		return category_id;
	}

	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}

	public String getCategory_name() {
		return category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	public int getService_id() {
		return service_id;
	}

	public void setService_id(int service_id) {
		this.service_id = service_id;
	}

	public String getSoftware_name() {
		return software_name;
	}

	public void setSoftware_name(String software_name) {
		this.software_name = software_name;
	}

	public String getService_start_date() {
		return service_start_date;
	}

	public void setService_start_date(String service_start_date) {
		this.service_start_date = service_start_date;
	}

	public String getService_end_date() {
		return service_end_date;
	}

	public void setService_end_date(String service_end_date) {
		this.service_end_date = service_end_date;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDate_added() {
		return date_added;
	}

	public void setDate_added(String date_added) {
		this.date_added = date_added;
	}

	public String getDate_updated() {
		return date_updated;
	}

	public void setDate_updated(String date_updated) {
		this.date_updated = date_updated;
	}

	public int getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(int is_deleted) {
		this.is_deleted = is_deleted;
	}

	@Override
	public String toString() {
		return "FacilityDTO [facility_id=" + facility_id + ", customer_id=" + customer_id + ", customer_name="
				+ customer_name + ", product_id=" + product_id + ", product_name=" + product_name + ", category_id="
				+ category_id + ", category_name=" + category_name + ", service_id=" + service_id + ", software_name="
				+ software_name + ", service_start_date=" + service_start_date + ", service_end_date="
				+ service_end_date + ", status=" + status + ", date_added=" + date_added + ", date_updated="
				+ date_updated + ", is_deleted=" + is_deleted + "]";
	}	
    
}
