package siepl_amc.trn.trn_notifications;

public class NotificationDTO {

    private Integer notification_id;
    private String type;          // License, Warranty, AMC, Purchase, Service
    private String message;
    private String created_on;
    private String status;        // Unread, Read, Discarded
    private String expiry_date;
    private String date_added;
    private String date_updated;
    private int is_deleted;

    // Constructors
    public NotificationDTO() {
    }

	public NotificationDTO(Integer notification_id, String type, String message, String created_on, String status,
			String expiry_date, String date_added, String date_updated, int is_deleted) {
		super();
		this.notification_id = notification_id;
		this.type = type;
		this.message = message;
		this.created_on = created_on;
		this.status = status;
		this.expiry_date = expiry_date;
		this.date_added = date_added;
		this.date_updated = date_updated;
		this.is_deleted = is_deleted;
	}

	public Integer getNotification_id() {
		return notification_id;
	}

	public void setNotification_id(Integer notification_id) {
		this.notification_id = notification_id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getCreated_on() {
		return created_on;
	}

	public void setCreated_on(String created_on) {
		this.created_on = created_on;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getExpiry_date() {
		return expiry_date;
	}

	public void setExpiry_date(String expiry_date) {
		this.expiry_date = expiry_date;
	}

	public String getDate_added() {
		return date_added;
	}

	public void setDate_added(String date_added) {
		this.date_added = date_added;
	}

	public String getDate_updated() {
		return date_updated;
	}

	public void setDate_updated(String date_updated) {
		this.date_updated = date_updated;
	}

	public int getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(int is_deleted) {
		this.is_deleted = is_deleted;
	}

	@Override
	public String toString() {
		return "NotificationDTO [notification_id=" + notification_id + ", type=" + type + ", message=" + message
				+ ", created_on=" + created_on + ", status=" + status + ", expiry_date=" + expiry_date + ", date_added="
				+ date_added + ", date_updated=" + date_updated + ", is_deleted=" + is_deleted + "]";
	}

    
}
