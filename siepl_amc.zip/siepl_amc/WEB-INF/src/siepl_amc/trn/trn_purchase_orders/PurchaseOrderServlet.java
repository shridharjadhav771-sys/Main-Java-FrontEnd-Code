package siepl_amc.trn.trn_purchase_orders;

import java.io.IOException;
import java.math.BigDecimal;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/purchaseOrder")
public class PurchaseOrderServlet extends HttpServlet {
    private final Gson gson;

    public PurchaseOrderServlet() {
        this.gson = new Gson(); // No LocalDateTime adapter needed
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");

        String purchaseOrderIdStr = req.getParameter("purchase_order_id");
        if (purchaseOrderIdStr == null || purchaseOrderIdStr.isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\": \"purchase_order_id is required\"}");
            return;
        }

        try {
            int id = Integer.parseInt(purchaseOrderIdStr);
            PurchaseOrderDAO dao = new PurchaseOrderDAO();
            PurchaseOrderDTO dto = dao.getPurchaseOrderById(id);

            if (dto != null) {
                resp.getWriter().write(gson.toJson(dto));
            } else {
                resp.getWriter().write("{}");
            }
        } catch (NumberFormatException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\": \"Invalid purchase_order_id\"}");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain");

        String action = req.getParameter("action");
        String purchaseOrderIdStr = req.getParameter("purchase_order_id");

        PurchaseOrderDAO dao = new PurchaseOrderDAO();
        PurchaseOrderDTO dto = new PurchaseOrderDTO();

        try {
            // DELETE
            if ("delete".equalsIgnoreCase(action) && purchaseOrderIdStr != null && !purchaseOrderIdStr.isEmpty()) {
                boolean deleted = dao.deletePurchaseOrder(purchaseOrderIdStr);
                resp.getWriter().write(deleted ? "success" : "error");
                return;
            }

            // If purchase_order_id is provided → UPDATE
            if (purchaseOrderIdStr != null && !purchaseOrderIdStr.isEmpty()) {
                dto.setPurchase_order_id(Integer.parseInt(purchaseOrderIdStr));
            }

            // Map fields from request
            String vendorIdStr = req.getParameter("vendor_id");
            if (vendorIdStr != null && !vendorIdStr.isEmpty()) {
                dto.setVendor_id(Integer.parseInt(vendorIdStr));
            }

            String productIdStr = req.getParameter("product_id");
            if (productIdStr != null && !productIdStr.isEmpty()) {
                dto.setProduct_id(Integer.parseInt(productIdStr));
            }

            String billAmountStr = req.getParameter("bill_amount");
            if (billAmountStr != null && !billAmountStr.isEmpty()) {
                dto.setBill_amount(new BigDecimal(billAmountStr));
            }

            dto.setDate_in(req.getParameter("date_in"));
            dto.setDate_out(req.getParameter("date_out"));
            dto.setWarranty_start_date(req.getParameter("warranty_start_date"));
            dto.setWarranty_end_date(req.getParameter("warranty_end_date"));

            String statusStr = req.getParameter("status");
            if (statusStr != null && !statusStr.isEmpty()) {
                dto.setStatus(statusStr.trim());
            }

            dto.setDate_added(req.getParameter("date_added"));
            dto.setDate_updated(req.getParameter("date_updated"));

            String isDeletedStr = req.getParameter("is_deleted");
            if (isDeletedStr != null && !isDeletedStr.isEmpty()) {
                dto.setIs_deleted(Integer.parseInt(isDeletedStr));
            }

            boolean success;
            if ("update".equalsIgnoreCase(action)) {
                success = dao.updatePurchaseOrder(dto);
            } else {
                success = dao.addPurchaseOrder(dto);
            }

            resp.getWriter().write(success ? "success" : "error");

        } catch (NumberFormatException nfe) {
            nfe.printStackTrace();
            resp.getWriter().write("error: invalid number format");
        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().write("error");
        }
    }
}
