package siepl_amc.trn.trn_purchase_orders;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import siepl_amc.utility.DBConfig;

public class PurchaseOrderDAO {

	public PurchaseOrderDTO getPurchaseOrderById(int id) {
		PurchaseOrderDTO purchaseOrderDTO = null;

		String sql = "SELECT po.purchase_order_id, " + "v.vendor_id, v.vendor_name, "
				+ "p.product_id, p.model AS product_name, " + "po.bill_amount, " + "po.date_in, po.date_out, "
				+ "po.warranty_start_date, po.warranty_end_date, " + "po.status, " + "po.date_added, po.date_updated, "
				+ "po.is_deleted " + "FROM siepl_amc_trn_purchase_orders po "
				+ "JOIN siepl_amc_mst_vendors v  ON v.vendor_id  = po.vendor_id "
				+ "JOIN siepl_amc_mst_products p ON p.product_id = po.product_id "
				+ "WHERE po.purchase_order_id = ? AND po.is_deleted = 0";

		try (Connection con = DBConfig.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				purchaseOrderDTO = new PurchaseOrderDTO();

				purchaseOrderDTO.setPurchase_order_id(rs.getInt("purchase_order_id"));
				purchaseOrderDTO.setVendor_id(rs.getInt("vendor_id"));
				purchaseOrderDTO.setVendor_name(rs.getString("vendor_name"));
				purchaseOrderDTO.setProduct_id(rs.getInt("product_id"));
				purchaseOrderDTO.setProduct_name(rs.getString("product_name"));

				purchaseOrderDTO.setBill_amount(rs.getBigDecimal("bill_amount"));

				// Dates as String (safe for DATE/TIMESTAMP columns)
				purchaseOrderDTO.setDate_in(rs.getString("date_in"));
				purchaseOrderDTO.setDate_out(rs.getString("date_out"));
				purchaseOrderDTO.setWarranty_start_date(rs.getString("warranty_start_date"));
				purchaseOrderDTO.setWarranty_end_date(rs.getString("warranty_end_date"));

				purchaseOrderDTO.setStatus(rs.getString("status"));
				purchaseOrderDTO.setDate_added(rs.getString("date_added"));
				purchaseOrderDTO.setDate_updated(rs.getString("date_updated"));
				purchaseOrderDTO.setIs_deleted(rs.getInt("is_deleted"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return purchaseOrderDTO;
	}

	public boolean deletePurchaseOrder(String purchaseOrderIdStr) {
		String sql = "UPDATE siepl_amc_trn_purchase_orders " + "SET is_deleted = 1, date_updated = NOW() "
				+ "WHERE purchase_order_id = ?";

		try (Connection con = DBConfig.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setInt(1, Integer.parseInt(purchaseOrderIdStr));
			return ps.executeUpdate() > 0; // true if a row was updated
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean updatePurchaseOrder(PurchaseOrderDTO purchaseOrderDTO) {
		String sql = "UPDATE siepl_amc_trn_purchase_orders " + "SET vendor_id = ?, product_id = ?, bill_amount = ?, "
				+ "    date_in = ?, date_out = ?, " + "    warranty_start_date = ?, warranty_end_date = ?, "
				+ "    status = ?, date_updated = NOW() " + "WHERE purchase_order_id = ? AND is_deleted = 0";

		try (Connection con = DBConfig.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setInt(1, purchaseOrderDTO.getVendor_id());
			ps.setInt(2, purchaseOrderDTO.getProduct_id());
			ps.setBigDecimal(3, purchaseOrderDTO.getBill_amount());
			ps.setString(4, purchaseOrderDTO.getDate_in());
			ps.setString(5, purchaseOrderDTO.getDate_out());
			ps.setString(6, purchaseOrderDTO.getWarranty_start_date());
			ps.setString(7, purchaseOrderDTO.getWarranty_end_date());
			ps.setString(8, purchaseOrderDTO.getStatus());
			ps.setInt(9, purchaseOrderDTO.getPurchase_order_id());

			return ps.executeUpdate() > 0;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean addPurchaseOrder(PurchaseOrderDTO purchaseOrderDTO) {
		String sql = "INSERT INTO siepl_amc_trn_purchase_orders " + "(vendor_id, product_id, bill_amount, "
				+ " date_in, date_out, warranty_start_date, warranty_end_date, status , date_added) "
				+ "VALUES (?,?,?,?,?,?,?,?,NOW())";

		try (Connection con = DBConfig.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setInt(1, purchaseOrderDTO.getVendor_id());
			ps.setInt(2, purchaseOrderDTO.getProduct_id());
			ps.setBigDecimal(3, purchaseOrderDTO.getBill_amount());
			ps.setString(4, purchaseOrderDTO.getDate_in());
			ps.setString(5, purchaseOrderDTO.getDate_out());
			ps.setString(6, purchaseOrderDTO.getWarranty_start_date());
			ps.setString(7, purchaseOrderDTO.getWarranty_end_date());
			ps.setString(8, purchaseOrderDTO.getStatus());

			return ps.executeUpdate() > 0;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public List<PurchaseOrderDTO> getSearchedPurchaseOrders(String query, Integer productId, String status) {
	    List<PurchaseOrderDTO> list = new ArrayList<>();
	    StringBuilder where = new StringBuilder();

	    if (query != null && !query.trim().isEmpty()) {
	        String q = query.trim().replace("'", "''");
	        // search vendor name OR product model OR status text
	        where.append(" AND (v.vendor_name LIKE '%").append(q).append("%' ")
	             .append("OR p.model LIKE '%").append(q).append("%' ")
	             .append("OR po.status LIKE '%").append(q).append("%') ");
	    }
	    if (productId != null && productId > 0) {
	        where.append(" AND p.product_id = ").append(productId);
	    }
	    if (status != null && !status.trim().isEmpty()) {
	        String s = status.trim().replace("'", "''");
	        where.append(" AND po.status = '").append(s).append("' ");
	    }

	    String sql =
	        "SELECT po.purchase_order_id, " +
	        "       v.vendor_id, v.vendor_name, " +
	        "       p.product_id, p.model AS product_name, " +
	        "       po.bill_amount, po.date_in, po.date_out, " +
	        "       po.warranty_start_date, po.warranty_end_date, " +
	        "       po.status, po.date_added, po.date_updated, po.is_deleted " +
	        "FROM siepl_amc_trn_purchase_orders po " +
	        "JOIN siepl_amc_mst_vendors v  ON v.vendor_id  = po.vendor_id " +
	        "JOIN siepl_amc_mst_products p ON p.product_id = po.product_id " +
	        "WHERE po.is_deleted = 0 " + where +
	        "ORDER BY po.purchase_order_id ASC";

	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {

	        while (rs.next()) {
	            PurchaseOrderDTO purchaseOrderDTO = new PurchaseOrderDTO();
	            purchaseOrderDTO.setPurchase_order_id(rs.getInt("purchase_order_id"));
	            purchaseOrderDTO.setVendor_id(rs.getInt("vendor_id"));
	            purchaseOrderDTO.setVendor_name(rs.getString("vendor_name"));   // ✅ vendor name available
	            purchaseOrderDTO.setProduct_id(rs.getInt("product_id"));
	            purchaseOrderDTO.setProduct_name(rs.getString("product_name")); // ✅ product model available
	            purchaseOrderDTO.setBill_amount(rs.getBigDecimal("bill_amount"));
	            purchaseOrderDTO.setDate_in(rs.getString("date_in"));
	            purchaseOrderDTO.setDate_out(rs.getString("date_out"));
	            purchaseOrderDTO.setWarranty_start_date(rs.getString("warranty_start_date"));
	            purchaseOrderDTO.setWarranty_end_date(rs.getString("warranty_end_date"));
	            purchaseOrderDTO.setStatus(rs.getString("status"));
	            purchaseOrderDTO.setDate_added(rs.getString("date_added"));
	            purchaseOrderDTO.setDate_updated(rs.getString("date_updated"));
	            purchaseOrderDTO.setIs_deleted(rs.getInt("is_deleted"));

	            list.add(purchaseOrderDTO);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return list;
	}


}
