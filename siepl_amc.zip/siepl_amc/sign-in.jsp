<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/img/favicon.png">
    <title>SIEPL | Sign Up</title>

    <!-- Fonts and icons -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700,900" />
    <link href="../assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" />

    <!-- CSS Files -->
    <link id="pagestyle" href="../assets/css/material-dashboard.css?v=3.2.0" rel="stylesheet" />

    <style>
        body {
            background: linear-gradient(135deg, #f3f4f6 0%, #e0e7ff 100%);
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background: rgba(255, 255, 255, 0.98) !important;
            backdrop-filter: blur(12px);
            border-radius: 0.75rem;
            padding: 1rem 2rem;
            margin: 1rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .navbar-brand {
            color: #1e40af !important;
            font-size: 1.6rem;
            font-weight: 700;
            transition: color 0.3s ease;
        }

        .navbar-brand:hover {
            color: #3b82f6 !important;
        }

        .page-header {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: url('https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=1950&q=80');
            background-size: cover;
            background-position: center;
        }

        .card {
            background: white;
            border-radius: 1.25rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            max-width: 600px;
            width: 100%;
            margin: 0 auto;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
        }

        .card-header {
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%) !important;
            padding: 2rem;
            text-align: center;
            border-radius: 1rem 1rem 0 0;
        }

        .card-header h4 {
            margin: 0;
            color: white;
            font-weight: 600;
            font-size: 2rem;
        }

        .card-body {
            padding: 2.5rem;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .input-group {
            position: relative;
            margin-bottom: 2rem;
            width: 100%;
            max-width: 500px;
        }

        .form-control {
            width: 100%;
            padding: 1rem;
            border: 1px solid #d1d5db;
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: all 0.3s ease;
            box-sizing: border-box;
        }

        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .form-label {
            position: absolute;
            top: 1rem;
            left: 1rem;
            font-size: 1rem;
            color: #6b7280;
            transition: all 0.2s ease;
            pointer-events: none;
        }

        .form-control:focus + .form-label,
        .form-control:not(:placeholder-shown) + .form-label {
            top: -0.75rem;
            left: 0.75rem;
            font-size: 0.75rem;
            color: #3b82f6;
            background: white;
            padding: 0 0.25rem;
        }

        .form-check {
            margin-bottom: 1.5rem;
            width: 100%;
            max-width: 500px;
        }

        .btn {
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%) !important;
            color: white !important;
            border: none;
            border-radius: 0.5rem;
            padding: 1rem;
            font-size: 1.1rem;
            font-weight: 600;
            width: 100%;
            max-width: 500px;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.3);
        }

        .text-sm {
            font-size: 0.875rem;
            color: #4b5563;
            text-align: center;
            margin-top: 1.5rem;
        }

        .text-gradient {
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: 600;
        }

        .footer {
            margin-top: 2rem;
            text-align: center;
            color: #6b7280;
            font-size: 0.875rem;
        }

        .footer a {
            color: #1e40af;
            font-weight: 600;
            text-decoration: none;
        }

        .footer a:hover {
            color: #3b82f6;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg top-0 z-index-3 shadow py-2 fixed-top mx-4 mt-3">
        <div class="container-fluid ps-2 pe-0">
            <a class="navbar-brand font-weight-bolder ms-lg-0 ms-3" href="../pages/dashboard.html">
                SIEPL
            </a>
        </div>
    </nav>
    <!-- End Navbar -->

    <main class="page-header">
        <div class="container my-auto">
            <div class="row justify-content-center">
                <div class="col-lg-6 col-md-8 col-12">
                    <div class="card z-index-0 fadeIn3 fadeInBottom">
                        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                            <div class="shadow-dark py-4 text-center">
                                <h4>SIEPL LOGIN</h4>
                            </div>
                        </div>
                        <div class="card-body px-4 py-5">
                            <form id="loginForm" action="<%=request.getContextPath()%>/categories.jsp" method="post" role="form">
                                <div class="input-group input-group-outline my-3">
                                    <input type="text" class="form-control" name="username" id="usernameId" required placeholder=" ">
                                    <label class="form-label">Username</label>
                                </div>
                                <div class="input-group input-group-outline mb-3">
                                    <input type="password" class="form-control" name="password" id="passwordId" required placeholder=" ">
                                    <label class="form-label">Password</label>
                                </div>

                                <!-- Remember Me Option -->
                                <div class="form-check form-switch d-flex align-items-center mb-3">
                                    <input class="form-check-input" type="checkbox" id="rememberMe">
                                    <label class="form-check-label mb-0 ms-3" for="rememberMe">Remember me</label>
                                </div>

                                <div class="text-center">
                                    <button type="submit" class="btn w-100 my-3">Sign Up</button>
                                </div>
                                <p class="mt-3 text-sm">
                                    Already have an account?
                                    <a href="login.jsp" class="text-gradient font-weight-bold">Sign in</a>
                                </p>
                            </form>
                        </div>
                    </div>
                    <footer class="footer mt-4">
                        <div class="copyright">
                              <script>document.write(new Date().getFullYear())</script>,
                            made with <i class="fa fa-heart text-danger"></i> by
                            <a href="https://www.creative-tim.com" target="_blank">SatyajeetIndia</a>
                        </div>
                    </footer>
                </div>
            </div>
        </div>
    </main>

    <!-- Core JS Files -->
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
    <script src="../assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="../assets/js/plugins/smooth-scrollbar.min.js"></script>
    <script src="../assets/js/material-dashboard.min.js?v=3.2.0"></script>

    <!-- Remember Me Script -->
    <script>
        // Load cookies on page load
        window.onload = function() {
            if (document.cookie) {
                const cookies = document.cookie.split("; ");
                cookies.forEach(cookie => {
                    let [name, value] = cookie.split("=");
                    if (name === "username") {
                        document.getElementById("usernameId").value = value;
                    }
                    if (name === "password") {
                        document.getElementById("passwordId").value = value;
                    }
                });
            }
        };

        // Set cookie function
        function setCookie(name, value, days) {
            const date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            const expires = "expires=" + date.toUTCString();
            document.cookie = name + "=" + value + ";" + expires + ";path=/";
        }

        // Save credentials if Remember Me is checked
        document.getElementById('loginForm').onsubmit = function(event) {
            if (document.getElementById('rememberMe').checked) {
                const username = document.getElementById('usernameId').value;
                const password = document.getElementById('passwordId').value;
                setCookie('username', username, 7);
                setCookie('password', password, 7);
            }
        };
    </script>
</body>
</html>
