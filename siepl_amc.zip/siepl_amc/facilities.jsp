<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Facilities</title>

    <!-- Bootstrap CSS + Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body { background-color: #f8f9fc; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .card-custom { border-radius:16px; box-shadow:0 8px 24px rgba(0,0,0,0.12); transition:transform .2s, box-shadow .2s; border:none; }
        .card-custom:hover { transform:translateY(-3px); box-shadow:0 12px 32px rgba(0,0,0,0.18); }
        .btn-primary, .btn-danger { border-radius:12px; padding:8px 18px; font-weight:500; }
        .btn-primary { background:linear-gradient(to right,#4e54c8,#8f94fb); border:none; }
        .btn-danger { background:linear-gradient(to right,#ff416c,#ff4b2b); border:none; }
        .table-custom { border-radius:12px; overflow:hidden; box-shadow:0 4px 12px rgba(0,0,0,0.05); }
        .table thead { background-color:#4e54c8; color:white; }
        .table thead th { border:none; padding:15px; }
        .table-striped tbody tr:nth-of-type(odd){ background-color:#fafbff; }
        .table-hover tbody tr:hover{ background-color:#e9f0ff; }
        .table td{ padding:15px; border-color:#f1f4f9; }
        .action-btn { margin-left:4px; }
        .modal-content { border-radius:16px; border:none; box-shadow:0 12px 32px rgba(0,0,0,0.18); }
        .modal-header { background:linear-gradient(to right,#4e54c8,#8f94fb); color:white; border-radius:16px 16px 0 0; }
        .modal-title { font-weight:600; }
        .form-control { border-radius:12px; padding:12px 16px; border:1px solid #e1e5ef; }
        .form-control:focus { box-shadow:0 0 0 3px rgba(78,84,200,0.2); border-color:#4e54c8; }
        .app-shell { display:flex; gap:0; align-items:flex-start; }
        .main-content { flex:1 1 auto; min-width:0; }
        .main-content .container { padding-left:2rem; padding-right:2rem; }
        @media (max-width:768px){ .app-shell{ flex-direction:column; } .main-content .container{ padding-left:1rem; padding-right:1rem; } }
    </style>
</head>
<body>

<div class="app-shell">

    <jsp:include page="sidebar.jsp" />

    <div class="main-content">
      <div class="container py-5">

        <div class="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h2 class="fw-bold mb-1">Facility Management</h2>
            <p class="text-muted">Manage your Facilities</p>
          </div>
          <button type="button" class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#addFacilityModal">
            + Add New Facility
          </button>
        </div>

        <div class="card card-custom">
          <div class="card-body">
            <h5 class="mb-3 fw-semibold">Facilities</h5>

            <!-- Search -->
            <form class="d-flex mb-3 row gx-3 gy-2 align-items-center" role="search" id="searchFacilityForm">
                <div class="col-auto">
                    <input class="form-control me-2" type="search"
                           placeholder="Search Product / Customer / Category / Software..."
                           aria-label="Search" name="query" id="query">
                </div>
                <div class="col-auto">
                    <select class="form-select" name="status" id="status">
                        <option value="">-- Select Status --</option>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                    </select>
                </div>
                <div class="col-auto">
                    <button type="button" class="btn btn-primary" onclick="loadFacilityList()">Search</button>
                </div>
            </form>

            <div class="table-responsive table-custom">
              <table class="table table-striped table-hover align-middle mb-0">
                <thead>
                  <tr>
                      <th>Customer</th>
                      <th>Product</th>
                      <th>Category</th>
                      <th>Software</th>
                      <th>Service Start</th>
                      <th>Service End</th>
                      <th>Status</th>
                      <th>Actions</th>
                  </tr>
                </thead>
                <tbody id="FacilityTblBody">
                  <!-- dynamic rows -->
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="addFacilityModal" tabindex="-1" aria-labelledby="addFacilityModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content text-dark">
      <div class="modal-header">
        <h5 class="modal-title" id="addFacilityModalLabel">Add New Facility</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="facility" method="post" name="FacilityForm" id="FacilityForm">
            <input type="hidden" name="facility_id" id="facility_id">
            <input type="hidden" name="action" id="actionID"/>

            <div class="mb-3">
                <label class="form-label">Customer</label>
                <select name="customer_id" id="customer_id" class="form-select" required>
                    <option value="">Select Customer</option>
                </select>
                <span id="customerError" style="color: grey"></span>
            </div>

            <div class="mb-3">
                <label class="form-label">Product</label>
                <select name="product_id" id="product_id" class="form-select" required>
                    <option value="">Select Product</option>
                </select>
                <span id="productError" style="color: grey"></span>
            </div>

            <div class="mb-3">
                <label class="form-label">Category</label>
                <select name="category_id" id="category_id" class="form-select" required>
                    <option value="">Select Category</option>
                </select>
                <span id="categoryError" style="color: grey"></span>
            </div>

            <div class="mb-3">
                <label class="form-label">Software Service</label>
                <select name="service_id" id="service_id" class="form-select" required>
                    <option value="">Select Software Service</option>
                </select>
                <span id="serviceError" style="color: grey"></span>
            </div>

            <div class="mb-3">
                <label class="form-label">Service Start Date</label>
                <input type="date" class="form-control" id="service_start_date" name="service_start_date" required>
                <span id="startError" style="color: grey"></span>
            </div>

            <div class="mb-3">
                <label class="form-label">Service End Date</label>
                <input type="date" class="form-control" id="service_end_date" name="service_end_date" required>
                <span id="endError" style="color: grey"></span>
            </div>

            <div class="mb-3">
                <label class="form-label">Status</label>
                <select name="status" id="status_modal" class="form-select" required>
                    <option value="">-- Select Status --</option>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                </select>
                <span id="statusError" style="color: grey"></span>
            </div>

            <div class="d-grid gap-2">
                <button type="button" onclick="validateFacilityInfo()" class="btn btn-primary" id="addbtnID">Add Facility</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
    loadCustomerList();
    loadProductList();
    loadCategoryList();
    loadServiceList();
    loadFacilityList();
});

function loadFacilityList(){
    $("#FacilityTblBody").html('<tr><td colspan="8" class="text-center">Loading...</td></tr>');
    $.ajax({
        url:'facilityList',
        type:'GET',
        data:{
            query: $("#query").val(),
            status: $("#status").val()
        },
        success:function(data){
            $("#FacilityTblBody").empty();
            $.map(data,function(f){
                $("#FacilityTblBody").append(createRowElement(f));
            });
        },
        error:function(){ alert('Error fetching facility data'); }
    });
}

function validateFacilityInfo(){
    $("#customerError,#productError,#categoryError,#serviceError,#startError,#endError,#statusError").html('');

    var customerId=$("#customer_id").val().trim(),
        productId=$("#product_id").val().trim(),
        categoryId=$("#category_id").val().trim(),
        serviceId=$("#service_id").val().trim(),
        startDate=$("#service_start_date").val().trim(),
        endDate=$("#service_end_date").val().trim(),
        status=$("#status_modal").val().trim(),
        isValid=true;

    if(customerId===''){ $("#customerError").html("Customer is required."); isValid=false; }
    if(productId===''){ $("#productError").html("Product is required."); isValid=false; }
    if(categoryId===''){ $("#categoryError").html("Category is required."); isValid=false; }
    if(serviceId===''){ $("#serviceError").html("Software Service is required."); isValid=false; }
    if(startDate===''){ $("#startError").html("Service Start Date is required."); isValid=false; }
    if(endDate===''){ $("#endError").html("Service End Date is required."); isValid=false; }
    if(status===''){ $("#statusError").html("Status is required."); isValid=false; }

    if(isValid){
        $.ajax({
            url:'facility',
            type:'POST',
            data:$('#FacilityForm').serialize(),
            success:function(data){
                data=$.trim(data);
                if(data==='success'){
                    loadFacilityList();
                    $('#addFacilityModal').modal('hide');
                }else{ alert('Save failed'); }
            },
            error:function(){ alert('Something went wrong.'); }
        });
    }
}

function createRowElement(f){
    var row="<tr>";
    row+="<td>"+f.customer_name+"</td>";
    row+="<td>"+f.product_name+"</td>";
    row+="<td>"+f.category_name+"</td>";
    row+="<td>"+f.software_name+"</td>";
    row+="<td>"+f.service_start_date+"</td>";
    row+="<td>"+f.service_end_date+"</td>";
    row+="<td>"+f.status+"</td>";
    row+="<td>";
    row+="<button class='btn btn-sm btn-primary' onclick='editFacility("+f.facility_id+")'>Edit</button> ";
    row+="<button class='btn btn-sm btn-danger' onclick='doDelete("+f.facility_id+")'>Delete</button>";
    row+="</td></tr>";
    return row;
}

function loadCustomerList(){
    $.ajax({
        url:'customerList',
        type:'GET',
        success:function(data){
            var $c=$("#customer_id");
            $c.empty().append('<option value="">Select Customer</option>');
            $.map(data,function(c){ $c.append('<option value="'+c.customer_id+'">'+c.customer_name+'</option>'); });
        }
    });
}
function loadProductList(){
    $.ajax({
        url:'productList',
        type:'GET',
        success:function(data){
            var $p=$("#product_id");
            $p.empty().append('<option value="">Select Product</option>');
            $.map(data,function(p){ $p.append('<option value="'+p.product_id+'">'+p.model+'</option>'); });
        }
    });
}
function loadCategoryList(){
    $.ajax({
        url:'categoryList',
        type:'GET',
        success:function(data){
            var $cat=$("#category_id");
            $cat.empty().append('<option value="">Select Category</option>');
            $.map(data,function(cat){ $cat.append('<option value="'+cat.category_id+'">'+cat.category_name+'</option>'); });
        }
    });
}
function loadServiceList(){
    $.ajax({
        url:'serviceList',
        type:'GET',
        success:function(data){
            var $s=$("#service_id");
            $s.empty().append('<option value="">Select Software Service</option>');
            $.map(data,function(s){ $s.append('<option value="'+s.service_id+'">'+s.software_name+'</option>'); });
        }
    });
}

function doDelete(facility_id){
    if(confirm("Delete this Facility?")){
        $('#actionID').val('delete');
        $('#facility_id').val(facility_id);
        $.ajax({
            url:'facility',
            type:'POST',
            data:$('#FacilityForm').serialize(),
            success:function(data){
                if($.trim(data)==='success'){ loadFacilityList(); $('#addFacilityModal').modal('hide'); }
                else { console.log("Not deleted"); }
            }
        });
    }
}

function editFacility(facility_id){
    $('#addFacilityModalLabel').text('Edit Facility');
    $.ajax({
        url:'facility',
        type:'GET',
        data:{facility_id:facility_id},
        dataType:'json',
        success:function(f){
            if(f && f.facility_id){
                $('#actionID').val('update');
                $('#facility_id').val(f.facility_id);
                $('#customer_id').val(f.customer_id);
                $('#product_id').val(f.product_id);
                $('#category_id').val(f.category_id);
                $('#service_id').val(f.service_id);
                $('#service_start_date').val(f.service_start_date);
                $('#service_end_date').val(f.service_end_date);
                $('#status_modal').val(f.status);
                $('#addbtnID').text('Update');
                $('#addFacilityModal').modal('show');
            } else { alert('Error fetching facility data'); }
        },
        error:function(){ alert('Error fetching facility data'); }
    });
}

$(document).on('click','[data-bs-target="#addFacilityModal"]',function(){
    $('#addFacilityModalLabel').text("Add New Facility");
    $('#addbtnID').text('Add Facility');
    $('#FacilityForm')[0].reset();
    $('#facility_id').val('');
    $('#customerError,#productError,#categoryError,#serviceError,#startError,#endError,#statusError').html('');
});
</script>
</body>
</html>
