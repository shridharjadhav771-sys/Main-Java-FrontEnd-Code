<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Sales Orders</title>

  <!-- Bootstrap CSS + Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body { background-color: #f8f9fc; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; } 
        .card-custom { border-radius: 16px; box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12); transition: transform 0.2s ease, box-shadow 0.2s ease; border: none; } 
        .card-custom:hover { transform: translateY(-3px); box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18); } 
        .btn-primary, .btn-danger { border-radius: 12px; padding: 8px 18px; font-weight: 500; } 
        .btn-primary { background: linear-gradient(to right, #4e54c8, #8f94fb); border: none; } 
        .btn-danger { background: linear-gradient(to right, #ff416c, #ff4b2b); border: none; } 
        .table-custom { border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); } 
        .table thead { background-color: #4e54c8; color: white; } 
        .table thead th { border: none; padding: 15px; } 
        .table-striped tbody tr:nth-of-type(odd) { background-color: #fafbff; } 
        .table-hover tbody tr:hover { background-color: #e9f0ff; } 
        .table td { padding: 15px; border-color: #f1f4f9; } 
        .action-btn { margin-left: 4px; }
        .modal-content { border-radius: 16px; border: none; box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18); } 
        .modal-header { background: linear-gradient(to right, #4e54c8, #8f94fb); color: white; border-radius: 16px 16px 0 0; } 
        .modal-title { font-weight: 600; } 
        .form-control { border-radius: 12px; padding: 12px 16px; border: 1px solid #e1e5ef; } 
        .form-control:focus { box-shadow: 0 0 0 3px rgba(78, 84, 200, 0.2); border-color: #4e54c8; } 
        .search-box { position: relative; } 
        .search-box .form-control { padding-left: 45px; } 
        .search-box .bi-search { position: absolute; left: 15px; top: 12px; color: #6c757d; } 
        .app-shell { display: flex; gap: 0; align-items: flex-start; } 
        .main-content { flex: 1 1 auto; min-width: 0; } 
        .main-content .container { padding-left: 2rem; padding-right: 2rem; } 
        @media (max-width: 768px) { .app-shell { flex-direction: column; } .main-content .container { padding-left: 1rem; padding-right: 1rem; } }
  </style>
</head>
<body>

<div class="app-shell">
  <jsp:include page="sidebar.jsp"/>

  <div class="main-content">
    <div class="container py-5">

      <!-- Header -->
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 class="fw-bold mb-1">Sales Order Management</h2>
          <p class="text-muted">Manage customer sales orders</p>
        </div>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addSOModal">
          + Add Sales Order
        </button>
      </div>

      <!-- Card -->
      <div class="card card-custom">
        <div class="card-body">
          <h5 class="mb-3 fw-semibold">Sales Orders</h5>

          <!-- Search -->
          <form class="d-flex mb-3 row gx-3 gy-2" role="search" id="searchSOForm">
            <div class="col-auto">
              <input class="form-control" type="search" placeholder="Search Customer / Product..."
                     name="query" id="query">
            </div>
            <div class="col-auto">
    <input class="form-control" type="date" name="startDate" id="startDate" placeholder="Start Date">
  </div>
  <div class="col-auto">
    <input class="form-control" type="date" name="endDate" id="endDate" placeholder="End Date">
  </div>
            <div class="col-auto">
              <button type="button" class="btn btn-primary" onclick="loadSOList()">Search</button>
            </div>
          </form>

          <!-- Table -->
          <div class="table-responsive">
            <table class="table table-striped table-hover align-middle mb-0">
              <thead>
                <tr>
                  <th>Customer</th>
                  <th>Product</th>
                  <th>Bill Amount</th>
                  <th>Date Out</th>
                  <th>Warranty Start</th>
                  <th>Warranty End</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="SOTblBody">
                <!-- Dynamic rows -->
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="addSOModal" tabindex="-1" aria-labelledby="addSOModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content text-dark">
      <div class="modal-header">
        <h5 class="modal-title" id="addSOModalLabel">Add Sales Order</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form action="salesOrder" method="post" id="SOForm">
          <input type="hidden" name="sales_order_id" id="sales_order_id">
          <input type="hidden" name="action" id="actionID"/>

          <div class="mb-3">
            <label for="customer_id" class="form-label">Customer</label>
            <select name="customer_id" id="customer_id" class="form-select" required>
              <option value="">Select Customer</option>
            </select>
            <span id="customerError" style="color: grey"></span>
          </div>

          <div class="mb-3">
            <label for="product_id" class="form-label">Product</label>
            <select name="product_id" id="product_id" class="form-select" required>
              <option value="">Select Product</option>
            </select>
            <span id="productError" style="color: grey"></span>
          </div>

          <div class="mb-3">
            <label for="bill_amount" class="form-label">Bill Amount</label>
            <input type="text" class="form-control" id="bill_amount" name="bill_amount" required>
            <span id="billError" style="color: grey"></span>
          </div>

          <div class="mb-3">
            <label for="date_out" class="form-label">Date Out</label>
            <input type="date" class="form-control" id="date_out" name="date_out" required>
            <span id="dateOutError" style="color: grey"></span>
          </div>

          <div class="mb-3">
            <label for="warranty_start_date" class="form-label">Warranty Start</label>
            <input type="date" class="form-control" id="warranty_start_date" name="warranty_start_date" required>
            <span id="wsdError" style="color: grey"></span>
          </div>

          <div class="mb-3">
            <label for="warranty_end_date" class="form-label">Warranty End</label>
            <input type="date" class="form-control" id="warranty_end_date" name="warranty_end_date" required>
            <span id="wedError" style="color: grey"></span>
          </div>

          <div class="d-grid gap-2">
            <button type="button" onclick="validateSOInfo()" class="btn btn-primary" id="addbtnID">Add Sales Order</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS + jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
  loadCustomerList();
  loadProductList();
  loadSOList();
});

function loadSOList(){
  $("#SOTblBody").html('<tr><td colspan="7" class="text-center">Loading...</td></tr>');
  $.ajax({
    url: 'salesOrderList',
    type: 'GET',
    data: { query: $("#query").val(),
    	 startDate: $("#startDate").val(),
         endDate: $("#endDate").val()},
    success: function(data){
      $("#SOTblBody").empty();
      $.map(data, function(so){
        $("#SOTblBody").append(createRowElement(so));
      });
    },
    error: function(){ alert('Error fetching sales orders'); }
  });
}

function validateSOInfo(){
  $("#customerError,#productError,#billError,#dateOutError,#wsdError,#wedError").html('');
  var customerId = $("#customer_id").val().trim(),
      productId = $("#product_id").val().trim(),
      billAmount = $("#bill_amount").val().trim(),
      dateOut = $("#date_out").val().trim(),
      wsd = $("#warranty_start_date").val().trim(),
      wed = $("#warranty_end_date").val().trim(),
      isValid = true;

  if(customerId===''){ $("#customerError").html("Customer required"); isValid=false; }
  if(productId===''){ $("#productError").html("Product required"); isValid=false; }
  if(billAmount===''){ $("#billError").html("Bill amount required"); isValid=false; }
  if(dateOut===''){ $("#dateOutError").html("Date out required"); isValid=false; }
  if(wsd===''){ $("#wsdError").html("Warranty start required"); isValid=false; }
  if(wed===''){ $("#wedError").html("Warranty end required"); isValid=false; }

  
  if(isValid){
      $.ajax({
          url: 'salesOrder',
          type: 'POST',
          data: $('#SOForm').serialize(),
          success: function(data){
              data = $.trim(data);
              if(data === 'success'){
            	  loadSOList();
                  $('#addSOModal').modal('hide');
              } else { alert('Save failed'); }
          },
          error: function(){ alert('Something went wrong. Please try again'); }
      });
  }
}

function createRowElement(so){
  var row = "<tr>";
  row += "<td>" + so.customer_name + "</td>";
  row += "<td>" + so.product_name + "</td>";
  row += "<td>" + so.bill_amount + "</td>";
  row += "<td>" + so.date_out + "</td>";
  row += "<td>" + so.warranty_start_date + "</td>";
  row += "<td>" + so.warranty_end_date + "</td>";
  row += "<td>";
  row += "<button class='btn btn-sm btn-primary' onclick='editSO(" + so.sales_order_id + ")'>Edit</button> ";
  row += "<button class='btn btn-sm btn-danger' onclick='doDelete(" + so.sales_order_id + ")'>Delete</button>";
  row += "</td></tr>";
  return row;
}


function loadCustomerList(){
    $.ajax({
        url: 'customerList',
        type: 'GET',
        success: function(data){
            var $cust = $("#customer_id");
            $cust.empty();
            $cust.append('<option value="">Select Customer</option>');
            $.map(data, function(c){ $cust.append('<option value="'+c.customer_id+'">'+c.customer_name+'</option>'); });
        },
        error: function(){ alert('Error fetching product data'); }
    });
}

function loadProductList(){
    $.ajax({
        url: 'productList',
        type: 'GET',
        success: function(data){
            var $product = $("#product_id");
            $product.empty();
            $product.append('<option value="">Select Product</option>');
            $.map(data, function(p){ $product.append('<option value="'+p.product_id+'">'+p.model+'</option>'); });
        },
        error: function(){ alert('Error fetching product data'); }
    });
}



function doDelete(sales_order_id){
    if(confirm("Delete this Sales Order?")){
        $('#actionID').val('delete');
        $('#sales_order_id').val(sales_order_id);
        $.ajax({
            url:'salesOrder',
            type:'POST',
            data: $('#SOForm').serialize(),
            success: function(data){
                if($.trim(data)==='success'){ 
                	loadSOList(); 
                $('#addSOModal').modal('hide'); 
                }
                else { console.log("Not deleted"); }
            },
            error: function(){ alert('Something went wrong.'); }
        });
    }
}


function editSO(id){
  $('#addSOModalLabel').text('Edit Sales Order');
  $.ajax({
    url:'salesOrder',
    type:'GET',
    data:{ sales_order_id:id },
    dataType:'json',
    success:function(so){
      if(so){
        $('#actionID').val('update');
        $('#sales_order_id').val(so.sales_order_id);
        $('#customer_id').val(so.customer_id);
        $('#product_id').val(so.product_id);
        $('#bill_amount').val(so.bill_amount);
        $('#date_out').val(so.date_out);
        $('#warranty_start_date').val(so.warranty_start_date);
        $('#warranty_end_date').val(so.warranty_end_date);
        $('#addbtnID').text('Update');
        $('#addSOModal').modal('show');
      }
    }
  });
}

$(document).on('click','[data-bs-target="#addSOModal"]', function(){
  $('#addSOModalLabel').text('Add Sales Order');
  $('#addbtnID').text('Add Sales Order');
  $('#SOForm')[0].reset();
  $('#sales_order_id').val('');
});
</script>
</body>
</html>
