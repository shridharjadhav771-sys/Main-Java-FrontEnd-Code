<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .sidebar {
            width: 300px;
            height: 100vh;
            background: #ffffff;
            border-right: 1px solid #e5e5e5;
            display: flex;
            flex-direction: column;
        }
        .sidebar-header {
            background: linear-gradient(135deg, #007bff, #0dcaf0);
            color: #fff;
            padding: 15px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        .sidebar-header i {
            font-size: 1.5rem;
            margin-right: 8px;
        }
        .nav-section {
            flex: 1;
            overflow-y: auto; /* enable scroll */
            padding-right: 6px; /* space for scrollbar */
        }
        .nav-link {
            border-radius: 8px;
            font-weight: 500;
            padding: 10px 12px;
            margin-bottom: 4px;
            transition: all 0.2s ease-in-out;
        }
        .nav-link:hover {
            background-color: #f0f4ff;
            color: #0d6efd !important;
        }
        .nav-link.active {
            background-color: #0d6efd !important;
            color: #fff !important;
        }
        .quick-stat-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 10px 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
            transition: 0.2s;
        }
        .quick-stat-card:hover {
            background: #e9f3ff;
        }
        .user-info {
            margin-top: auto;
            background: #f8f9fa;
            border-radius: 12px;
            padding: 12px;
            display: flex;
            align-items: center;
        }
        .user-info i {
            font-size: 1.8rem;
            margin-right: 10px;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="sidebar p-3 shadow-sm">
        <!-- Brand -->
        <div class="sidebar-header">
            <i class="bi bi-gear-fill"></i>
            <span>AMC Pro</span>
        </div>

        <!-- Navigation -->
        <div class="nav-section">
            <h6 class="text-uppercase text-muted small fw-bold">Main Navigation</h6>
            <ul class="nav nav-pills flex-column mb-auto mt-2">
                <li>
                    <a href="dashboard.jsp" class="nav-link active d-flex align-items-center">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <!-- Dummy Modules -->
                <li>
                    <a href="categories.jsp" class="nav-link text-dark d-flex align-items-center">
                        <i class="bi bi-tags me-2"></i> Categories
                    </a>
                </li>
                <li>
                    <a href="subcategories.jsp" class="nav-link text-dark d-flex align-items-center">
                        <i class="bi bi-tags-fill me-2"></i> Sub Categories
                    </a>
                </li>
                <li>
                    <a href="vendors.jsp" class="nav-link text-dark d-flex align-items-center">
                        <i class="bi bi-person-workspace me-2"></i> Vendors
                    </a>
                </li>
                
                <li>
                    <a href="products.jsp" class="nav-link text-dark d-flex align-items-center">
                        <i class="bi bi-inboxes me-2"></i> Products
                    </a>
                </li>
                <li>
                    <a href="customers.jsp" class="nav-link text-dark d-flex align-items-center">
                        <i class="bi bi-people me-2"></i> Customers
                    </a>
                </li>
                <li>
                    <a href="purchaseOrders.jsp" class="nav-link text-dark d-flex align-items-center">
                        <i class="bi bi-cart-check me-2"></i> Purchase Orders
                    </a>
                </li>
                <li>
                    <a href="salesOrders.jsp" class="nav-link text-dark d-flex align-items-center">
                        <i class="bi bi-journal-text me-2"></i> Sales Orders
                    </a>
                </li>
                
                
                <li>
                    <a href="services.jsp" class="nav-link text-dark d-flex align-items-center">
                        <i class="bi bi-pc-display me-2"></i> Software & Services
                    </a>
                </li>
                <li>
                    <a href="facilities.jsp" class="nav-link text-dark d-flex align-items-center">
                       <i class="bi bi-person-gear me-2"></i> Facility Management
                    </a>
                </li>
                <li>
                    <a href="units.jsp" class="nav-link text-dark d-flex align-items-center">
                        <i class="bi bi-box-seam me-2"></i> Units
                    </a>
                </li>
                <li>
                    <a href="reports.jsp" class="nav-link text-dark d-flex align-items-center">
                        <i class="bi bi-bar-chart-line me-2"></i> Reports
                    </a>
                </li>
               <li>
                    <a href="licenseHistory.jsp" class="nav-link text-dark d-flex align-items-center">
                        <i class="bi bi-box-seam me-2"></i> License History
                    </a>
                </li>
            </ul>
        </div>

        <!-- Quick Stats -->
        <hr>
        <h6 class="text-uppercase text-muted small fw-bold">Quick Stats</h6>
        <div class="quick-stat-card">
            <span><i class="bi bi-key text-success me-2"></i> Active Licenses</span>
            <span class="badge bg-success">12</span>
        </div>
        <div class="quick-stat-card">
            <span><i class="bi bi-clipboard-check text-warning me-2"></i> Open Assignments</span>
            <span class="badge bg-warning text-dark">5</span>
        </div>
        <div class="quick-stat-card">
            <span><i class="bi bi-exclamation-triangle text-danger me-2"></i> Expiring Soon</span>
            <span class="badge bg-danger">3</span>
        </div>

        <!-- User Info -->
        <div class="user-info mt-3">
            <i class="bi bi-person-circle"></i>
            <div>
                <strong>Admin User</strong><br>
                <small class="text-muted">System Administrator</small>
            </div>
            <span class="badge bg-danger ms-auto rounded-circle">1</span>
        </div>
    </div>
</body>
</html>