	<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Vendors</title>

    <!-- Bootstrap CSS + Icons (ensure these are available once) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    /* --- Categories page styles --- */
    body {
      background-color: #f8f9fc;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .card-custom {
      border-radius: 16px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
      transition: transform 0.2s ease, box-shadow 0.2s ease;
      border: none;
    }
    .card-custom:hover {
      transform: translateY(-3px);
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18);
    }
    .btn-primary, .btn-danger {
      border-radius: 12px;
      padding: 8px 18px;
      font-weight: 500;
    }
    .btn-primary {
      background: linear-gradient(to right, #4e54c8, #8f94fb);
      border: none;
    }
    .btn-danger {
      background: linear-gradient(to right, #ff416c, #ff4b2b);
      border: none;
    }
    .table-custom {
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }
    .table thead {
      background-color: #4e54c8;
      color: white;
    }
    .table thead th {
      border: none;
      padding: 15px;
    }
    .table-striped tbody tr:nth-of-type(odd) {
      background-color: #fafbff;
    }
    .table-hover tbody tr:hover {
      background-color: #e9f0ff;
    }
    .table td {
      padding: 15px;
      border-color: #f1f4f9;
    }
    .action-btn {
      margin-left: 4px;
    }
    .modal-content {
      border-radius: 16px;
      border: none;
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18);
    }
    .modal-header {
      background: linear-gradient(to right, #4e54c8, #8f94fb);
      color: white;
      border-radius: 16px 16px 0 0;
    }
    .modal-title {
      font-weight: 600;
    }
    .form-control {
      border-radius: 12px;
      padding: 12px 16px;
      border: 1px solid #e1e5ef;
    }
    .form-control:focus {
      box-shadow: 0 0 0 3px rgba(78, 84, 200, 0.2);
      border-color: #4e54c8;
    }
    .search-box {
      position: relative;
    }
    .search-box .form-control {
      padding-left: 45px;
    }
    .search-box .bi-search {
      position: absolute;
      left: 15px;
      top: 12px;
      color: #6c757d;
    }

    /* Layout helpers so sidebar (provided by sidebar.jsp) sits left and main content fills right */
    .app-shell {
      display: flex;
      gap: 0;
      align-items: flex-start;
    }
    .main-content {
      flex: 1 1 auto;
      min-width: 0; /* ensures proper flex behavior */
    }
    /* container inside main-content keeps spacing consistent with your original page */
    .main-content .container {
      padding-left: 2rem;
      padding-right: 2rem;
    }

    @media (max-width: 768px) {
      .app-shell {
        flex-direction: column;
      }
      .main-content .container {
        padding-left: 1rem;
        padding-right: 1rem;
      }
    }
  </style>
</head>
<body>

  <div class="app-shell">

    <!-- SINGLE include tag to insert the sidebar -->
    <jsp:include page="sidebar.jsp" />

    <!-- Main content -->
    <div class="main-content">
      <div class="container py-5">

        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h2 class="fw-bold mb-1">Vendors Management</h2>
            <p class="text-muted">Organize your vendors into categories</p>
          </div>

          <!-- Button to open modal -->
          <button type="button" class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#addVendorModal">
            + Add New Vendors 
          </button>
        </div>

        <!-- Categories Card -->
        <div class="card card-custom" >
          <div class="card-body">
            <h5 class="mb-3 fw-semibold"> Vendors </h5>

            <!-- Search Form -->
            <form class="d-flex mb-3" role="search" id="searchForm">
              <input class="form-control me-2" type="search" placeholder="Search vendors..." aria-label="Search" name="query" id="query">
              <button class="btn btn-outline-primary" type="submit" >Search</button>
            </form>

            <!-- Table -->
            <div class="table-responsive table-custom">
              <table class="table table-striped table-hover align-middle mb-0">
                <thead>
                  <tr>
                    <th scope="col">Vendors Name</th>
                    <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody id="vendorsTblBody">
                  <!-- Dynamic rows will be injected by JS -->
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div> <!-- /.container -->
    </div> <!-- /.main-content -->

  </div> <!-- /.app-shell -->

  <!-- ===================== Modal ===================== -->
  <div class="modal fade" id="addVendorModal" tabindex="-1" aria-labelledby="addVendorModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
      <div class="modal-content text-dark">
        <div class="modal-header">
          <h5 class="modal-title" id="addVendorModalLabel">Add New Vendor</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body">
          <form action="vendor" method="post" name="vendorForm" id="vendorForm">

            <input type="hidden" name="vendor_id" id="vendor_id">
            <input type="hidden" name="action" id="actionID"/>

            <!-- Category Name -->
            <div class="mb-3">
              <label for="vendor_name" class="form-label">Vendor Name</label>
              <input type="text" class="form-control" id="vendor_name" name="vendor_name" required>
              <span id="nameError" style="color: grey"></span>
            </div>

            <!-- Buttons -->
            <div class="d-grid gap-2">
              <button type="button" onclick="validateInfo()" class="btn btn-primary" id="addbtnID">Add Vendor</button>
              <a href="vendorList" class="btn btn-secondary">Cancel</a>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS + jQuery (kept at bottom) -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"
          integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

  <script type="text/javascript">
    $(document).ready(function(){
        loadVendorList();
    });

    $("#searchForm").on("submit", function(event) {
        event.preventDefault();
        loadVendorList();
    });

    function loadVendorList() {
        $.ajax({
            url: 'vendorList',
            type: 'GET',
            data: {
                query: $("#query").val()
            },
            success: function(data) {
                console.log("Fetched Vendors:", data);

                $("#vendorsTblBody").empty();
                $.map(data, function(vendor) {
                    var rowData = createRowElement(vendor);
                    $("#vendorsTblBody").append(rowData);
                });
            },
            error: function() {
                alert('Error fetching vendor data');
            }
        });
    }

    function validateInfo() {
        $("#nameError").html('');
        var vendorName = $("#vendor_name").val().trim();
        var isValid = true;

        if (vendorName === '') {
            $("#nameError").html("Vendor Name is required.");
            isValid = false;
        }

        if (isValid) {
            $.ajax({
                url: 'vendor',
                type: 'POST',
                data: $('#vendorForm').serialize(),
                success: function (data) {
                    data = $.trim(data);
                    if (data === 'success') {
                        loadVendorList();
                        $('#addVendorModal').modal('hide');
                    } else {
                        alert('Save failed');
                    }
                },
                error: function () {
                    alert('Something went wrong. Please try again');
                }
            });
        }
    }

    function createRowElement(vendor){
        var rowData = "<tr>";
        rowData +="<td>"+ vendor.vendor_name +"</td>";
        /* 
        rowData += "<td>" + new Date(category.date_added).toLocaleString('en-US', {
            month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true
        }) + "</td>";
        rowData += "<td>" + new Date(category.date_updated).toLocaleString('en-US', {
            month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true
        }) + "</td>";
         */
        rowData += "<td>";
        rowData += "<button class='btn btn-sm btn-primary' onclick='editVendor(" + vendor.vendor_id + ")'>Edit</button> ";
        rowData += "<button type='button' class='btn btn-sm btn-danger' onclick='doDelete(" + vendor.vendor_id + ", event)'>Delete</button>";
        rowData += "</td>";
        rowData +="</tr>";
        return rowData;
    }

    function doDelete(vendor_id){
        if (confirm("Delete this vendor?")){
            $('#actionID').val('delete');
            $('#vendor_id').val(vendor_id);
            $.ajax({
                url : 'vendor',
                type : 'POST',
                data : $('#vendorForm').serialize(),
                success : function(data){
                    console.log(data);
                    if($.trim(data) === 'success'){
                        loadVendorList();
                        $('#addVendorModal').modal('hide');
                    }else{
                        console.log("Not saved...");
                    }
                },error: function(){
                    alert('Something wrong. Please try again')
                }
            });
        }
    }

    function editVendor(vendorId){
        $('#addVendorModalLabel').text('Edit Vendor');
        $.ajax({
            url : 'vendor',
            type : 'GET',
            data : { vendor_id : vendorId },
            dataType: 'json',
            success : function(vendor) {
                if(vendor && vendor.vendor_id){
                    $('#actionID').val('update');
                    $('#vendor_id').val(vendor.vendor_id);
                    $('#vendor_name').val(vendor.vendor_name);
                    $('#addbtnID').text('Update');
                    $('#addVendorModal').modal('show');
                } else {
                    alert('Error fetching vendor data');
                }
            },
            error: function() {
                alert('Error fetching vendor data');
            }
        });
    }

    $(document).on('click','[data-bs-target="#addVendorModal"]', function(){
        $('#addVendorModalLabel').text("Add New Vendor");
        $('#addbtnID').text('Add Vendor');
        $('#vendorForm')[0].reset();
        $('#vendor_id').val('');
        $('#nameError').html('');
    });
  </script>
</body>
</html>
