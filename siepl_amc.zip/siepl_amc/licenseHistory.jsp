<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>License History</title>

    <!-- Bootstrap CSS + Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
      body { background-color: #f8f9fc; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
      .card-custom { border-radius: 16px; box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12); border: none; }
      .card-custom:hover { transform: translateY(-3px); box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18); }
      .btn-primary { border-radius: 12px; background: linear-gradient(to right, #4e54c8, #8f94fb); border: none; }
      .btn-danger { border-radius: 12px; background: linear-gradient(to right, #ff416c, #ff4b2b); border: none; }
      .table-custom { border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); }
      .table thead { background-color: #4e54c8; color: white; }
      .table thead th { border: none; padding: 15px; }
      .table-striped tbody tr:nth-of-type(odd) { background-color: #fafbff; }
      .table-hover tbody tr:hover { background-color: #e9f0ff; }
      .table td { padding: 15px; border-color: #f1f4f9; }
      .modal-content { border-radius: 16px; border: none; }
      .modal-header { background: linear-gradient(to right, #4e54c8, #8f94fb); color: white; border-radius: 16px 16px 0 0; }
      .form-control { border-radius: 12px; padding: 12px 16px; border: 1px solid #e1e5ef; }
      .form-control:focus { box-shadow: 0 0 0 3px rgba(78, 84, 200, 0.2); border-color: #4e54c8; }
    </style>
</head>
<body>

<div class="app-shell">
  <jsp:include page="sidebar.jsp" />

  <!-- Main content -->
  <div class="main-content">
    <div class="container py-5">

      <!-- Page Header -->
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 class="fw-bold mb-1">License History</h2>
          <p class="text-muted">Track renewals and expiry dates of licenses</p>
        </div>

        <button type="button" class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#addHistoryModal">
          + Add License History
        </button>
      </div>

      <!-- Card -->
      <div class="card card-custom">
        <div class="card-body">
          <h5 class="mb-3 fw-semibold"> License Records </h5>

          <!-- Search Form -->
          <form class="d-flex mb-3 row gx-3 gy-2 align-items-center" role="search" id="searchForm" >
            <div class="col-auto">
              <input class="form-control" type="search" placeholder="Search Software..." aria-label="Search" name="query" id="query">
            </div>
            <div class="col-auto">
              <button type="button" class="btn btn-primary" onclick="loadLicenseHistory()">Search</button>
            </div>
          </form>

          <!-- Table -->
          <div class="table-responsive table-custom">
            <table class="table table-striped table-hover align-middle mb-0">
              <thead>
                <tr>
                  <th scope="col">History ID</th>
                  <th scope="col">Service ID</th>
                  <th scope="col">Software Name</th>
                  <th scope="col">Renewed On</th>
                  <th scope="col">New Expiry Date</th>
                  <th scope="col">Date Added</th>
                  <th scope="col">Date Updated</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody id="historyTblBody">
                <!-- Dynamic rows -->
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="addHistoryModal" tabindex="-1" aria-labelledby="addHistoryModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content text-dark">
      <div class="modal-header">
        <h5 class="modal-title" id="addHistoryModalLabel">Add License History</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form action="licenseHistory" method="post" name="historyForm" id="historyForm">
          <input type="hidden" name="history_id" id="history_id">
          <input type="hidden" name="action" id="actionID"/>

          <div class="mb-3">
            <label for="service_id" class="form-label">Service ID</label>
            <input type="number" class="form-control" id="service_id" name="service_id" required>
          </div>

          <div class="mb-3">
            <label for="software_name" class="form-label">Software Name</label>
            <input type="text" class="form-control" id="software_name" name="software_name" required>
          </div>

          <div class="mb-3">
            <label for="renewed_on_date" class="form-label">Renewed On</label>
            <input type="date" class="form-control" id="renewed_on_date" name="renewed_on_date" required>
          </div>

          <div class="mb-3">
            <label for="new_expiry_date" class="form-label">New Expiry Date</label>
            <input type="date" class="form-control" id="new_expiry_date" name="new_expiry_date" required>
          </div>

          <div class="d-grid gap-2">
            <button type="button" onclick="saveHistory()" class="btn btn-primary" id="addbtnID">Add History</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS + jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
    loadLicenseHistory();
});

function loadLicenseHistory(){
  $("#historyTblBody").html('<tr><td colspan="8" class="text-center">Loading...</td></tr>');
  $.ajax({
    url: 'licenseHistoryList',
    type: 'GET',
    data: { query: $("#query").val() },
    success: function(data){
      $("#historyTblBody").empty();
      $.map(data, function(history){
        var row = createRow(history);
        $("#historyTblBody").append(row);
      });
    },
    error: function(){ alert('Error fetching license history'); }
  });
}

function createRow(history){
  var row = "<tr>";
  row += "<td>"+ history.history_id +"</td>";
  row += "<td>"+ history.service_id +"</td>";
  row += "<td>"+ history.software_name +"</td>";
  row += "<td>"+ history.renewed_on_date +"</td>";
  row += "<td>"+ history.new_expiry_date +"</td>";
  row += "<td>"+ history.date_added +"</td>";
  row += "<td>"+ history.date_updated +"</td>";
  row += "<td>";
  row += "<button class='btn btn-sm btn-primary' onclick='editHistory("+ history.history_id +")'>Edit</button> ";
  row += "<button class='btn btn-sm btn-danger' onclick='deleteHistory("+ history.history_id +")'>Delete</button>";
  row += "</td></tr>";
  return row;
}

function saveHistory(){
  $.ajax({
    url: 'licenseHistory',
    type: 'POST',
    data: $('#historyForm').serialize(),
    success: function(data){
      if($.trim(data) === 'success'){
        loadLicenseHistory();
        $('#addHistoryModal').modal('hide');
      } else {
        alert('Save failed');
      }
    },
    error: function(){ alert('Something went wrong.'); }
  });
}

function editHistory(id){
  $.ajax({
    url: 'licenseHistory',
    type: 'GET',
    data: { history_id: id },
    dataType: 'json',
    success: function(history){
      if(history){
        $('#actionID').val('update');
        $('#history_id').val(history.history_id);
        $('#service_id').val(history.service_id);
        $('#software_name').val(history.software_name);
        $('#renewed_on_date').val(history.renewed_on_date);
        $('#new_expiry_date').val(history.new_expiry_date);

        $('#addbtnID').text('Update History');
        $('#addHistoryModal').modal('show');
      }
    }
  });
}

function deleteHistory(id){
  if(confirm("Delete this record?")){
    $('#actionID').val('delete');
    $('#history_id').val(id);
    $.ajax({
      url: 'licenseHistory',
      type: 'POST',
      data: $('#historyForm').serialize(),
      success: function(data){
        if($.trim(data) === 'success'){
          loadLicenseHistory();
        }
      }
    });
  }
}
</script>
</body>
</html>
