<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>SubCategories</title>

    <!-- Bootstrap CSS + Icons (ensure these are available once) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      background-color: #f8f9fc;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .card-custom {
      border-radius: 16px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
      transition: transform 0.2s ease, box-shadow 0.2s ease;
      border: none;
    }
    .card-custom:hover {
      transform: translateY(-3px);
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18);
    }
    .btn-primary, .btn-danger {
      border-radius: 12px;
      padding: 8px 18px;
      font-weight: 500;
    }
    .btn-primary {
      background: linear-gradient(to right, #4e54c8, #8f94fb);
      border: none;
    }
    .btn-danger {
      background: linear-gradient(to right, #ff416c, #ff4b2b);
      border: none;
    }
    .table-custom {
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }
    .table thead {
      background-color: #4e54c8;
      color: white;
    }
    .table thead th {
      border: none;
      padding: 15px;
    }
    .table-striped tbody tr:nth-of-type(odd) {
      background-color: #fafbff;
    }
    .table-hover tbody tr:hover {
      background-color: #e9f0ff;
    }
    .table td {
      padding: 15px;
      border-color: #f1f4f9;
    }
    .action-btn {
      margin-left: 4px;
    }
    .modal-content {
      border-radius: 16px;
      border: none;
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18);
    }
    .modal-header {
      background: linear-gradient(to right, #4e54c8, #8f94fb);
      color: white;
      border-radius: 16px 16px 0 0;
    }
    .modal-title {
      font-weight: 600;
    }
    .form-control {
      border-radius: 12px;
      padding: 12px 16px;
      border: 1px solid #e1e5ef;
    }
    .form-control:focus {
      box-shadow: 0 0 0 3px rgba(78, 84, 200, 0.2);
      border-color: #4e54c8;
    }
    .search-box {
      position: relative;
    }
    .search-box .form-control {
      padding-left: 45px;
    }
    .search-box .bi-search {
      position: absolute;
      left: 15px;
      top: 12px;
      color: #6c757d;
    }

    .app-shell {
      display: flex;
      gap: 0;
      align-items: flex-start;
    }
    .main-content {
      flex: 1 1 auto;
      min-width: 0;
    }
    .main-content .container {
      padding-left: 2rem;
      padding-right: 2rem;
    }

    @media (max-width: 768px) {
      .app-shell {
        flex-direction: column;
      }
      .main-content .container {
        padding-left: 1rem;
        padding-right: 1rem;
      }
    }
  </style>
</head>
<body>

  <div class="app-shell">

    <jsp:include page="sidebar.jsp" />

    <!-- Main content -->
    <div class="main-content">
      <div class="container py-5">

        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h2 class="fw-bold mb-1">Product Management</h2>
            <p class="text-muted">Organize your products </p>
          </div>

          <!-- Button to open modal -->
          <button type="button" class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#addProductModal">
            + Add New Product
          </button>
        </div>

        <!-- SubCategories Card -->
        <div class="card card-custom" >
          <div class="card-body">
            <h5 class="mb-3 fw-semibold"> Product </h5>

            <!-- Search Form -->
            <form class="d-flex mb-3 row gx-3 gy-2 align-items-center" role="search" id="searchForm" >
            <div class="col-auto"> 
              <input class="form-control me-2" type="search" placeholder="Search Product..." aria-label="Search" name="query" id="query">
              </div>
              <div class="col-auto">
        <select class="form-select" name="category_id" id="searchCategoryId">
            <option value="">-- Select Category --</option>
            
        </select>
    </div>

    <!-- Designation Dropdown -->
    <div class="col-auto">
        <select class="form-select" name="subcategory_id" id="searchSubcategoryId">
            <option value="">-- Select SubCategory --</option>
            
        </select>
    </div>
    
    <div class="col-auto">
        <select class="form-select" name="unit_id" id="searchUnitId">
            <option value="">-- Select Unit --</option>
            
        </select>
    </div>
              
              <div class="col-auto">
        <button type=button class="btn btn-primary" onclick="loadProductList()">Search</button>
    </div>
              
              
            </form>

            <!-- Table -->
            <div class="table-responsive table-custom">
              <table class="table table-striped table-hover align-middle mb-0">
                <thead>
                  <tr>
                  	<th scope="col">Product Id</th>
                  	<th scope="col">Serial no.</th>
                  	<th scope="col">Category Name</th>
                    <th scope="col">SubCategory Name</th>
                    <th scope="col">Model</th>
                    <th scope="col">Description</th>
                    <th scope="col">Unit Name</th>
                    <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody id="productTblBody">
                  <!-- Dynamic rows will be injected by JS -->
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>
    </div>

  </div>

  <!-- Modal -->
<div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="addProductModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content text-dark">
      <div class="modal-header">
        <h5 class="modal-title" id="addProductModalLabel">Add New Product</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="product" method="post" name="productForm" id="productForm">
          <input type="hidden" name="product_id" id="product_id">
          <input type="hidden" name="action" id="actionID"/>
			
		  <div class="mb-3">
            <label for="serial_id" class="form-label">Serial No.</label>
            <input type="text" min="1" step="1" class="form-control" id="serial_id" name="serial_no" required>
            <span id="serialNoError" style="color: grey"></span>
          </div>
          
          <div class="mb-3">
            <select name="category_id" id="category_id" class="form-select" required>
                <option value="">Select Category</option>
              </select>
            <span id="categoryIdError" style="color: grey"></span>
          </div>
          
          <div class="mb-3">
            <select name="subcategory_id" id="subcategory_id" class="form-select" required>
                <option value="">Select SubCategory</option>
              </select>
            <span id="subcategoryIdError" style="color: grey"></span>
          </div>
          
          <!-- Category Id -->
          <div class="mb-3">
            <label for="model_id" class="form-label">Model</label>
            <input type="text" min="1" step="1" class="form-control" id="model_id" name="model" required>
            <span id="modelError" style="color: grey"></span>
          </div>

          <!-- SubCategory Name -->
          <div class="mb-3">
            <label for="description_id" class="form-label">Description</label>
            <input type="text" class="form-control" id="description_id" name="description" required>
            <span id="descriptionError" style="color: grey"></span>
          </div>

		<div class="mb-3">
            <label for="unit_id" class="form-label">Unit Id</label>
            <select name="unit_id" id="unit_id" class="form-select" required>
                <option value="">Select Unit</option>
              </select>
            <span id="unitError" style="color: grey"></span>
          </div>
          <!-- Buttons -->
          <div class="d-grid gap-2">
            <button type="button" onclick="validateInfo()" class="btn btn-primary" id="addbtnID">Add Product</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

  <!-- Bootstrap JS + jQuery -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"
          integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

  <script type="text/javascript">
    $(document).ready(function(){
        loadProductList();
        loadCategoryList();
        $("#category_id").change(function() {
            var categoryId = $(this).val();
            if (categoryId) {
                loadSubcategoryList(categoryId);
            } else {
                $("#subcategory_id").empty().append('<option value="">Select SubCategory</option>');
            }
        });
        
        $("#searchCategoryId").change(function() {
            var categoryId = $(this).val();
            if (categoryId) {
                loadSubcategoryList(categoryId, "#searchSubcategoryId");
            } else {
                $("#searchSubcategoryId").empty().append('<option value="">Select SubCategory</option>');
            }
        });
        
        loadUnitList();
    });

    $("#searchForm").on("submit", function(event) {
        event.preventDefault();
        loadProductList();
    });

    function loadProductList() {
    	$("#productTblBody").html('<tr><td colspan="8" class="text-center">Loading...</td></tr>');
        $.ajax({
            url: 'productList',
            type: 'GET',
            data: {
                query: $("#query").val(),
                category_id: $("#searchCategoryId").val(),
                subcategory_id: $("#searchSubcategoryId").val(),
                unit_id: $("#searchUnitId").val()
            },
            success: function(data) {
                console.log("Fetched product:", data);

                $("#productTblBody").empty();
                $.map(data, function(product) {
                    var rowData = createRowElement(product);
                    $("#productTblBody").append(rowData);
                });
            },
            error: function() {
                alert('Error fetching product data');
            }
        });
    }

    function validateInfo() {
        // Clear previous error messages
        $("#serialNoError").html('');
        $("#categoryIdError").html('');
        $("#subcategoryIdError").html('');
        $("#modelError").html('');
        $("#unitError").html('');
        $("#descriptionError").html('');

        // Get field values
        var serialNo = $("#serial_id").val().trim();
        var categoryId = $("#category_id").val().trim();
        var subcategoryId = $("#subcategory_id").val().trim();
        var model = $("#model_id").val().trim();
        var unitId = $("#unit_id").val().trim();
        var description = $("#description_id").val().trim();

        var isValid = true;

        // Serial Number Validation
        if (serialNo === '') {
            $("#serialNoError").html("Serial Number is required.");
            isValid = false;
        }

        // Category ID Validation
        if (categoryId === '') {
            $("#categoryIdError").html("Category ID is required.");
            isValid = false;
        } else {
            var idNum = Number(categoryId);
            if (isNaN(idNum) || !Number.isInteger(idNum)) {
                $("#categoryError").html("Category ID must be a valid integer.");
                isValid = false;
            } else if (idNum <= 0) {
                $("#categoryError").html("Category ID must be a positive integer.");
                isValid = false;
            }
        }

        // Subcategory Validation
        if (subcategoryId === '') {
            $("#subcategoryIdError").html("Subcategory is required.");
            isValid = false;
        }

        // Model Validation
        if (model === '') {
            $("#modelError").html("Model is required.");
            isValid = false;
        }

        // Unit Validation
        if (unitId === '') {
            $("#unitError").html("Unit is required.");
            isValid = false;
        }

        // Description Validation
        if (description === '') {
            $("#descriptionError").html("Description is required.");
            isValid = false;
        }

        // Submit form if valid
        if (isValid) {
            $.ajax({
                url: 'product',
                type: 'POST',
                data: $('#productForm').serialize(),
                success: function (data) {
                    data = $.trim(data);
                    if (data === 'success') {
                        loadProductList();
                        $('#addProductModal').modal('hide');
                    } else {
                        alert('Save failed');
                    }
                },
                error: function () {
                    alert('Something went wrong. Please try again');
                }
            });
        }
    }


    function createRowElement(product){
        var rowData = "<tr>";
        rowData +="<td>"+ product.product_id +"</td>";
        rowData +="<td>"+ product.serial_no +"</td>";
        rowData +="<td>"+ product.category_name +"</td>";
        rowData +="<td>"+ product.subcategory_name +"</td>";
        rowData +="<td>"+ product.model +"</td>";
        rowData +="<td>"+ product.description +"</td>";
        rowData +="<td>"+ product.unit_name +"</td>";
        rowData += "<td>";
        rowData += "<button class='btn btn-sm btn-primary' onclick='editProduct(" + product.product_id + ")'>Edit</button> ";
        rowData += "<button type='button' class='btn btn-sm btn-danger' onclick='doDelete(" + product.product_id + ", event)'>Delete</button>";
        rowData += "</td>";
        rowData +="</tr>";
        return rowData;
    }

    function doDelete(product_id){
        if (confirm("Delete this product?")){
            $('#actionID').val('delete');
            $('#product_id').val(product_id);
            $.ajax({
                url : 'product',
                type : 'POST',
                data : $('#productForm').serialize(),
                success : function(data){
                    console.log(data);
                    if($.trim(data) === 'success'){
                    	loadProductList();
                        $('#addProductModal').modal('hide');
                    }else{
                        console.log("Not saved...");
                    }
                },error: function(){
                    alert('Something wrong. Please try again')
                }
            });
        }
    }
    
    function loadCategoryList() {
        $.ajax({
            url: 'category', 
            type: 'GET',
            data: { action: 'list' }, 
            success: function(data) {
                console.log("Fetched:", data);
               

                $.map(data, function(category) {
                    var optionData = '<option value="' + category.category_id + '">' 
                                   + category.category_name + '</option>';
                    $("#category_id").append(optionData);
                    $("#searchCategoryId").append(optionData);
                });
            },
            error: function(err) {
                console.log("Error fetching categories:", err);
            }
        });
    }


    function loadSubcategoryList(categoryId, targetDropdown) {
        $.ajax({
            url: 'subcategories',
            type: 'GET',
            data: {
                action: 'list',
                category_id: categoryId  
            },
            success: function(data) {
                $(targetDropdown).empty().append('<option value="">Select SubCategory</option>');
                $.map(data, function(subcategory) {  
                    var optionData = '<option value="' + subcategory.subcategory_id + '">' +
                                     subcategory.subcategory_name + '</option>';
                    $(targetDropdown).append(optionData);
                });
            },
            error: function(err) {
                console.log("Error fetching subcategories:", err);
            }
        });
    }


    
    function loadUnitList(){
    	$.ajax({
    		url : 'unit',
    		type : 'GET',
    		data : {action : 'list'},
    		success : function(data){
    			console.log(data);
    			
    			$.map( data, function( unit ){
    				console.log(unit.unit_id + ' ' + unit.unit_name);
    				var optionData = '<option value='+ unit.unit_id+'>'+ unit.unit_name +'</option>';
    				$("#unit_id").append(optionData);
    				$("#searchUnitId").append(optionData);
    			});
    		},
    		error: function(data) {
                console.log("Error fetching units:", data);
            }
    	});
    }
    
    function editProduct(product_id){
        $('#addProductModalLabel').text('Edit Product');
        $.ajax({
            url : 'product',
            type : 'GET',
            data : { product_id : product_id },
            dataType: 'json',
            success : function(product) {
                if(product && product.product_id){
                    $('#actionID').val('update');
                    $('#product_id').val(product.product_id);
                    $('#serial_id').val(product.serial_no);
                    $('#category_id').val(product.category_id);
                    $('#subcategory_id').val(product.subcategory_id);
                    $('#model_id').val(product.model);
                    $('#description_id').val(product.description);
                    $('#unit_id').val(product.unit_id);
                    
                    $('#addbtnID').text('Update');
                    $('#addProductModal').modal('show');
                } else {
                    alert('Error fetching product data');
                }
            },
            error: function() {
                alert('Error fetching product data');
            }
        });
    }

    $(document).on('click','[data-bs-target="#addProductModal"]', function(){
        $('#addProductModalLabel').text("Add New Product");
        $('#addbtnID').text('Add Product');
        $('#productForm')[0].reset();
        $('#product_id').val('');
        $('#nameError').html('');
        $('#serialNoError, categoryIdError, subcategoryIdError, modelError, descriptionError, unitError').html('');
    });
  </script>
</body>
</html>
