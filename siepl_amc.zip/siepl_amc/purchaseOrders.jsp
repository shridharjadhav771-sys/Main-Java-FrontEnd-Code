<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Purchase Orders</title>

    <!-- Bootstrap CSS + Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body { background-color: #f8f9fc; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; } 
        .card-custom { border-radius: 16px; box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12); transition: transform 0.2s ease, box-shadow 0.2s ease; border: none; } 
        .card-custom:hover { transform: translateY(-3px); box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18); } 
        .btn-primary, .btn-danger { border-radius: 12px; padding: 8px 18px; font-weight: 500; } 
        .btn-primary { background: linear-gradient(to right, #4e54c8, #8f94fb); border: none; } 
        .btn-danger { background: linear-gradient(to right, #ff416c, #ff4b2b); border: none; } 
        .table-custom { border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); } 
        .table thead { background-color: #4e54c8; color: white; } 
        .table thead th { border: none; padding: 15px; } 
        .table-striped tbody tr:nth-of-type(odd) { background-color: #fafbff; } 
        .table-hover tbody tr:hover { background-color: #e9f0ff; } 
        .table td { padding: 15px; border-color: #f1f4f9; } 
        .action-btn { margin-left: 4px; } 
        .modal-content { border-radius: 16px; border: none; box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18); } 
        .modal-header { background: linear-gradient(to right, #4e54c8, #8f94fb); color: white; border-radius: 16px 16px 0 0; } 
        .modal-title { font-weight: 600; } 
        .form-control { border-radius: 12px; padding: 12px 16px; border: 1px solid #e1e5ef; } 
        .form-control:focus { box-shadow: 0 0 0 3px rgba(78, 84, 200, 0.2); border-color: #4e54c8; } 
        .search-box { position: relative; } 
        .search-box .form-control { padding-left: 45px; } 
        .search-box .bi-search { position: absolute; left: 15px; top: 12px; color: #6c757d; } 
        .app-shell { display: flex; gap: 0; align-items: flex-start; } 
        .main-content { flex: 1 1 auto; min-width: 0; } 
        .main-content .container { padding-left: 2rem; padding-right: 2rem; } 
        @media (max-width: 768px) { .app-shell { flex-direction: column; } .main-content .container { padding-left: 1rem; padding-right: 1rem; }
        .table-responsive {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch; /* smooth scrolling on mobile */
} }
    </style>
</head>
<body>

<div class="app-shell">

    <jsp:include page="sidebar.jsp" />

    <!-- Main content -->
    <div class="main-content">
      <div class="container py-5">

        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h2 class="fw-bold mb-1">Purchase Order Management</h2>
            <p class="text-muted">Organize your Purchase Orders</p>
          </div>

          <!-- Button to open modal -->
          <button type="button" class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#addPOModal">
            + Add New Purchase Order
          </button>
        </div>

        <!-- Purchase Orders Card -->
        <div class="card card-custom">
          <div class="card-body">
            <h5 class="mb-3 fw-semibold">Purchase Orders</h5>

            <!-- Search Form -->
            <form class="d-flex mb-3 row gx-3 gy-2 align-items-center" role="search" id="searchPOForm">
                <div class="col-auto">
                    <input class="form-control me-2" type="search"
                           placeholder="Search Product / Vendor..."
                           aria-label="Search" name="query" id="query">
                </div>

                <div class="col-auto">
                    <select class="form-select" name="status" id="status">
                        <option value="">-- Select Status --</option>
                        <option value="Completed">Completed</option>
                        <option value="Open">Open</option>
                        <option value="Pending">Pending</option>
                    </select>
                </div>

                <div class="col-auto">
                    <button type="button" class="btn btn-primary" onclick="loadPOList()">Search</button>
                </div>
            </form>

            <!-- Table -->
            <div class="table-responsive table-custom">
              <table class="table table-striped table-hover align-middle mb-0">
                <thead>
                  <tr>
                      <th scope="col">Vendor Name</th>
                      <th scope="col">Product Name</th>
                      <th scope="col">Bill Amount</th>
                      <th scope="col">Date In</th>
                      <th scope="col">Date Out</th>
                      <th scope="col">Warranty Start Date</th>
                      <th scope="col">Warranty End Date</th>
                      <th scope="col">Status</th>
                      <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody id="POTblBody">
                  <!-- Dynamic rows -->
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>
    </div>

</div>

<!-- Modal -->
<div class="modal fade" id="addPOModal" tabindex="-1" aria-labelledby="addPOModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content text-dark">
      <div class="modal-header">
        <h5 class="modal-title" id="addPOModalLabel">Add New Purchase Order</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="purchaseOrder" method="post" name="POForm" id="POForm">
            <input type="hidden" name="purchase_order_id" id="purchase_order_id">
            <input type="hidden" name="action" id="actionID"/>

            <div class="mb-3">
                <label for="vendor_id" class="form-label">Vendor</label>
                <select name="vendor_id" id="vendor_id" class="form-select" required>
                    <option value="">Select Vendor</option>
                </select>
                <span id="vendorError" style="color: grey"></span>
            </div>

            <div class="mb-3">
                <label for="product_id" class="form-label">Product</label>
                <select name="product_id" id="product_id" class="form-select" required>
                    <option value="">Select Product</option>
                </select>
                <span id="productError" style="color: grey"></span>
            </div>

            <div class="mb-3">
                <label for="bill_amount" class="form-label">Bill Amount</label>
                <input type="text" class="form-control" id="bill_amount" name="bill_amount" required>
                <span id="billError" style="color: grey"></span>
            </div>

            <div class="mb-3">
                <label for="date_in" class="form-label">Date In</label>
                <input type="date" class="form-control" id="date_in" name="date_in" required>
                <span id="dateInError" style="color: grey"></span>
            </div>

            <div class="mb-3">
                <label for="date_out" class="form-label">Date Out</label>
                <input type="date" class="form-control" id="date_out" name="date_out" required>
                <span id="dateOutError" style="color: grey"></span>
            </div>

            <div class="mb-3">
                <label for="warranty_start_date" class="form-label">Warranty Start Date</label>
                <input type="date" class="form-control" id="warranty_start_date" name="warranty_start_date" required>
                <span id="wsdError" style="color: grey"></span>
            </div>

            <div class="mb-3">
                <label for="warranty_end_date" class="form-label">Warranty End Date</label>
                <input type="date" class="form-control" id="warranty_end_date" name="warranty_end_date" required>
                <span id="wedError" style="color: grey"></span>
            </div>

            <div class="mb-3">
                <label for="status_modal" class="form-label">Status</label>
                <select name="status" id="status_modal" class="form-select" required>
                     <option value="">-- Select Status --</option>
                        <option value="Completed">Completed</option>
                        <option value="Open">Open</option>
                        <option value="Pending">Pending</option>
                </select>
                <span id="statusError" style="color: grey"></span>
            </div>

            <div class="d-grid gap-2">
                <button type="button" onclick="validatePOInfo()" class="btn btn-primary" id="addbtnID">Add Purchase Order</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS + jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
    loadProductList();
    loadVendorList();
    loadPOList();
});
w
function loadPOList() {
    $("#POTblBody").html('<tr><td colspan="9" class="text-center">Loading...</td></tr>');
    $.ajax({
        url: 'purchaseOrderList',
        type: 'GET',
        data: {
            query: $("#query").val(),
            status: $("#status").val()
        },
        success: function(data) {
            $("#POTblBody").empty();
            $.map(data, function(po) {
                $("#POTblBody").append(createRowElement(po));
            });
        },
        error: function() {
            alert('Error fetching purchase order data');
        }
    });
}

function validatePOInfo() {
    $("#vendorError,#productError,#billError,#dateInError,#dateOutError,#wsdError,#wedError,#statusError").html('');

    var vendorId = $("#vendor_id").val().trim(),
        productId = $("#product_id").val().trim(),
        billAmount = $("#bill_amount").val().trim(),
        dateIn = $("#date_in").val().trim(),
        dateOut = $("#date_out").val().trim(),
        warrantyStartDate = $("#warranty_start_date").val().trim(),
        warrantyEndDate = $("#warranty_end_date").val().trim(),
        status = $("#status_modal").val().trim(),
        isValid = true;

    if(vendorId === '') { $("#vendorError").html("Vendor is required."); isValid=false; }
    if(productId === '') { $("#productError").html("Product is required."); isValid=false; }
    if(billAmount === '') { $("#billError").html("Bill Amount is required."); isValid=false; }
    if(dateIn === '') { $("#dateInError").html("Date In is required."); isValid=false; }
    if(dateOut === '') { $("#dateOutError").html("Date Out is required."); isValid=false; }
    if(warrantyStartDate === '') { $("#wsdError").html("Warranty Start Date is required."); isValid=false; }
    if(warrantyEndDate === '') { $("#wedError").html("Warranty End Date is required."); isValid=false; }
    if(status === '') { $("#statusError").html("Status is required."); isValid=false; }

    if(isValid){
        $.ajax({
            url: 'purchaseOrder',
            type: 'POST',
            data: $('#POForm').serialize(),
            success: function(data){
                data = $.trim(data);
                if(data === 'success'){
                    loadPOList();
                    $('#addPOModal').modal('hide');
                } else { alert('Save failed'); }
            },
            error: function(){ alert('Something went wrong. Please try again'); }
        });
    }
}

function createRowElement(po){
    var row = "<tr>";
    row += "<td>" + po.vendor_name + "</td>";
    row += "<td>" + po.product_name + "</td>";
    row += "<td>" + po.bill_amount + "</td>";
    row += "<td>" + po.date_in + "</td>";
    row += "<td>" + po.date_out + "</td>";
    row += "<td>" + po.warranty_start_date + "</td>";
    row += "<td>" + po.warranty_end_date + "</td>";
    row += "<td>" + po.status + "</td>";
    row += "<td>";
    row += "<button class='btn btn-sm btn-primary' onclick='editPO(" + po.purchase_order_id + ")'>Edit</button> ";
    row += "<button class='btn btn-sm btn-danger' onclick='doDelete(" + po.purchase_order_id + ")'>Delete</button>";
    row += "</td></tr>";
    return row;
}

function loadVendorList(){
    $.ajax({
        url: 'vendorList',
        type: 'GET',
        success: function(data){
            var $vendor = $("#vendor_id");
            $vendor.empty();
            $vendor.append('<option value="">Select Vendor</option>');
            $.map(data, function(v){ $vendor.append('<option value="'+v.vendor_id+'">'+v.vendor_name+'</option>'); });
        },
        error: function(){ alert('Error fetching vendor data'); }
    });
}

function loadProductList(){
    $.ajax({
        url: 'productList',
        type: 'GET',
        success: function(data){
            var $product = $("#product_id");
            $product.empty();
            $product.append('<option value="">Select Product</option>');
            $.map(data, function(p){ $product.append('<option value="'+p.product_id+'">'+p.model+'</option>'); });
        },
        error: function(){ alert('Error fetching product data'); }
    });
}

function doDelete(purchase_order_id){
    if(confirm("Delete this Purchase Order?")){
        $('#actionID').val('delete');
        $('#purchase_order_id').val(purchase_order_id);
        $.ajax({
            url:'purchaseOrder',
            type:'POST',
            data: $('#POForm').serialize(),
            success: function(data){
                if($.trim(data)==='success'){ loadPOList(); $('#addPOModal').modal('hide'); }
                else { console.log("Not deleted"); }
            },
            error: function(){ alert('Something went wrong.'); }
        });
    }
}

function editPO(purchase_order_id){
    $('#addPOModalLabel').text('Edit Purchase Order');
    $.ajax({
        url: 'purchaseOrder',
        type: 'GET',
        data: {purchase_order_id: purchase_order_id},
        dataType: 'json',
        success: function(po){
            if(po && po.purchase_order_id){
                $('#actionID').val('update');
                $('#purchase_order_id').val(po.purchase_order_id);
                $('#vendor_id').val(po.vendor_id);
                $('#product_id').val(po.product_id);
                $('#bill_amount').val(po.bill_amount);
                $('#date_in').val(po.date_in);
                $('#date_out').val(po.date_out);
                $('#warranty_start_date').val(po.warranty_start_date);
                $('#warranty_end_date').val(po.warranty_end_date);
                $('#status_modal').val(po.status);

                $('#addbtnID').text('Update');
                $('#addPOModal').modal('show');
            } else { alert('Error fetching purchase order data'); }
        },
        error: function(){ alert('Error fetching purchase order data'); }
    });
}

// Reset modal
$(document).on('click', '[data-bs-target="#addPOModal"]', function(){
    $('#addPOModalLabel').text("Add New Purchase Order");
    $('#addbtnID').text('Add Purchase Order');
    $('#POForm')[0].reset();
    $('#purchase_order_id').val('');
    $('#vendorError,#productError,#billError,#dateInError,#dateOutError,#wsdError,#wedError,#statusError').html('');
});
</script>
</body>
</html>
