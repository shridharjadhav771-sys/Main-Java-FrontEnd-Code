<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>SubCategories</title>

    <!-- Bootstrap CSS + Icons (ensure these are available once) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      background-color: #f8f9fc;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .card-custom {
      border-radius: 16px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
      transition: transform 0.2s ease, box-shadow 0.2s ease;
      border: none;
    }
    .card-custom:hover {
      transform: translateY(-3px);
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18);
    }
    .btn-primary, .btn-danger {
      border-radius: 12px;
      padding: 8px 18px;
      font-weight: 500;
    }
    .btn-primary {
      background: linear-gradient(to right, #4e54c8, #8f94fb);
      border: none;
    }
    .btn-danger {
      background: linear-gradient(to right, #ff416c, #ff4b2b);
      border: none;
    }
    .table-custom {
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }
    .table thead {
      background-color: #4e54c8;
      color: white;
    }
    .table thead th {
      border: none;
      padding: 15px;
    }
    .table-striped tbody tr:nth-of-type(odd) {
      background-color: #fafbff;
    }
    .table-hover tbody tr:hover {
      background-color: #e9f0ff;
    }
    .table td {
      padding: 15px;
      border-color: #f1f4f9;
    }
    .action-btn {
      margin-left: 4px;
    }
    .modal-content {
      border-radius: 16px;
      border: none;
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18);
    }
    .modal-header {
      background: linear-gradient(to right, #4e54c8, #8f94fb);
      color: white;
      border-radius: 16px 16px 0 0;
    }
    .modal-title {
      font-weight: 600;
    }
    .form-control {
      border-radius: 12px;
      padding: 12px 16px;
      border: 1px solid #e1e5ef;
    }
    .form-control:focus {
      box-shadow: 0 0 0 3px rgba(78, 84, 200, 0.2);
      border-color: #4e54c8;
    }
    .search-box {
      position: relative;
    }
    .search-box .form-control {
      padding-left: 45px;
    }
    .search-box .bi-search {
      position: absolute;
      left: 15px;
      top: 12px;
      color: #6c757d;
    }

    .app-shell {
      display: flex;
      gap: 0;
      align-items: flex-start;
    }
    .main-content {
      flex: 1 1 auto;
      min-width: 0;
    }
    .main-content .container {
      padding-left: 2rem;
      padding-right: 2rem;
    }

    @media (max-width: 768px) {
      .app-shell {
        flex-direction: column;
      }
      .main-content .container {
        padding-left: 1rem;
        padding-right: 1rem;
      }
    }
  </style>
</head>
<body>

  <div class="app-shell">

    <jsp:include page="sidebar.jsp" />

    <!-- Main content -->
    <div class="main-content">
      <div class="container py-5">

        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h2 class="fw-bold mb-1">SubCategory Management</h2>
            <p class="text-muted">Organize your products into sub categories</p>
          </div>

          <!-- Button to open modal -->
          <button type="button" class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#addSubCategoryModal">
            + Add New SubCategory
          </button>
        </div>

        <!-- SubCategories Card -->
        <div class="card card-custom" >
          <div class="card-body">
            <h5 class="mb-3 fw-semibold"> SubCategory </h5>

            <!-- Search Form -->
            <form class="d-flex mb-3" role="search" id="searchForm">
              <input class="form-control me-2" type="search" placeholder="Search SubCategory..." aria-label="Search" name="query" id="query">
              <button class="btn btn-outline-primary" type="submit" >Search</button>
            </form>

            <!-- Table -->
            <div class="table-responsive table-custom">
              <table class="table table-striped table-hover align-middle mb-0">
                <thead>
                  <tr>
                  	<th scope="col">Category Id</th>
                    <th scope="col">SubCategory Name</th>
                    <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody id="subcategoryTblBody">
                  <!-- Dynamic rows will be injected by JS -->
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>
    </div>

  </div>

  <!-- Modal -->
<div class="modal fade" id="addSubCategoryModal" tabindex="-1" aria-labelledby="addSubCategoryModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content text-dark">
      <div class="modal-header">
        <h5 class="modal-title" id="addSubCategoryModalLabel">Add New SubCategory</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="subcategories" method="post" name="subcategoryForm" id="subcategoryForm">
          <input type="hidden" name="subcategory_id" id="subcategory_id">
          <input type="hidden" name="action" id="actionID"/>

          <!-- Category Id -->
          <div class="mb-3">
            <label for="category_id" class="form-label">Category Id</label>
            <input type="number" min="1" step="1" class="form-control" id="category_id" name="category_id" required>
            <span id="idError" style="color: grey"></span>
          </div>

          <!-- SubCategory Name -->
          <div class="mb-3">
            <label for="subcategory_name" class="form-label">Sub Category Name</label>
            <input type="text" class="form-control" id="subcategory_name" name="subcategory_name" required>
            <span id="nameError" style="color: grey"></span>
          </div>

          <!-- Buttons -->
          <div class="d-grid gap-2">
            <button type="button" onclick="validateInfo()" class="btn btn-primary" id="addbtnID">Add SubCategory</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

  <!-- Bootstrap JS + jQuery -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"
          integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

  <script type="text/javascript">
    $(document).ready(function(){
        loadSubcategoryList();
    });

    $("#searchForm").on("submit", function(event) {
        event.preventDefault();
        loadSubcategoryList();
    });

    function loadSubcategoryList() {
        $.ajax({
            url: 'subcategoryList',
            type: 'GET',
            data: {
                query: $("#query").val()
            },
            success: function(data) {
                console.log("Fetched Sub-Categories:", data);

                $("#subcategoryTblBody").empty();
                $.map(data, function(subcategory) {
                    var rowData = createRowElement(subcategory);
                    $("#subcategoryTblBody").append(rowData);
                });
            },
            error: function() {
                alert('Error fetching subcategory data');
            }
        });
    }

    function validateInfo() {
        $("#idError").html('');
        $("#nameError").html('');
        var parentCategoryId = $("#category_id").val().trim();
        var subcategoryName = $("#subcategory_name").val().trim();
        var isValid = true;

        if (parentCategoryId === '') {
            $("#idError").html("Category ID is required.");
            isValid = false;
        } else {
            var idNum = Number(parentCategoryId);
            if (isNaN(idNum) || !Number.isInteger(idNum)) {
                $("#idError").html("Category ID must be a valid integer.");
                isValid = false;
            } else if (idNum <= 0) {
                $("#idError").html("Category ID must be a positive integer.");
                isValid = false;
            }
        }

        if (subcategoryName === '') {
            $("#nameError").html("Subcategory Name is required.");
            isValid = false;
        }

        if (isValid) {
            $.ajax({
                url: 'subcategories',
                type: 'POST',
                data: $('#subcategoryForm').serialize(),
                success: function (data) {
                    data = $.trim(data);
                    if (data === 'success') {
                    	loadSubcategoryList();
                    	$('#addSubCategoryModal').modal('hide');
                    } else {
                        alert('Save failed');
                    }
                },
                error: function () {
                    alert('Something went wrong. Please try again');
                }
            });
        }
    }

    function createRowElement(subcategory){
        var rowData = "<tr>";
        rowData +="<td>"+ subcategory.category_id +"</td>";
        rowData +="<td>"+ subcategory.subcategory_name +"</td>";
        rowData += "<td>";
        rowData += "<button class='btn btn-sm btn-primary' onclick='editSubcategory(" + subcategory.subcategory_id + ")'>Edit</button> ";
        rowData += "<button type='button' class='btn btn-sm btn-danger' onclick='doDelete(" + subcategory.subcategory_id + ", event)'>Delete</button>";
        rowData += "</td>";
        rowData +="</tr>";
        return rowData;
    }

    function doDelete(subcategory_id){
        if (confirm("Delete this subcategory?")){
            $('#actionID').val('delete');
            $('#subcategory_id').val(subcategory_id);
            $.ajax({
                url : 'subcategories',
                type : 'POST',
                data : $('#subcategoryForm').serialize(),
                success : function(data){
                    console.log(data);
                    if($.trim(data) === 'success'){
                    	loadSubcategoryList();
                        $('#addSubCategoryModal').modal('hide');
                    }else{
                        console.log("Not saved...");
                    }
                },error: function(){
                    alert('Something wrong. Please try again')
                }
            });
        }
    }

    function editSubcategory(subcategoryId){
        $('#addSubCategoryModalLabel').text('Edit SubCategory');
        $.ajax({
            url : 'subcategories',
            type : 'GET',
            data : { subcategory_id : subcategoryId },
            dataType: 'json',
            success : function(subcategory) {
                if(subcategory && subcategory.category_id){
                    $('#actionID').val('update');
                    $('#subcategory_id').val(subcategory.subcategory_id);
                    $('#category_id').val(subcategory.category_id);
                    $('#subcategory_name').val(subcategory.subcategory_name);
                    $('#addbtnID').text('Update');
                    $('#addSubCategoryModal').modal('show');
                } else {
                    alert('Error fetching subcategory data');
                }
            },
            error: function() {
                alert('Error fetching subcategory data');
            }
        });
    }

    $(document).on('click','[data-bs-target="#addSubCategoryModal"]', function(){
        $('#addSubCategoryModalLabel').text("Add New SubCategory");
        $('#addbtnID').text('Add SubCategory');
        $('#subcategoryForm')[0].reset();
        $('#subcategory_id').val('');
        $('#nameError').html('');
        $('#idError').html('');
    });
  </script>
</body>
</html>
s