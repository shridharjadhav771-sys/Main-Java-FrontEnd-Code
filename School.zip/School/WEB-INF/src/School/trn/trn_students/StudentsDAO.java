package School.trn.trn_students;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import School.Utility.DBConfig;

public class StudentsDAO {


	public boolean insertStudent(StudentsDTO dto) {
		// TODO Auto-generated method stub
		String query = "insert into mini_trn_students (name, class_id, course_id, dob, gender, contact) values (?, ?, ?, ?, ?, ?)";
		try (Connection con = DBConfig.getConnection();
	             PreparedStatement ps = con.prepareStatement(query)){
			ps.setString(1, dto.getStudent_name());
			ps.setInt(2, dto.getClass_id());
			ps.setInt(3, dto.getCourse_id());
			ps.setDate(4, dto.getDob());
			ps.setString(5, dto.getGender());
			ps.setString(6, dto.getContact());
			int rows = ps.executeUpdate();
			return rows > 0;
		}catch (Exception e) {
			// TODO: handle exception
			 System.out.println("insertStudent() error: " + e.getMessage());
		}
		return false;
	}

	
	public StudentsDTO getStudentById(int student_id) {
		// TODO Auto-generated method stub
		StudentsDTO dto = null;
		String query = "SELECT * FROM mini_trn_students WHERE student_id = ? AND is_deleted = 0";
		try (Connection con = DBConfig.getConnection();
         PreparedStatement ps = con.prepareStatement(query)){
	 		ps.setInt(1, student_id);
        	 ResultSet rs = ps.executeQuery();
        	 while(rs.next()) {
				dto = new StudentsDTO();
				dto.setStudent_id(rs.getInt("student_id"));
				dto.setStudent_name(rs.getString("name"));
            	dto.setDob(rs.getDate("dob"));
            	dto.setGender(rs.getString("gender"));
            	dto.setContact(rs.getString("contact"));
            	dto.setClass_id(rs.getInt("class_id"));
            	dto.setCourse_id(rs.getInt("course_id"));           
        	 }
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("getStudentById() error: " + e.getMessage());
		}
		return dto;
	}

	public boolean updateStudent(StudentsDTO dto) {
		// TODO Auto-generated method stub
		if (dto == null || dto.getStudent_id() <= 0 || dto.getStudent_name() == null || dto.getStudent_name().trim().isEmpty()) {
	        System.out.println("updateStudent() error: Invalid DTO or missing required fields");
	        return false;
	    }
		
		String query = "update mini_trn_students set name=?, class_id=?, course_id=?, dob=?, gender=?, contact=? where student_id=?";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setString(1, dto.getStudent_name());
			ps.setInt(2, dto.getClass_id());
			ps.setInt(3, dto.getCourse_id());
			ps.setDate(4, dto.getDob());
			ps.setString(5, dto.getGender());
			ps.setString(6, dto.getContact());
			ps.setInt(7, dto.getStudent_id());
			int rows = ps.executeUpdate();
			return rows > 0;
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("updateStudent() error: " + e.getMessage());
		}
		return false;
	}

	public boolean deleteStudent(int student_id) {
		// TODO Auto-generated method stub
		String query = "update mini_trn_students set is_deleted = 1 where student_id = ?";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setInt(1, student_id);
			int rows = ps.executeUpdate();
			return rows > 0;
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("deleteStudent() error: " + e.getMessage());
		}
		return false;
	}

	public List<StudentsDTO> getDeletedStudents() {
		// TODO Auto-generated method stub
		List<StudentsDTO> list = new ArrayList<>();
		String query = "SELECT s.student_id, s.name as student_name, s.dob, s.gender, s.contact, " +
                "c.class_id, c.class_name, co.course_id, co.course_name " +
                "FROM mini_trn_students s " +
                "JOIN mini_mst_classes c ON c.class_id = s.class_id " +
                "JOIN mini_mst_courses co ON co.course_id = s.course_id " +
                "WHERE s.is_deleted = 1";
		try (Connection con = DBConfig.getConnection();
	             PreparedStatement ps = con.prepareStatement(query)){
	            	 ResultSet rs = ps.executeQuery();
				while(rs.next()) {
					StudentsDTO dto = new StudentsDTO();
					dto.setStudent_id(rs.getInt("student_id"));
					dto.setStudent_name(rs.getString("student_name"));
	                dto.setDob(rs.getDate("dob"));
	                dto.setGender(rs.getString("gender"));
	                dto.setContact(rs.getString("contact"));
	                dto.setClass_id(rs.getInt("class_id"));
	                dto.setClass_name(rs.getString("class_name"));
	                dto.setCourse_id(rs.getInt("course_id"));
	                dto.setCourse_name(rs.getString("course_name"));
	               
	                list.add(dto);
				}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}

	public boolean restoreStudent(int student_id) {
		// TODO Auto-generated method stub
		String query = "update mini_trn_students set is_deleted = 0 where student_id = ?";
		try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(query)){
			ps.setInt(1, student_id);
			int rows = ps.executeUpdate();
			return rows > 0;
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("restoreStudent() error: " + e.getMessage());
		}
		return false;
	}

	/*
	public List<StudentsDTO> getSearcherdStudents(String query, String searchBy, String matchType) {
	    List<StudentsDTO> list = new ArrayList<>();
	    String sql = "";

	    boolean isSearch = (!query.trim().isEmpty() && !searchBy.trim().isEmpty() && !matchType.trim().isEmpty());

	    if (isSearch) {
	        String operator = matchType.equals("exact") ? "=" : "LIKE";

	        sql = "SELECT student_id, s.name AS student_name, s.dob, s.gender, s.contact, " +
	              "c.class_id, c.class_name, co.course_id, co.course_name " +
	              "FROM mini_trn_students s " +
	              "JOIN mini_mst_courses co ON co.course_id = s.course_id " +
	              "JOIN mini_mst_classes c ON c.class_id = s.class_id " +
	              "WHERE s.is_deleted = 0 AND c.is_deleted = 0 AND co.is_deleted = 0 AND " +
	              searchBy + " " + operator + " ?";

	        if (operator.equals("LIKE")) {
	            query = "%" + query + "%";
	        }
	    } else {
	        sql = "SELECT student_id, s.name AS student_name, s.dob, s.gender, s.contact, " +
	              "c.class_id, c.class_name, co.course_id, co.course_name " +
	              "FROM mini_trn_students s " +
	              "JOIN mini_mst_courses co ON co.course_id = s.course_id " +
	              "JOIN mini_mst_classes c ON c.class_id = s.class_id " +
	              "WHERE s.is_deleted = 0 AND c.is_deleted = 0 AND co.is_deleted = 0";
	    }

	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {

	        if (isSearch) {
	            ps.setString(1, query);
	        }

	        ResultSet rs = ps.executeQuery();
	        while (rs.next()) {
	            StudentsDTO dto = new StudentsDTO();
	            dto.setStudent_id(rs.getInt("student_id"));
	            dto.setStudent_name(rs.getString("student_name"));
	            dto.setDob(rs.getDate("dob"));
	            dto.setGender(rs.getString("gender"));
	            dto.setContact(rs.getString("contact"));
	            dto.setClass_id(rs.getInt("class_id"));
	            dto.setClass_name(rs.getString("class_name"));
	            dto.setCourse_id(rs.getInt("course_id"));
	            dto.setCourse_name(rs.getString("course_name"));

	            list.add(dto);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return list;
	}
	
	private String mapColumn(String searchBy) {
	    switch (searchBy) {
	        case "name":
	            return "s.name";
	        case "dob":
	            return "s.dob";
	        case "gender":
	            return "s.gender";
	        case "contact":
	            return "s.contact";
	        case "course":
	            return "co.course_name";
	        case "class":
	            return "c.class_name";
	        default:
	            return null;
	    }
	}
*/

	public List<StudentsDTO> getSearchedStudents(String query, Integer classId, Integer courseId, int currentPage,int rowsPerPage, String sortColumn) {
		List<StudentsDTO> list = new ArrayList<>();
		try {
			
			String subQuery = "";
			if(!"".equals(query)) {
				subQuery = " and (s.name like '%"+ query +"%' or s.contact like '%"+ query+"%')";
			}
			
			if(classId !=null) {
				subQuery += " and c.class_id = " + classId;
			}
			
			if(courseId !=null) {
				subQuery += " and co.course_id = " + courseId;
			}
			
			int offset = (currentPage -1) *  rowsPerPage;
			
			String sql = "SELECT student_id, s.name AS student_name, s.dob, s.gender, s.contact, " +
		             "c.class_id, c.class_name, co.course_id, co.course_name " +
		             "FROM mini_trn_students s " +
		             "JOIN mini_mst_courses co ON co.course_id = s.course_id " +
		             "JOIN mini_mst_classes c ON c.class_id = s.class_id " +
		             "WHERE 1=1 " + subQuery + 
		             " AND s.is_deleted = 0 AND c.is_deleted = 0 AND co.is_deleted = 0 " +
		             "ORDER BY " + sortColumn + " ASC " +
		             "LIMIT " + offset + ", " + rowsPerPage;

			
			System.out.println("SQL: " + sql);
			 try (Connection con = DBConfig.getConnection();
			         PreparedStatement ps = con.prepareStatement(sql)) {
 
			        ResultSet rs = ps.executeQuery();
			        while (rs.next()) {
			            StudentsDTO dto = new StudentsDTO();
			            dto.setStudent_id(rs.getInt("student_id"));
			            dto.setStudent_name(rs.getString("student_name"));
			            dto.setDob(rs.getDate("dob"));
			            dto.setGender(rs.getString("gender"));
			            dto.setContact(rs.getString("contact"));
			            dto.setClass_id(rs.getInt("class_id"));
			            dto.setClass_name(rs.getString("class_name"));
			            dto.setCourse_id(rs.getInt("course_id"));
			            dto.setCourse_name(rs.getString("course_name"));

			            list.add(dto);
			        }
			    } catch (Exception e) {
			        e.printStackTrace();
			    }
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}


	public int getSearchedStudentsCount(String query, Integer classId, Integer courseId) {
	    int count = 0;
	    String subQuery = "";
	    if (!"".equals(query)) {
	        subQuery = " and (s.name like '%" + query + "%' or s.contact like '%" + query + "%')";
	    }
	    if (classId != null) {
	        subQuery += " and c.class_id = " + classId;
	    }
	    if (courseId != null) {
	        subQuery += " and co.course_id = " + courseId;
	    }

	    String sql = "SELECT COUNT(*) as total FROM mini_trn_students s " +
	                 "JOIN mini_mst_courses co ON co.course_id = s.course_id " +
	                 "JOIN mini_mst_classes c ON c.class_id = s.class_id " +
	                 "WHERE 1=1 " + subQuery + 
	                 " and s.is_deleted = 0 AND c.is_deleted = 0 AND co.is_deleted = 0";

	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {
	        if (rs.next()) {
	            count = rs.getInt("total");
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return count;
	}
	
	public boolean checkContact(String contact) {
		String sql = "select contact from mini_trn_students where contact = '" + contact + "' ";
		 try (Connection con = DBConfig.getConnection();
		         PreparedStatement ps = con.prepareStatement(sql);
		         ResultSet rs = ps.executeQuery()) {
		        if (rs.next()) {
		        	return true;
		        }
		 }catch (Exception e) {
			// TODO: handle exception
			 e.printStackTrace();
		}
		return false;
	}

}


	


