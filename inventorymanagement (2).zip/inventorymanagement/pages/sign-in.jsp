<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport"
	content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="apple-touch-icon" sizes="76x76"
	href="../assets/img/apple-icon.png">
<link rel="icon" type="image/png" href="../assets/img/favicon.png">
<title>Inventory Management System | Login</title>
<!--     Fonts and icons     -->
<link rel="stylesheet" type="text/css"
	href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700,900" />
<!-- Nucleo Icons -->
<link href="../assets/css/nucleo-icons.css" rel="stylesheet" />
<link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
<!-- Font Awesome Icons -->
<script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
<!-- Material Icons -->
<link rel="stylesheet"
	href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" />
<!-- CSS Files -->
<link id="pagestyle" href="../assets/css/material-dashboard.css?v=3.2.0"
	rel="stylesheet" />
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
	
</head>

<body class="bg-gray-200">
	<div class="container position-sticky z-index-sticky top-0">
		<div class="row">
			<div class="col-12">
				<!-- Navbar -->
				<nav
					class="navbar navbar-expand-lg blur border-radius-xl top-0 z-index-3 shadow position-absolute my-3 py-2 start-0 end-0 mx-4">
					<div class="container-fluid ps-2 pe-0">
						<a class="navbar-brand font-weight-bolder ms-lg-0 ms-3 "
							href="../pages/dashboard.html"> Inventory Management System </a>
					</div>
				</nav>
				<!-- End Navbar -->
			</div>
		</div>
	</div>
	<main class="main-content  mt-0">
		<div class="page-header align-items-start min-vh-100"
			style="background-image: url('https://images.unsplash.com/photo-1497294815431-9365093b7331?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1950&q=80');">
			<span class="mask bg-gradient-dark opacity-6"></span>
			<div class="container my-auto">
				<div class="row">
					<div class="col-lg-4 col-md-8 col-12 mx-auto">
						<div class="card z-index-0 fadeIn3 fadeInBottom">
							<div
								class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
								<div
									class="bg-gradient-dark shadow-dark border-radius-lg py-3 pe-1">
									<h4 class="text-white font-weight-bolder text-center mt-2 mb-0">Sign
										in</h4>

								</div>
							</div>
							<div class="card-body">

								<%-- <form action="<%=request.getContextPath()%>/login"
									method="post" role="form" class="text-start" > --%>
								<form id="loginForm"
									action="<%=request.getContextPath()%>/login" method="post"
									role="form" class="text-start">

									<div class="input-group input-group-outline my-3">
										<label class="form-label">Username</label> <input type="text"
											class="form-control" required="required" name="username"
											id="usernameId">
									</div>
									<div class="input-group input-group-outline mb-3">
										<label class="form-label">Password</label> <input
											type="password" class="form-control" required="required"
											name="password" id="passwordId">
									</div>
									<div
										class="form-check form-switch d-flex align-items-center mb-3">
										<input class="form-check-input" type="checkbox"
											id="rememberMe" checked> <label
											class="form-check-label mb-0 ms-3" for="rememberMe">Remember
											me</label>
									</div>
									<div class="text-center">
										<button type="submit"
											class="btn bg-gradient-dark w-100 my-4 mb-2">Sign in</button>
									</div>

								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<footer class="footer position-absolute bottom-2 py-2 w-100">
				<div class="container">
					<div class="row align-items-center justify-content-lg-between">
						<div class="col-12 col-md-6 my-auto">
							<div
								class="copyright text-center text-sm text-white text-lg-start">
								�
								<script>
									document.write(new Date().getFullYear())
								</script>
								, made with <i class="fa fa-heart" aria-hidden="true"></i> by <a
									href="https://www.creative-tim.com"
									class="font-weight-bold text-white" target="_blank">Globe
									Creater</a> for a better web.
							</div>
						</div>

					</div>
				</div>
			</footer>
		</div>
	</main>
	<!--   Core JS Files   -->
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>
	<script src="../assets/js/plugins/perfect-scrollbar.min.js"></script>
	<script src="../assets/js/plugins/smooth-scrollbar.min.js"></script>

	<!-- <script>
		// Check if cookies for username and password are set
		window.onload = function() {
			if (document.cookie) {
				const cookies = document.cookie.split("; ");
				cookies.forEach(cookie => {
					let [name, value] = cookie.split("=");
					if (name === "username") {
						document.getElementById("usernameId").value = value;
					}
					if (name === "password") {
						document.getElementById("passwordId").value = value;
					}
				});
			}
		};

		// Function to set cookies
		function setCookie(name, value, days) {
			const date = new Date();
			date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
			const expires = "expires=" + date.toUTCString();
			document.cookie = name + "=" + value + ";" + expires + ";path=/";
		}

		// Listen to form submission
		document.getElementById('loginForm').onsubmit = function(event) {
			if (document.getElementById('rememberMe').checked) {
				const username = document.getElementById('usernameId').value;
				const password = document.getElementById('passwordId').value;
				setCookie('username', username, 7); // Save username for 7 days
				setCookie('password', password, 7); // Save password for 7 days
			}
		};
	</script> -->
	
	<script>
$(document).ready(function() {
    // On page load, fill inputs if cookies exist
    if ($.cookie('username')) {
        $("#usernameId").val($.cookie('username'));
        $("#rememberMe").prop('checked', true);
    }
    if ($.cookie('password')) {
        $("#passwordId").val($.cookie('password'));
    }

    // Handle form submit
    $("#loginForm").on("submit", function() {
        const username = $("#usernameId").val();
        const password = $("#passwordId").val();

        if ($("#rememberMe").is(":checked")) {
            $.cookie('username', username, { expires: 7, path: '/' });
            $.cookie('password', password, { expires: 7, path: '/' });
        } else {
            $.removeCookie('username', { path: '/' });
            $.removeCookie('password', { path: '/' });
        }
    });
});
</script>
	

	<script>
		var win = navigator.platform.indexOf('Win') > -1;
		if (win && document.querySelector('#sidenav-scrollbar')) {
			var options = {
				damping : '0.5'
			}
			Scrollbar.init(document.querySelector('#sidenav-scrollbar'),
					options);
		}
	</script>
	<!-- Github buttons -->
	<script async defer src="https://buttons.github.io/buttons.js"></script>
	<!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
	<script src="../assets/js/material-dashboard.min.js?v=3.2.0"></script>
</body>

</html>