<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ page import="java.util.List"%>
<%@ page import="dao.OrdersDAO"%>
<%@ page import="dto.OrdersDTO"%>
<!DOCTYPE html>
<html>
<head>
<title>Search Orders</title>
<link rel="stylesheet"
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<style>
body {
	background:
		url('https://images.unsplash.com/photo-1506806732259-39c2d0268443?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80')
		no-repeat center center fixed;
	background-size: cover;
}

.container {
	background-color: rgba(255, 255, 255, 0.9);
	padding: 30px;
	border-radius: 15px;
	box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.3);
}

h2 {
	color: #198754;
	font-weight: bold;
}

table {
	background-color: #fff;
}
</style>
</head>
<body class="bg-light">

	<div class="container mt-5">
		<h2 class="text-center mb-4">🔍 Search Orders</h2>

		<!-- Search Form -->
		<form action="searchOrders.jsp" method="get"
			class="row g-3 justify-content-center">
			<div class="col-md-3">
				<input type="text" name="customerName" class="form-control"
					placeholder="Enter Customer Name"
					value="<%=request.getParameter("customerName") != null ? request.getParameter("customerName") : ""%>">
			</div>
			<div class="col-md-3">
				<input type="text" name="vegetableName" class="form-control"
					placeholder="Enter Vegetable Name"
					value="<%=request.getParameter("vegetableName") != null ? request.getParameter("vegetableName") : ""%>">
			</div>
			<div class="col-md-3">
				<input type="date" name="orderDate" class="form-control"
					value="<%=request.getParameter("orderDate") != null ? request.getParameter("orderDate") : ""%>">
			</div>
			<div class="col-md-2">
				<button type="submit" class="btn btn-success w-100">Search</button>
			</div>
		</form>

		<hr class="my-4">

		<!-- Results -->
		<h4>Order List</h4>
		<%
		String customerName = request.getParameter("customerName");
		String vegetableName = request.getParameter("vegetableName");
		String orderDate = request.getParameter("orderDate");

		OrdersDAO orderDAO = new OrdersDAO();
		List<OrdersDTO> orders;

		if ((customerName != null && !customerName.trim().isEmpty())
				|| (vegetableName != null && !vegetableName.trim().isEmpty())
				|| (orderDate != null && !orderDate.trim().isEmpty())) {
			// Search when filters are applied
			orders = orderDAO.searchOrders(customerName, vegetableName, orderDate);
		} else {
			// Show all orders by default
			orders = orderDAO.getAllOrders();
		}

		if (orders != null && !orders.isEmpty()) {
		%>
		<table class="table table-bordered table-striped mt-3">
			<thead class="table-dark">
				<tr>
					<th>Order ID</th>
					<th>Customer</th>
					<th>Vegetable</th>
					<th>Quantity</th>
					<th>Total Price</th>
					<th>Order Date</th>
				</tr>
			</thead>
			<tbody>
				<%
				for (OrdersDTO order : orders) {
				%>
				<tr>
					<td><%=order.getId()%></td>
					<td><%=order.getCustomerName()%></td>
					<td><%=order.getVegetableName()%></td>
					<td><%=order.getQuantity()%></td>
					<td>₹<%=order.getVegetablePrice()%></td>
					<td><%=order.getOrderDate()%></td>
				</tr>
				<%
				}
				%>
			</tbody>
		</table>
		<%
		} else {
		%>
		<p class="text-danger mt-3">⚠ No orders found.</p>
		<%
		}
		%>
	</div>

</body>
</html>