<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MAJ - Vegetable Shop</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: url('https://images.pexels.com/photos/2255920/pexels-photo-2255920.jpeg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
        }

        /* Sidebar */
        .sidebar {
            height: 100vh;
            width: 240px;
            position: fixed;
            background: #198754;
            color: white;
            padding-top: 30px;
            box-shadow: 2px 0 8px rgba(0,0,0,0.2);
            z-index: 1000;
            transition: transform 0.3s ease-in-out;
        }
        .sidebar h3 {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar a {
            display: block;
            color: white;
            padding: 12px 20px;
            margin: 5px 15px;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 500;
            transition: 0.3s;
        }
        .sidebar a:hover { 
            background: #145c32; 
            transform: translateX(5px);
        }

        /* Sidebar Logo */
        .sidebar-logo {
            width: 70%;         /* scales with sidebar width */
            max-width: 220px;   /* won't exceed original size on desktop */
            height: auto;
            border-radius: 12px;
        }

        /* Sidebar toggle button for mobile */
        .sidebar-collapse-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1100;
            background: #198754;
            color: white;
            border: none;
            padding: 10px 12px;
            border-radius: 8px;
        }

        /* Content */
        .content { margin-left: 260px; padding: 20px; transition: margin-left 0.3s; }

        /* Hero Section */
        .hero-section {
            background: url('https://images.unsplash.com/photo-1617196039897-52adf705daa0?auto=format&fit=crop&w=1600&q=80') no-repeat center center;
            background-size: cover;
            height: 300px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2.5rem;
            font-weight: bold;
            text-shadow: 2px 2px 8px rgba(0,0,0,0.8);
            margin-bottom: 30px;
        }

        /* Cards */
        .card {
            border-radius: 15px;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .card:hover { 
            transform: translateY(-5px); 
            box-shadow: 0 12px 25px rgba(0,0,0,0.3); 
        }
        .card img {
            height: 200px;
            object-fit: cover;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }

        /* Footer */
        footer {
            background: #145c32; 
            color: white; 
            padding: 15px; 
            text-align: center; 
            border-radius: 10px; 
            margin-top: 40px; 
        }

        /* Responsive */
        @media(max-width:768px){
            .sidebar { 
                transform: translateX(-100%); 
                width: 200px;
            }
            .sidebar.show { transform: translateX(0); }
            .sidebar-collapse-btn { display: block; }
            .content { margin-left: 0; }

            .sidebar-logo {
                width: 50%;    /* smaller on mobile for better fit */
                max-width: 150px;
            }
        }
    </style>
</head>
<body>

    <!-- Sidebar toggle button for mobile -->
    <button class="sidebar-collapse-btn" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar -->
    <div class="sidebar text-center" id="sidebar">
        <!-- Logo -->
        <div style="margin-bottom: 20px;">
            <img src="images/MAJ_shop.png" alt="MAJ Shop Logo" class="sidebar-logo">
        </div>

        <h3><i class="fas fa-leaf"></i> MAJ Vegetable Shop</h3>
        
        <a href="CustomerServlet?action=list"><i class="fas fa-user"></i> Customers</a>
        <a href="vegetables.jsp"><i class="fas fa-carrot"></i> Vegetables</a>
        <a href="orders.jsp"><i class="fas fa-shopping-cart"></i> Orders</a>
        <a href="ReportServlet"><i class="fas fa-chart-bar"></i> Reports</a>
    </div>

    <!-- Main Content -->
    <div class="content">
        <!-- Hero Section -->
        <div class="hero-section"><i class="fas fa-seedling"></i> Fresh & Organic Vegetables</div>

        <!-- Dashboard Cards -->
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <img src="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Customers">
                    <div class="card-body text-center">
                        <h5 class="card-title">Manage Customers</h5>
                        <p class="card-text">Add, update, and view customer details.</p>
                        <a href="customers.jsp" class="btn btn-success">Go to Customers</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm">
                    <img src="https://images.pexels.com/photos/393611/pexels-photo-393611.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Vegetables">
                    <div class="card-body text-center">
                        <h5 class="card-title">Manage Vegetables</h5>
                        <p class="card-text">Add new vegetables and categorize them.</p>
                        <a href="vegetables.jsp" class="btn btn-success">Go to Vegetables</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm">
                    <img src="https://images.pexels.com/photos/96974/pexels-photo-96974.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Orders">
                    <div class="card-body text-center">
                        <h5 class="card-title">Manage Orders</h5>
                        <p class="card-text">Place orders, filter, and search history.</p>
                        <a href="orders.jsp" class="btn btn-success">Go to Orders</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <footer class = "text-light">&copy; 2025 MAJ - Vegetable Shop | Contact: 9881775845 / 8999104696 | Proprietors : Omkar Dhage | Abhijeet Suryawanshi</footer>
    </div>

    <script>
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('show');
        }
    </script>

</body>
</html>
