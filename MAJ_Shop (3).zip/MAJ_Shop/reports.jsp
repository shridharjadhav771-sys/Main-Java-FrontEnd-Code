<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="dto.ReportDTO" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Reports - Vegetable Shop</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: url('https://images.pexels.com/photos/2255920/pexels-photo-2255920.jpeg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
        }

        .dashboard-container {
            background-color: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 6px 15px rgba(0,0,0,0.3);
        }

        h2 {
            font-weight: bold;
            color: #2c3e50;
        }

        .card {
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
            transition: transform 0.2s ease-in-out;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .stat-value {
            font-size: 1.8rem;
            font-weight: bold;
        }

        .stat-label {
            font-size: 0.9rem;
            color: #6c757d;
        }
    </style>
</head>
<body>
<div class="container mt-5 dashboard-container">
    <h2 class="mb-4 text-center">📊 Reports Dashboard</h2>

    <%
        ReportDTO report = (ReportDTO) request.getAttribute("report");
        if (report == null) {
    %>
        <div class="alert alert-warning">No reports available</div>
    <%
        } else {
    %>

        <!-- Stats in cards -->
        <div class="row text-center">
            <div class="col-md-3 mb-3">
                <div class="card bg-light">
                    <div class="card-body">
                        <div class="stat-value text-primary"><%= report.getTotalCustomers() %></div>
                        <div class="stat-label">Total Customers</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card bg-light">
                    <div class="card-body">
                        <div class="stat-value text-success"><%= report.getTotalVegetables() %></div>
                        <div class="stat-label">Total Vegetables</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card bg-light">
                    <div class="card-body">
                        <div class="stat-value text-warning"><%= report.getTotalOrders() %></div>
                        <div class="stat-label">Total Orders</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card bg-light">
                    <div class="card-body">
                        <div class="stat-value text-danger">₹ <%= report.getTotalSales() %></div>
                        <div class="stat-label">Total Sales</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Detailed Table -->
        <div class="mt-5">
            <h4 class="mb-3">📑 Detailed Report</h4>
            <table class="table table-bordered table-striped text-center">
                <tr>
                    <th>Total Customers</th>
                    <td><%= report.getTotalCustomers() %></td>
                </tr>
                <tr>
                    <th>Total Vegetables</th>
                    <td><%= report.getTotalVegetables() %></td>
                </tr>
                <tr>
                    <th>Total Orders</th>
                    <td><%= report.getTotalOrders() %></td>
                </tr>
                <tr>
                    <th>Total Sales (₹)</th>
                    <td><%= report.getTotalSales() %></td>
                </tr>
            </table>
        </div>
    <%
        }
    %>

    <div class="text-center mt-4">
        <a href="index.jsp" class="btn btn-primary btn-lg">⬅ Back to Home</a>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
