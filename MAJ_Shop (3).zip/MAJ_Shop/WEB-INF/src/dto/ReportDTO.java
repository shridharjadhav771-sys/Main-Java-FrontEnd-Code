package dto;

public class ReportDTO {
    private int totalCustomers;
    private int totalVegetables;
    private int totalOrders;
    private double totalSales;

    // Getters and Setters
    public int getTotalCustomers() {
        return totalCustomers;
    }
    public void setTotalCustomers(int totalCustomers) {
        this.totalCustomers = totalCustomers;
    }

    public int getTotalVegetables() {
        return totalVegetables;
    }
    public void setTotalVegetables(int totalVegetables) {
        this.totalVegetables = totalVegetables;
    }

    public int getTotalOrders() {
        return totalOrders;
    }
    public void setTotalOrders(int totalOrders) {
        this.totalOrders = totalOrders;
    }

    public double getTotalSales() {
        return totalSales;
    }
    public void setTotalSales(double totalSales) {
        this.totalSales = totalSales;
    }
}
