package dto;

public class SearchDTO {
    private int id;
    private String customerName;
    private String vegetableName;
    private int quantity;
    private String orderDate;

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getVegetableName() { return vegetableName; }
    public void setVegetableName(String vegetableName) { this.vegetableName = vegetableName; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getOrderDate() { return orderDate; }
    public void setOrderDate(String orderDate) { this.orderDate = orderDate; }
}
