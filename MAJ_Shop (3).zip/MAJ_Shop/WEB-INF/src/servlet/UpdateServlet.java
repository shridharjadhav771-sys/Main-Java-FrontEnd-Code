package servlet;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CustomerDAO;
import dto.CustomerDTO;

@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
    private CustomerDAO customerDAO;

    public void init() {
        customerDAO = new CustomerDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String phone = request.getParameter("phone");
            String email = request.getParameter("email");

            CustomerDTO c = new CustomerDTO();
            c.setId(id);
            c.setName(name);
            c.setPhone(phone);
            c.setEmail(email);

            customerDAO.updateCustomer(c);
            response.sendRedirect("CustomerServlet");
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
