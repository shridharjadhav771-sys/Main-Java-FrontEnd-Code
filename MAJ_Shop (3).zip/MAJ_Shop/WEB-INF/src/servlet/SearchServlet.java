package servlet;

import dao.OrdersDAO;
import dao.SearchDAO;
import dto.OrdersDTO;
import dto.SearchDTO;
import java.io.IOException;
import java.util.List;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String customer = req.getParameter("customer");
        String vegetable = req.getParameter("vegetable");
        String date = req.getParameter("date");

        if (customer == null) customer = "";
        if (vegetable == null) vegetable = "";
        if (date == null) date = "";

        List<?> orders;

        try {
            // If all search fields are empty, show all orders
            if (customer.isEmpty() && vegetable.isEmpty() && date.isEmpty()) {
                OrdersDAO dao = new OrdersDAO();
                orders = dao.getAllOrders();   // Fetch all orders
            } else {
                SearchDAO dao = new SearchDAO();
                orders = dao.searchOrders(customer, vegetable, date);  // Fetch filtered
            }

            req.setAttribute("orders", orders);
            RequestDispatcher rd = req.getRequestDispatcher("searchOrders.jsp");
            rd.forward(req, resp);

        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().println("Error: " + e.getMessage());
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
