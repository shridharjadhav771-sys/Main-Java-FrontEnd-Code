package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.OrdersDAO;
import dto.OrdersDTO;


@WebServlet("/OrderServlet")
public class OrdersServlet extends HttpServlet {

	 private static final long serialVersionUID = 1L;
	    private OrdersDAO orderDAO;

	    @Override
	    public void init() throws ServletException {
	        orderDAO = new OrdersDAO();
	    }

	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
	            throws ServletException, IOException {

	        String action = request.getParameter("action");

	        if ("add".equals(action)) {
	            addOrder(request, response);
	        } else {
	            response.sendRedirect("orders.jsp");
	        }
	    }

	    private void addOrder(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {

	        int customerId = Integer.parseInt(request.getParameter("customerId"));
	        int vegetableId = Integer.parseInt(request.getParameter("vegetableId"));
	        int quantity = Integer.parseInt(request.getParameter("quantity"));

	        OrdersDTO order = new OrdersDTO();
	        order.setCustomerId(customerId);
	        order.setVegetableId(vegetableId);
	        order.setQuantity(quantity);

	        boolean success = false;
	        try {
	            success = orderDAO.addOrder(order);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        if (success) {
	            response.sendRedirect("orders.jsp?status=success");
	        } else {
	            response.sendRedirect("orders.jsp?status=error");
	        }
	    }
}