package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.VegetablesDAO;
import dto.VegetablesDTO;

@WebServlet("/VegetableServlet")
public class VegetableServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private VegetablesDAO vegetableDAO;

    @Override
    public void init() throws ServletException {
        vegetableDAO = new VegetablesDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("add".equals(action)) {
            addVegetable(request, response);
        } else {
            response.sendRedirect("vegetables.jsp");
        }
    }

    private void addVegetable(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	@WebServlet("/AddVegetableServlet")
    public class AddVegetableServlet extends HttpServlet {
        protected void doPost(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException {

            String name = request.getParameter("name");
            String category = request.getParameter("category");
            double price = Double.parseDouble(request.getParameter("price"));

            VegetablesDTO v = new VegetablesDTO();
            v.setName(name);
            v.setCategory(category);
            v.setPrice(price);

            try {
                VegetablesDAO dao = new VegetablesDAO();
                dao.addVegetable(v);
                response.sendRedirect("vegetables.jsp");
            } catch (Exception e) {
                e.printStackTrace();
                response.getWriter().println("Error: " + e.getMessage());
            }
        }
    }

}