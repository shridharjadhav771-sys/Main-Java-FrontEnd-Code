package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.VegetablesDAO;

@WebServlet("/DeleteVegetableServlet")
public class DeleteVegetableServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private VegetablesDAO dao;

    @Override
    public void init() throws ServletException {
        dao = new VegetablesDAO();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        try {
            boolean success = dao.deleteVegetable(id);
            if (success) {
                resp.sendRedirect("vegetables.jsp?status=deleted");
            } else {
                resp.sendRedirect("vegetables.jsp?status=error");
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("vegetables.jsp?status=error");
        }
    }
}
