package servlet;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CustomerDAO;
import dto.CustomerDTO;

@WebServlet("/CustomerServlet")
public class CustomerServlet extends HttpServlet {
    private CustomerDAO customerDAO;

    public void init() {
        customerDAO = new CustomerDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            if (action == null || action.equals("list")) {
                listCustomers(request, response);
            } else if (action.equals("add")) {
                addCustomer(request, response);
            } else if (action.equals("delete")) {
                deleteCustomer(request, response);
            } else if (action.equals("edit")) {
                editCustomer(request, response);
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    private void listCustomers(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        List<CustomerDTO> list = customerDAO.getAllCustomers();
        request.setAttribute("customers", list);
        RequestDispatcher rd = request.getRequestDispatcher("customers.jsp");
        rd.forward(request, response);
    }

    private void addCustomer(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        CustomerDTO c = new CustomerDTO();
        c.setName(request.getParameter("name"));
        c.setPhone(request.getParameter("phone"));
        c.setEmail(request.getParameter("email"));
        customerDAO.addCustomer(c);
        response.sendRedirect("CustomerServlet?action=list");
    }

    private void deleteCustomer(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            boolean success = customerDAO.deleteCustomer(id);

            if (success) {
                response.sendRedirect("CustomerServlet?action=list&status=deleted"); // ✅ go through servlet
            } else {
                response.sendRedirect("CustomerServlet?action=list&status=delete_error"); // ✅
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("CustomerServlet?action=list&status=delete_error"); // ✅
        }
    }

    private void editCustomer(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        int id = Integer.parseInt(request.getParameter("id"));
        CustomerDTO customer = customerDAO.getCustomerById(id);
        request.setAttribute("customer", customer);
        RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
        rd.forward(request, response);
    }
}
