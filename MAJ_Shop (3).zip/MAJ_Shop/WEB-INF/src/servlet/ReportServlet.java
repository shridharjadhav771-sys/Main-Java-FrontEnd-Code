package servlet;

import dao.ReportDAO;
import dto.ReportDTO;
import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/ReportServlet")
public class ReportServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ReportDAO dao = new ReportDAO();
        ReportDTO report = dao.getReport();

        // Safety: if null, give empty DTO
        if (report == null) {
            report = new ReportDTO();
        }

        req.setAttribute("report", report);
        RequestDispatcher rd = req.getRequestDispatcher("reports.jsp");
        rd.forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
