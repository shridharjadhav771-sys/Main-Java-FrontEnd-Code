package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.VegetablesDAO;
import dto.VegetablesDTO;

@WebServlet("/UpdateVegetableServlet")
public class UpdateVegetableServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private VegetablesDAO dao;

    @Override
    public void init() throws ServletException {
        dao = new VegetablesDAO();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        try {
            VegetablesDTO v = dao.getVegetableById(id);
            req.setAttribute("veg", v);
            req.getRequestDispatcher("update_vegetable.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("vegetables.jsp?status=error");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        String name = req.getParameter("name");
        String category = req.getParameter("category");
        double price = Double.parseDouble(req.getParameter("price"));

        VegetablesDTO v = new VegetablesDTO();
        v.setId(id);
        v.setName(name);
        v.setCategory(category);
        v.setPrice(price);

        try {
            boolean success = dao.updateVegetable(v);
            if (success) {
                resp.sendRedirect("vegetables.jsp?status=updated");
            } else {
                resp.sendRedirect("vegetables.jsp?status=error");
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("vegetables.jsp?status=error");
        }
    }
}
