package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import dto.VegetablesDTO;
import utility.DBConfig;

public class VegetablesDAO {

	public boolean addVegetable(VegetablesDTO vegetable) throws Exception {
        String sql = "INSERT INTO vegetables (name, category, price) VALUES (?, ?, ?)";
        try (Connection con = DBConfig.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, vegetable.getName());
            ps.setString(2, vegetable.getCategory());
            ps.setDouble(3, vegetable.getPrice());
            
            int rows = ps.executeUpdate();
            return rows > 0;
        }
    }
	
	public List<VegetablesDTO> getAllVegetables() throws Exception {
        List<VegetablesDTO> list = new ArrayList<>();
        String sql = "SELECT * FROM vegetables";
        try (Connection con = DBConfig.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
            	VegetablesDTO v = new VegetablesDTO();
                v.setId(rs.getInt("id"));
                v.setName(rs.getString("name"));
                v.setCategory(rs.getString("category"));
                v.setPrice(rs.getDouble("price"));
                list.add(v);
            }
        }
        return list;
    }
	
	// Update vegetable
	public boolean updateVegetable(VegetablesDTO v) throws Exception {
	    String sql = "UPDATE vegetables SET name=?, category=?, price=? WHERE id=?";
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {
	        ps.setString(1, v.getName());
	        ps.setString(2, v.getCategory());
	        ps.setDouble(3, v.getPrice());
	        ps.setInt(4, v.getId());
	        return ps.executeUpdate() > 0;
	    }
	}

	// Delete vegetable
	public boolean deleteVegetable(int id) throws Exception {
	    String sql = "DELETE FROM vegetables WHERE id=?";
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {
	        ps.setInt(1, id);
	        return ps.executeUpdate() > 0;
	    }
	}

	// Get vegetable by ID
	public VegetablesDTO getVegetableById(int id) throws Exception {
	    String sql = "SELECT * FROM vegetables WHERE id=?";
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {
	        ps.setInt(1, id);
	        try (ResultSet rs = ps.executeQuery()) {
	            if (rs.next()) {
	                VegetablesDTO v = new VegetablesDTO();
	                v.setId(rs.getInt("id"));
	                v.setName(rs.getString("name"));
	                v.setCategory(rs.getString("category"));
	                v.setPrice(rs.getDouble("price"));
	                return v;
	            }
	        }
	    }
	    return null;
	}

}