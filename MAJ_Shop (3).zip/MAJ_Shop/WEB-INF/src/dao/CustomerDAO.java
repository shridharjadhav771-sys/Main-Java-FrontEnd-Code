package dao;

import dto.CustomerDTO;
import utility.DBConfig;

import java.sql.*;
import java.util.*;

public class CustomerDAO {

    // Add Customer
    public void addCustomer(CustomerDTO c) throws Exception {
        try (Connection con = DBConfig.getConnection()) {
            String sql = "INSERT INTO customers (name, phone, email) VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, c.getName());
            ps.setString(2, c.getPhone());
            ps.setString(3, c.getEmail());
            ps.executeUpdate();
        }
    }

    // Update Customer
    public boolean updateCustomer(CustomerDTO c) throws Exception {
        try (Connection con = DBConfig.getConnection()) {
            String sql = "UPDATE customers SET name=?, phone=?, email=? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, c.getName());
            ps.setString(2, c.getPhone());
            ps.setString(3, c.getEmail());
            ps.setInt(4, c.getId());
            return ps.executeUpdate()>0;
        }
    }

    // Delete Customer
    public boolean deleteCustomer(int id) {
	    String sql = "DELETE FROM customers WHERE id=?";
	    try (Connection conn = DBConfig.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setInt(1, id);
	        return ps.executeUpdate() > 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return false;
	    }
	}

    // List Customers
    public List<CustomerDTO> getAllCustomers() throws Exception {
        List<CustomerDTO> list = new ArrayList<>();
        try (Connection con = DBConfig.getConnection()) {
            String sql = "SELECT * FROM customers ORDER BY id DESC";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                CustomerDTO c = new CustomerDTO();
                c.setId(rs.getInt("id"));
                c.setName(rs.getString("name"));
                c.setPhone(rs.getString("phone"));
                c.setEmail(rs.getString("email"));
                list.add(c);
            }
        }
        return list;
    }

    // Get Single Customer
    public CustomerDTO getCustomerById(int id) throws Exception {
        try (Connection con = DBConfig.getConnection()) {
            String sql = "SELECT * FROM customers WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                CustomerDTO c = new CustomerDTO();
                c.setId(rs.getInt("id"));
                c.setName(rs.getString("name"));
                c.setPhone(rs.getString("phone"));
                c.setEmail(rs.getString("email"));
                return c;
            }
        }
        return null;
    }
}
