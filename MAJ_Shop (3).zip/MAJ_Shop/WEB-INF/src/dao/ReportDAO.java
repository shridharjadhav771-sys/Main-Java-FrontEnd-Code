package dao;

import java.sql.*;
import dto.ReportDTO;
import utility.DBConfig; // change to DBConfig if your class name is different

public class ReportDAO {

    public ReportDTO getReport() {
        ReportDTO dto = new ReportDTO();

        String sqlCustomers = "SELECT COUNT(*) FROM customers";
        String sqlVegetables = "SELECT COUNT(*) FROM vegetables";
        String sqlOrders = "SELECT COUNT(*) FROM orders";
        String sqlTotalSales = "SELECT SUM(o.quantity * v.price) " +
                               "FROM orders o JOIN vegetables v ON o.vegetable_id = v.id";

        try (Connection con = DBConfig.getConnection()) {

            // Customers
            try (PreparedStatement ps = con.prepareStatement(sqlCustomers);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) dto.setTotalCustomers(rs.getInt(1));
            }

            // Vegetables
            try (PreparedStatement ps = con.prepareStatement(sqlVegetables);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) dto.setTotalVegetables(rs.getInt(1));
            }

            // Orders
            try (PreparedStatement ps = con.prepareStatement(sqlOrders);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) dto.setTotalOrders(rs.getInt(1));
            }

            // Total Sales
            try (PreparedStatement ps = con.prepareStatement(sqlTotalSales);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    double total = rs.getDouble(1);
                    if (rs.wasNull()) total = 0.0;
                    dto.setTotalSales(total);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return dto;
    }
}
