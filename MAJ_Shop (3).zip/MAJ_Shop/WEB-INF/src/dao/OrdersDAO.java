package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import dto.OrdersDTO;
import utility.DBConfig;

public class OrdersDAO {

	public boolean addOrder(OrdersDTO order) throws Exception {
		String sql = "INSERT INTO orders (customer_id, vegetable_id, quantity, order_date) VALUES (?, ?, ?, ?)";
		try (Connection con = DBConfig.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setInt(1, order.getCustomerId());
			ps.setInt(2, order.getVegetableId());
			ps.setInt(3, order.getQuantity());
			ps.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
			return ps.executeUpdate() > 0;
		}
	}
	public List<OrdersDTO> getAllOrders() throws Exception {
	    List<OrdersDTO> list = new ArrayList<>();
	    
	    String sql = "SELECT o.id, c.name AS customerName, v.name AS vegetableName, " +
	                 "o.quantity, v.price AS vegetablePrice, o.order_date " +   // Alias price
	                 "FROM orders o " +
	                 "LEFT JOIN customers c ON o.customer_id = c.id " +       // Use LEFT JOIN
	                 "LEFT JOIN vegetables v ON o.vegetable_id = v.id " +    // Use LEFT JOIN
	                 "ORDER BY o.order_date DESC";
	    
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {

	        while (rs.next()) {
	        	OrdersDTO dto = new OrdersDTO();
	            dto.setId(rs.getInt("id"));
	            dto.setCustomerName(rs.getString("customerName"));      // Matches alias
	            dto.setVegetableName(rs.getString("vegetableName"));    // Matches alias
	            dto.setQuantity(rs.getInt("quantity"));
	            dto.setVegetablePrice(rs.getDouble("vegetablePrice"));  // Matches alias
	            dto.setOrderDate(rs.getTimestamp("order_date"));
	            
	            // Debug print
	            System.out.println("Fetched order: " + dto.getId() + " - " + dto.getCustomerName());
	            
	            list.add(dto);
	        }
	        System.out.println("Total orders fetched: " + list.size());
	    }
	    
	    return list;
	}
	public List<OrdersDTO> searchOrders(String customerName, String vegetableName, String orderDate) throws Exception {
	    StringBuilder sql = new StringBuilder(
	        "SELECT o.id, c.name AS customerName, v.name AS vegetableName, v.price AS vegetablePrice, " +
	        "o.quantity, o.order_date " +
	        "FROM orders o " +
	        "JOIN customers c ON o.customer_id = c.id " +
	        "JOIN vegetables v ON o.vegetable_id = v.id WHERE 1=1 "
	    );

	    List<Object> params = new ArrayList<>();

	    if (customerName != null && !customerName.trim().isEmpty()) {
	        sql.append(" AND c.name LIKE ? ");
	        params.add("%" + customerName + "%");
	    }
	    if (vegetableName != null && !vegetableName.trim().isEmpty()) {
	        sql.append(" AND v.name LIKE ? ");
	        params.add("%" + vegetableName + "%");
	    }
	    if (orderDate != null && !orderDate.trim().isEmpty()) {
	        sql.append(" AND DATE(o.order_date) = ? ");
	        params.add(orderDate);  // format: yyyy-MM-dd
	    }

	    List<OrdersDTO> list = new ArrayList<>();
	    try (Connection con = DBConfig.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql.toString())) {

	        for (int i = 0; i < params.size(); i++) {
	            ps.setObject(i + 1, params.get(i));
	        }

	        try (ResultSet rs = ps.executeQuery()) {
	            while (rs.next()) {
	                OrdersDTO order = new OrdersDTO();
	                order.setId(rs.getInt("id"));
	                order.setCustomerName(rs.getString("customerName"));
	                order.setVegetableName(rs.getString("vegetableName"));
	                order.setVegetablePrice(rs.getDouble("vegetablePrice"));
	                order.setQuantity(rs.getInt("quantity"));
	                order.setOrderDate(rs.getTimestamp("order_date"));
	                list.add(order);
	            }
	        }
	    }
	    return list;
	}
}