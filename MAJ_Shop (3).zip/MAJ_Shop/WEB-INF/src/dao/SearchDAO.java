package dao;

import java.sql.*;
import java.util.*;
import dto.SearchDTO;
import utility.DBConfig;

public class SearchDAO {

    public List<SearchDTO> searchOrders(String customer, String vegetable, String date) {
        List<SearchDTO> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT o.id, c.name AS customer_name, v.name AS vegetable_name, " +
            "o.quantity, o.order_date " +
            "FROM orders o " +
            "JOIN customers c ON o.customer_id = c.id " +
            "JOIN vegetables v ON o.vegetable_id = v.id " +
            "WHERE 1=1 "
        );

        if (customer != null && !customer.isEmpty()) {
            sql.append(" AND c.name LIKE ? ");
        }
        if (vegetable != null && !vegetable.isEmpty()) {
            sql.append(" AND v.name LIKE ? ");
        }
        if (date != null && !date.isEmpty()) {
            sql.append(" AND DATE(o.order_date) = ? ");
        }

        try (Connection con = DBConfig.getConnection();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            int index = 1;
            if (!customer.isEmpty()) ps.setString(index++, "%" + customer + "%");
            if (!vegetable.isEmpty()) ps.setString(index++, "%" + vegetable + "%");
            if (!date.isEmpty()) ps.setString(index++, date);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                SearchDTO dto = new SearchDTO();
                dto.setId(rs.getInt("id"));
                dto.setCustomerName(rs.getString("customer_name"));
                dto.setVegetableName(rs.getString("vegetable_name"));
                dto.setQuantity(rs.getInt("quantity"));
                dto.setOrderDate(rs.getString("order_date"));
                list.add(dto);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
