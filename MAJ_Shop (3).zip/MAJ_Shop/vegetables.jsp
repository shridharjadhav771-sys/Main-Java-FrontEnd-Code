<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.*,dao.VegetablesDAO,dto.VegetablesDTO" %>
<%
    VegetablesDAO dao = new VegetablesDAO();
    List<VegetablesDTO> list = dao.getAllVegetables();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Vegetables List - Vegetable Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
       body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: url('https://images.pexels.com/photos/2255920/pexels-photo-2255920.jpeg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
        }
        .container {
            margin-top: 60px;
        }
        .accordion-button {
            font-weight: 500;
        }
        .btn-sm {
            margin-right: 8px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="mb-4 text-center text-white">Vegetables Inventory</h2>

    <% String status = request.getParameter("status");
       if ("success".equals(status)) { %>
        <div class="alert alert-success">Vegetable added successfully!</div>
    <% } else if ("updated".equals(status)) { %>
        <div class="alert alert-success">Vegetable updated successfully!</div>
    <% } else if ("deleted".equals(status)) { %>
        <div class="alert alert-warning">Vegetable deleted successfully!</div>
    <% } else if ("error".equals(status)) { %>
        <div class="alert alert-danger">Operation failed. Try again.</div>
    <% } %>

    <!-- Collapsible List -->
    <div class="accordion" id="vegAccordion">
        <% if (list != null && !list.isEmpty()) {
               for (VegetablesDTO v : list) { %>
            <div class="accordion-item">
                <h2 class="accordion-header" id="heading<%=v.getId()%>">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<%=v.getId()%>">
                        <%= v.getName() %> - ₹<%= v.getPrice() %>
                    </button>
                </h2>
                <div id="collapse<%=v.getId()%>" class="accordion-collapse collapse" data-bs-parent="#vegAccordion">
                    <div class="accordion-body">
                        <p><b>Category:</b> <%= v.getCategory() %></p>
                        <p><b>Price:</b> ₹<%= v.getPrice() %></p>
                        <a href="UpdateVegetableServlet?id=<%= v.getId() %>" class="btn btn-sm btn-primary">Update</a>
                        <a href="DeleteVegetableServlet?id=<%= v.getId() %>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this vegetable?');">Delete</a>
                    </div>
                </div>
            </div>
        <% } } else { %>
            <div class="alert alert-info">No vegetables found. Please add some.</div>
        <% } %>
    </div>

    <div class="mt-4 text-center">
        <a href="vegetables.jsp" class="btn btn-success">Add New Vegetable</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
