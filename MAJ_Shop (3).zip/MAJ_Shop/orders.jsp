<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ page
	import="java.util.*, dao.CustomerDAO, dao.VegetablesDAO, dto.CustomerDTO, dto.VegetablesDTO"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Order - Vegetable Shop</title>
<link
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
	rel="stylesheet">
<style>
body {
	font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
	background:
		url('https://images.pexels.com/photos/2255920/pexels-photo-2255920.jpeg')
		no-repeat center center fixed;
	background-size: cover;
	margin: 0;
}

.card {
	border-radius: 20px;
	box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
	background: rgba(255, 255, 255, 0.92);
	/* translucent for readability */
}

.card-header {
	border-radius: 20px 20px 0 0;
	background: #198754;
	color: white;
	text-align: center;
	font-weight: bold;
	font-size: 1.2rem;
}

.btn-custom {
	border-radius: 30px;
	padding: 10px 20px;
	font-weight: 500;
}

.container {
	margin-top: 80px;
}
</style>
</head>
<body>
	<div class="container d-flex justify-content-center">
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">Place New Order
				<div class="d-flex justify-content-end mb-3">
							<!-- Search Order Page Redirect -->
							<a href="searchOrders.jsp" class="btn btn-light btn-sm"> 
							🔍 Search Orders  </a>     
						</div></div>
				<div class="card-body p-4">

					<!-- Right aligned Add Customer button -->
					<div class="d-flex justify-content-end mb-3">
						<a href="customers.jsp" class="btn btn-outline-dark btn-sm">
							➕ Add New Customer </a>
							
							</div>
							
						

						<form action="OrderServlet" method="post">
							<input type="hidden" name="action" value="add">

							<div class="mb-3">
								<label class="form-label">Select Customer</label> <select
									class="form-select" name="customerId" required>
									<option value="">-- Choose Customer --</option>
									<%
									CustomerDAO customerDAO = new CustomerDAO();
									List<CustomerDTO> customers = customerDAO.getAllCustomers();
									for (CustomerDTO c : customers) {
									%>
									<option value="<%=c.getId()%>"><%=c.getName()%></option>
									<%
									}
									%>
								</select>
							</div>

							<div class="mb-3">
								<label class="form-label">Select Vegetable</label> <select
									class="form-select" name="vegetableId" required>
									<option value="">-- Choose Vegetable --</option>
									<%
									VegetablesDAO vegetableDAO = new VegetablesDAO();
									List<VegetablesDTO> veggies = vegetableDAO.getAllVegetables();
									for (VegetablesDTO v : veggies) {
									%>
									<option value="<%=v.getId()%>"><%=v.getName()%> - ₹<%=v.getPrice()%></option>
									<%
									}
									%>
								</select>
							</div>

							<div class="mb-3">
								<label class="form-label">Quantity</label> <input type="number"
									class="form-control" name="quantity" min="1"
									placeholder="Enter quantity" required>
							</div>

							<div class="d-grid">
								<button type="submit" class="btn btn-success btn-custom">Place
									Order</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<script
			src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
