<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="dto.VegetablesDTO" %>
<%
    VegetablesDTO v = (VegetablesDTO) request.getAttribute("veg");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Update Vegetable</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">

<h2>Update Vegetable</h2>

<form action="UpdateVegetableServlet" method="post">
    <input type="hidden" name="id" value="<%= v.getId() %>">

    <div class="mb-3">
        <label class="form-label">Name</label>
        <input type="text" class="form-control" name="name" value="<%= v.getName() %>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Category</label>
        <input type="text" class="form-control" name="category" value="<%= v.getCategory() %>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Price</label>
        <input type="number" step="0.01" class="form-control" name="price" value="<%= v.getPrice() %>" required>
    </div>

    <button type="submit" class="btn btn-primary">Update</button>
    <a href="vegetables.jsp" class="btn btn-secondary">Cancel</a>
</form>

</body>
</html>
