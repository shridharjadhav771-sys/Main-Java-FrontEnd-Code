<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ page import="java.util.List"%>
<%@ page import="dto.CustomerDTO"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Customer Management - Vegetable Shop</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
	background: url('https://images.pexels.com/photos/2255920/pexels-photo-2255920.jpeg') no-repeat center center fixed;
	background-size: cover;
	font-family: Arial, sans-serif;
}
.card {
	border-radius: 15px;
}
.card-header {
	font-weight: bold;
	display: flex;
	justify-content: space-between;
	align-items: center;
}
.container-custom {
	margin-top: 30px;
}
.offcanvas-body {
	max-height: 75vh;
	overflow-y: auto;
}
.table-hover tbody tr:hover {
	background-color: #f1f1f1;
}
@media (max-width: 767px) {
	.card-header button {
		width: 100%;
		margin-top: 5px;
	}
}
</style>
</head>
<body>
<div class="container container-custom">
	<div class="row g-4">
		<!-- Add Customer Form -->
		<div class="col-12 col-md-5">
			<div class="card shadow-lg">
				<div class="card-header bg-success text-white">Add New Customer</div>
				<div class="card-body">
					<form action="CustomerServlet" method="post">
						<input type="hidden" name="action" value="add">
						<div class="mb-3">
							<label>Customer Name</label>
							<input type="text" name="name" class="form-control" required>
						</div>
						<div class="mb-3">
							<label>Phone</label>
							<input type="text" name="phone" class="form-control" required>
						</div>
						<div class="mb-3">
							<label>Email</label>
							<input type="email" name="email" class="form-control" required>
						</div>
						<button type="submit" class="btn btn-success w-100">Add Customer</button>
					</form>
				</div>
			</div>
		</div>

		<!-- Customer List Hamburger -->
		<div class="col-12 col-md-7">
			<div class="card shadow-lg">
				<div class="card-header bg-success text-white">
					Customer List
					<button class="btn btn-light btn-sm" type="button" data-bs-toggle="offcanvas" data-bs-target="#customerSidebar" aria-controls="customerSidebar">
						☰ View Customers
					</button>
				</div>
				<div class="card-body">
					<p>Click the button above to view the customer list.</p>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Offcanvas Sidebar -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="customerSidebar" aria-labelledby="customerSidebarLabel">
  <div class="offcanvas-header bg-success text-white">
    <h5 class="offcanvas-title" id="customerSidebarLabel">Existing Customers</h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <%
    	List<CustomerDTO> list = (List<CustomerDTO>) request.getAttribute("customers");
    	if (list == null || list.isEmpty()) {
    %>
    	<p>No customers found.</p>
    <% } else { %>
    	<div class="table-responsive">
    		<table class="table table-hover table-striped align-middle">
    			<thead class="table-success">
    				<tr>
    					<th>#</th>
    					<th>Name</th>
    					<th>Phone</th>
    					<th>Email</th>
    					<th>Actions</th>
    				</tr>
    			</thead>
    			<tbody>
    			<%
    				int count = 1;
    				for(CustomerDTO c : list) {
    			%>
    				<tr>
    					<td><%= count++ %></td>
    					<td><%= c.getName() %></td>
    					<td><%= c.getPhone() %></td>
    					<td><%= c.getEmail() %></td>
    					<td>
    						<form action="CustomerServlet" method="post" style="display:inline;">
    							<input type="hidden" name="action" value="edit">
    							<input type="hidden" name="id" value="<%= c.getId() %>">
    							<button type="submit" class="btn btn-warning btn-sm">Edit</button>
    						</form>
    						<form action="CustomerServlet" method="post" style="display:inline;"
    							onsubmit="return confirm('Are you sure you want to delete this customer?');">
    							<input type="hidden" name="action" value="delete">
    							<input type="hidden" name="id" value="<%= c.getId() %>">
    							<button type="submit" class="btn btn-danger btn-sm">Delete</button>
    						</form>
    					</td>
    				</tr>
    			<% } %>
    			</tbody>
    		</table>
    	</div>
    <% } %>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
